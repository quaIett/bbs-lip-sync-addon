package mchorse.bbs_mod.cubic;

import mchorse.bbs_mod.bobj.BOBJBone;
import com.mojang.blaze3d.systems.RenderSystem;
import mchorse.bbs_mod.client.BBSShaders;
import mchorse.bbs_mod.client.render.picker.BBSPickerRenderer;
import mchorse.bbs_mod.cubic.data.animation.Animations;
import mchorse.bbs_mod.cubic.data.model.Model;
import mchorse.bbs_mod.cubic.data.model.ModelGroup;
import mchorse.bbs_mod.cubic.jem.CemAnimation;
import mchorse.bbs_mod.cubic.model.ArmorSlot;
import mchorse.bbs_mod.cubic.model.ArmorType;
import mchorse.bbs_mod.cubic.model.View;
import mchorse.bbs_mod.cubic.model.bobj.BOBJModel;
import mchorse.bbs_mod.cubic.model.config.ModelConfig;
import mchorse.bbs_mod.cubic.render.CubicCubeRenderer;
import mchorse.bbs_mod.cubic.render.CubicMatrixRenderer;
import mchorse.bbs_mod.cubic.render.CubicRenderer;
import mchorse.bbs_mod.cubic.render.vao.BOBJModelVAO;
import mchorse.bbs_mod.BBSModClient;
import mchorse.bbs_mod.cubic.render.vao.ModelVAORenderer;
import mchorse.bbs_mod.cubic.weld.ModelWeld;
import mchorse.bbs_mod.cubic.weld.WeldBinding;
import mchorse.bbs_mod.graphics.ModelPreviewRenderer;
import mchorse.bbs_mod.graphics.texture.Texture;
import mchorse.bbs_mod.data.types.MapType;
import mchorse.bbs_mod.forms.FormTranslucentQueue;
import mchorse.bbs_mod.forms.forms.Form;
import mchorse.bbs_mod.forms.forms.ModelForm;
import mchorse.bbs_mod.forms.renderers.utils.FormMaterialLevels;
import mchorse.bbs_mod.forms.renderers.utils.FormOverlay;
import mchorse.bbs_mod.forms.renderers.utils.MatrixCache;
import mchorse.bbs_mod.forms.renderers.utils.RenderFrame;
import mchorse.bbs_mod.obj.shapes.ShapeKeys;
import mchorse.bbs_mod.resources.Link;
import mchorse.bbs_mod.ui.framework.elements.utils.StencilMap;
import mchorse.bbs_mod.utils.MathUtils;
import mchorse.bbs_mod.utils.colors.Color;
import mchorse.bbs_mod.utils.joml.Matrices;
import mchorse.bbs_mod.utils.pose.Pose;
import mchorse.bbs_mod.utils.pose.Transform;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_7833;
import net.minecraft.class_9801;
import com.mojang.blaze3d.vertex.VertexFormat;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;

public class ModelInstance implements IModelInstance
{

    public final String id;
    public IModel model;
    public Animations animations;

    /** Live procedural OptiFine CEM animation, when this model was loaded from a .jem; null otherwise. */
    public CemAnimation cemAnimation;

    /* The channels token: which (form, entity, transition, frame, pose version) the asset's
     * pose currently holds. The instance is one globally cached asset per model id, so the
     * token must live HERE — two forms sharing a model overwrite each other's pose, and each
     * write re-stamps it. See ModelFormRenderer#evaluateChannels. */
    private Object channelsForm;
    private Object channelsEntity;
    private float channelsTransition;
    private long channelsEpoch;
    private int channelsPoseVersion;
    private boolean channelsValid;

    public boolean matchesChannels(Object form, Object entity, float transition, long epoch, int poseVersion)
    {
        return this.channelsValid
            && this.channelsForm == form
            && this.channelsEntity == entity
            && Float.compare(this.channelsTransition, transition) == 0
            && this.channelsEpoch == epoch
            && this.channelsPoseVersion == poseVersion;
    }

    public void stampChannels(Object form, Object entity, float transition, long epoch, int poseVersion)
    {
        this.channelsForm = form;
        this.channelsEntity = entity;
        this.channelsTransition = transition;
        this.channelsEpoch = epoch;
        this.channelsPoseVersion = poseVersion;
        this.channelsValid = true;
    }

    public void clearChannels()
    {
        this.channelsValid = false;
        this.channelsForm = null;
        this.channelsEntity = null;
    }

    /** The model's intrinsic texture from its loader; {@link ModelConfig#texture} overrides it when set. */
    public Link baseTexture;

    /**
     * What the loader had to work around to build this model - a part model it could not find, an
     * attribute it does not support, a second model file in the folder it had to leave out - worded
     * by the loader, one line each. A model that came out wrong looks exactly like one drawn that way,
     * and the console, where the same lines go, is where nobody looks; the model editor shows these.
     */
    public final List<String> warnings = new ArrayList<>();

    /**
     * The {@code .bbs.json} this model was read from, when the model editor may write it back: a
     * cubic model that is a real file in the user's own assets, with nothing compiled in from other
     * files. Null for every other model — one from the jar or a pack, an OBJ, a VOX — and those the
     * editor only configures.
     */
    private Link modelFile;

    /**
     * Per-material default textures, loaded from the model's {@code textures/<material>/}
     * folders (or synthesized as a 1x1 swatch for flat-color materials). Keyed by material
     * name; the empty key is the model's default texture. Used as the static fallback for a
     * material when no animation track overrides it - see {@link #getMaterialTexture}.
     */
    public Map<String, Link> materialTextures = new HashMap<>();

    /** Ordered, distinct list of material names present on the model (for the editor and resolution). */
    public List<String> materials = new ArrayList<>();

    /** The pass list of a model with nothing to tell apart: draw it all, with whatever is bound. */
    private static final List<String> SINGLE_PASS = java.util.Collections.singletonList(null);

    /** The model's {@code config.json} as an editable value tree; the instance reads every setting from here. */
    public final ModelConfig config;

    /** Welds resolved against the model (groups/cubes/corners). Built lazily on first render, kept across frames. */
    private List<WeldBinding> weldBindings;

    public transient Form form;

    public ModelInstance(String id, IModel model, Animations animations, Link texture)
    {
        this.id = id;
        this.model = model;
        this.animations = animations;
        this.baseTexture = texture;
        this.config = new ModelConfig(id);
    }

    @Override
    public IModel getModel()
    {
        return this.model;
    }

    /** The file the model editor writes this model to, or null for a model it may only configure. */
    public Link getModelFile()
    {
        return this.modelFile;
    }

    public void setModelFile(Link modelFile)
    {
        this.modelFile = modelFile;
    }

    /** Whether the model editor may edit the model itself — see {@link #getModelFile()}. */
    public boolean isEditable()
    {
        return this.modelFile != null;
    }

    @Override
    public Pose getSneakingPose()
    {
        return this.config.getSneakingPose();
    }

    public Pose getDefaultPose()
    {
        return this.config.getDefaultPose();
    }

    @Override
    public Animations getAnimations()
    {
        return this.animations;
    }

    /** Welds resolved against this model, built once. Empty when the model declares none or isn't cubic. */
    public List<WeldBinding> getWeldBindings()
    {
        if (this.weldBindings == null)
        {
            this.weldBindings = new ArrayList<>();

            if (this.model instanceof Model model)
            {
                for (ModelWeld weld : this.config.getWelds())
                {
                    WeldBinding binding = WeldBinding.resolve(model, weld);

                    if (binding != null)
                    {
                        this.weldBindings.add(binding);
                    }
                }
            }
        }

        return this.weldBindings;
    }

    /**
     * Re-resolve welds after the config's weld list was edited: drop the cached bindings (rebuilt on the
     * next render) and refresh the config's derived caches so the new welds take effect.
     */
    public void invalidateWelds()
    {
        this.weldBindings = null;
        this.config.rebuild();
    }

    /**
     * Resolve a material's static default texture: the per-material texture loaded
     * from {@code textures/<material>/} if present, otherwise the supplied fallback
     * (the form/model default texture). Animation tracks layer on top of this at
     * render time (handled by the caller), so this only covers the non-animated default.
     */
    public Link getMaterialTexture(String material, Link fallback)
    {
        Link link = this.materialTextures.get(material);

        return link != null ? link : fallback;
    }

    public String getAnchor()
    {
        String anchor = this.model.getAnchor();
        String anchorGroup = this.config.anchor.get();

        if (anchorGroup.isEmpty() && !anchor.isEmpty())
        {
            return anchor;
        }

        return anchorGroup;
    }

    public void applyConfig(MapType data)
    {
        if (data == null)
        {
            return;
        }

        this.config.fromData(data);
    }

    /* Config accessors — the instance reads all of these from {@link #config}. */

    public Link getTexture()
    {
        Link texture = this.config.getTexture();

        return texture != null ? texture : this.baseTexture;
    }

    public Vector3f getScale()
    {
        return this.config.scale.get();
    }

    public float getUiScale()
    {
        return this.config.uiScale.get();
    }

    public boolean isProcedural()
    {
        return this.config.procedural.get();
    }

    public boolean isCulling()
    {
        return this.config.culling.get();
    }

    public String getPoseGroup()
    {
        String group = this.config.poseGroup.get();

        return group.isEmpty() ? this.id : group;
    }

    public View getView()
    {
        return this.config.getView();
    }

    public Set<String> getDisabledBones()
    {
        return this.config.disabledBones.get();
    }

    public Map<String, String> getFlippedParts()
    {
        return this.config.getFlippedParts();
    }

    public Map<ArmorType, ArmorSlot> getArmorSlots()
    {
        return this.config.getArmorSlots();
    }

    public List<ArmorSlot> getItemsMain()
    {
        return this.config.getItemsMain();
    }

    public List<ArmorSlot> getItemsOff()
    {
        return this.config.getItemsOff();
    }

    public ArmorSlot getFpMain()
    {
        return this.config.getFpMain();
    }

    public ArmorSlot getFpOffhand()
    {
        return this.config.getFpOffhand();
    }

    /**
     * Only BOBJ needs setting up. A cubic Model draws through the immediate CubicCubeRenderer path — in
     * previews via entityCutoutNoCull(adopted texture), in-world via the bbs:core/model layer — so there
     * is no per-group geometry to bake and retain for it. (1.21.1 baked one VAO per group here and drew
     * them through a raw-GL VAO path; that path is gone, and the bake with it.)
     */
    public void setup()
    {
        if (this.model instanceof BOBJModel model)
        {
            class_310.method_1551().execute(model::setup);
        }
    }

    /**
     * Release GPU resources held for this model. Nothing holds any today — cubic geometry is rebuilt into a
     * BufferBuilder per draw and BOBJ frees its own — but the model lifecycle calls this on reload, so the
     * hook stays for whatever the render path retains next.
     */
    public void delete()
    {}

    /* Rendering */

    public void fillStencilMap(StencilMap stencilMap, ModelForm form)
    {
        if (this.model instanceof Model model)
        {
            for (ModelGroup group : model.getOrderedGroups())
            {
                stencilMap.addPicking(form, this.getPickingBone(group.id));
            }
        }
        else if (this.model instanceof BOBJModel model)
        {
            for (BOBJBone orderedBone : model.getArmature().orderedBones)
            {
                stencilMap.addPicking(form, this.getPickingBone(orderedBone.name));
            }
        }
    }

    /**
     * Resolve a bone's name for stencil picking, redirecting it to another bone when the model's
     * config declares an override (e.g. clicking "torso" selecting "low_body" instead). The bone's
     * own geometry still owns the stencil index — only the bone the click resolves to changes.
     */
    private String getPickingBone(String bone)
    {
        return this.config.getPickingOverrides().getOrDefault(bone, bone);
    }

    public void captureMatrices(MatrixCache bones)
    {
        if (this.model instanceof Model model)
        {
            class_4587 stack = new class_4587();
            CubicMatrixRenderer renderer = new CubicMatrixRenderer(model);

            CubicRenderer.processRenderModel(renderer, null, stack, model);

            for (ModelGroup group : model.getAllGroups())
            {
                Matrix4f matrix = new Matrix4f(renderer.matrices.get(group.index));
                Matrix4f origin = new Matrix4f(renderer.origins.get(group.index));

                matrix.translate(
                    group.initial.translate.x / 16,
                    group.initial.translate.y / 16,
                    group.initial.translate.z / 16
                );
                matrix.rotateY(MathUtils.PI);
                origin.translate(
                    group.initial.translate.x / 16,
                    group.initial.translate.y / 16,
                    group.initial.translate.z / 16
                );
                origin.rotateY(MathUtils.PI);

                bones.put(group.id, matrix, origin, evaluatedChannelRotation(group.current, group.orient, true));
            }
        }
        else if (this.model instanceof BOBJModel model)
        {
            model.getArmature().setupMatrices();

            for (BOBJBone orderedBone : model.getArmature().orderedBones)
            {
                Matrix4f matrix = new Matrix4f();
                Matrix4f origin = new Matrix4f();

                matrix.rotateY(MathUtils.PI).mul(orderedBone.mat);
                origin.rotateY(MathUtils.PI).mul(orderedBone.originMat);

                bones.put(orderedBone.name, matrix, origin, evaluatedChannelRotation(orderedBone.transform, orderedBone.orient, false));
            }
        }
    }

    /**
     * The bone's EVALUATED channel rotation (ZYX euler radians) for the gizmo's
     * additive overlay-editing base, or {@code null} when the render doesn't
     * follow the channels additively: quaternion mode composes multiplicatively,
     * and a composed {@code orient} counts only while it still EQUALS the
     * channel rotation — the first composed layer seeds it FROM the channels
     * (identical by construction), but stacked layers multiply and diverge,
     * and then the additive base model doesn't apply.
     */
    private static Vector3f evaluatedChannelRotation(Transform current, Quaternionf orient, boolean degrees)
    {
        if (current.rotationMode == Transform.RotationMode.QUATERNION)
        {
            return null;
        }

        Vector3f radians = degrees
            ? new Vector3f(
                MathUtils.toRad(current.rotate.x),
                MathUtils.toRad(current.rotate.y),
                MathUtils.toRad(current.rotate.z)
            )
            : new Vector3f(current.rotate);

        if (orient != null)
        {
            Quaternionf channels = Matrices.toQuaternionZYXRadians(radians.x, radians.y, radians.z);

            /* |dot| = cos(θ/2) between the two rotations (double cover); anything
             * under ~1.6° apart means a genuinely multiplicative stack. */
            if (Math.abs(channels.dot(orient)) < 0.9999F)
            {
                return null;
            }
        }

        return radians;
    }

    /**
     * First weld pass: capture the rigid world corners of every welded face with no drawing, then build the seams.
     * Runs a dedicated capture-only renderer that only touches welded cubes (and only their welded face's corners),
     * so it's a light matrix walk over the tree rather than a full per-vertex pass.
     */
    private void captureWelds(List<WeldBinding> bindings, class_4587 stack, Model model, int light, int overlay, StencilMap stencilMap, ShapeKeys keys)
    {
        for (WeldBinding binding : bindings)
        {
            for (WeldBinding.Layer layer : binding.layers)
            {
                layer.resetCapture();
            }
        }

        CubicCubeRenderer capture = new CubicCubeRenderer(light, overlay, stencilMap, keys);

        capture.setWelds(bindings);
        capture.setCaptureOnly(true);
        CubicRenderer.processRenderModel(capture, null, stack, model);

        for (WeldBinding binding : bindings)
        {
            for (WeldBinding.Layer layer : binding.layers)
            {
                layer.computeSeam();
            }
        }
    }

    /**
     * The materials to draw in turn, or a single null pass — "draw everything, with whatever is
     * bound" — for a model that has no materials to tell apart. The empty name comes first: it is
     * the model's own geometry, drawn with the texture the caller bound.
     */
    private List<String> renderPasses(Function<String, Texture> textureResolver)
    {
        if (textureResolver == null || this.materials.size() <= 1)
        {
            return SINGLE_PASS;
        }

        List<String> passes = new ArrayList<>(this.materials.size() + 1);

        passes.add("");

        for (String material : this.materials)
        {
            if (!material.isEmpty())
            {
                passes.add(material);
            }
        }

        return passes;
    }

    public void render(class_4587 stack, Color color, int light, int overlay, StencilMap stencilMap, ShapeKeys keys, Function<String, Texture> textureResolver)
    {
        /* The colour overlay is off while the pick buffer is being filled (it draws ids, not colours)
         * and while the entity is flashing red — the hurt flash owns the channel then, and it wins. */
        boolean tintable = stencilMap == null && overlay == class_4608.field_21444 && this.form instanceof ModelForm;

        if (this.model instanceof Model model)
        {
            List<WeldBinding> bindings = this.getWeldBindings();

            /* 1.21.11: cubic models always take the immediate CPU path ({@link #isVAORendered} is BOBJ-only
             * here), so the 1.21.1 hybrid VAO/CPU split is unnecessary — the welded cubes deform right in
             * CubicCubeRenderer's subdivided quad path. The seams must still be captured first, for the
             * visible draw AND for picking (else a bent welded bone highlights its un-sealed rest silhouette). */
            if (!bindings.isEmpty())
            {
                this.captureWelds(bindings, stack, model, light, overlay, stencilMap, keys);
            }

            CubicCubeRenderer renderProcessor = new CubicCubeRenderer(light, overlay, stencilMap, keys);

            renderProcessor.setColor(color.r, color.g, color.b, color.a);
            renderProcessor.setWelds(bindings);
            /* A material switched off in the material tab drops every cube and mesh that names it. */
            renderProcessor.setMaterialVisibility((material) -> FormMaterialLevels.materialVisible(this.form instanceof ModelForm form ? form : null, material));

            /* One pass per material, each with that material's texture bound: the draw takes its
             * texture from whatever the manager bound last, and an OBJ normalises every material's
             * UVs into ITS OWN texture (the model sheet stays 1x1, see CubicModelLoader), so a
             * single pass would sample every material against one sheet. A model with at most one
             * material keeps its single unfiltered pass. */
            for (String material : this.renderPasses(textureResolver))
            {
                if (material != null && !material.isEmpty())
                {
                    Texture materialTexture = textureResolver.apply(material);

                    if (materialTexture != null)
                    {
                        BBSModClient.getTextures().bindTexture(materialTexture);

                        /* The pick pass cuts out against Sampler0, so it follows the same texture —
                         * otherwise a material's UVs would be judged against the form's sheet. */
                        if (stencilMap != null)
                        {
                            BBSPickerRenderer.setSampler0(materialTexture);
                        }
                    }
                }

                renderProcessor.setMaterialFilter(material);

                /* The overlay is authored on three levels — the form, the material, the bone — and
                 * they collapse into one colour per bone. A palette in the swatch carries them all
                 * through a single draw: each bone's colour claims a texel and its vertices address
                 * it. */
                ModelForm modelForm = tintable ? (ModelForm) this.form : null;
                String tintMaterial = material == null ? "" : material;

                FormOverlay.beginPalette();
                renderProcessor.setOverlayPalette(modelForm == null ? null
                    : (group) -> FormOverlay.slot(FormOverlay.combine(modelForm, tintMaterial, group)));

                /* TODO(1.21.11 render): RenderSystem.setShader(...) + BufferRenderer.drawWithGlobalProgram(...)
                 * were removed in 1.21.5+. The immediate (non-VAO) cube geometry is built into a BufferBuilder
                 * in QUADS mode (CubicCubeRenderer now emits 4 verts/face) so it can be drawn through a vanilla
                 * entity RenderLayer (POSITION_COLOR_TEXTURE_OVERLAY_LIGHT_NORMAL + QUADS). During an in-panel
                 * preview (ModelPreviewRenderer.ACTIVE) it goes to entityCutoutNoCull(adopted model texture);
                 * the world path still targets the not-yet-ported BBS model layer (no-op until VARIANT 2). */
                class_287 builder = class_289.method_1348().method_60827(VertexFormat.class_5596.field_27382, class_290.field_1580);
                CubicRenderer.processRenderModel(renderProcessor, builder, stack, model);

                /* The subdivided welded quads are held back in the renderer's patch buffer during
                 * the walk (so a seam gets both of its sides before it is drawn) and only leave it
                 * here — without this the bent bands are simply not emitted. */
                renderProcessor.finish(builder);

                class_9801 built = builder.method_60794();

                /* Claimed while the geometry was written, so the upload comes after it. */
                boolean tinted = FormOverlay.hasPalette();

                if (tinted)
                {
                    FormOverlay.commitPalette();
                }

                if (built != null)
                {
                    if (stencilMap != null)
                    {
                        /* Picking pass: draw the index colours (Target + per-vertex bone sub-index in UV2.x)
                         * with the picker_models pipeline into the StencilFormFramebuffer target. The custom
                         * BBSPicker UBO can't ride the immediate RenderLayer path, so it goes through
                         * BBSPickerRenderer; the model-view is identity here (the camera is baked into the
                         * vertices, same as the visible draw above). Target/Sampler0 were set by the renderer. */
                        BBSPickerRenderer.draw(BBSShaders.getPickerModelsProgram(), built, RenderSystem.getModelViewMatrix());
                    }
                    else if (ModelPreviewRenderer.ACTIVE && ModelPreviewRenderer.TEXTURE != null)
                    {
                        /* In-panel preview (form editor viewport, list thumbnails). This used to draw through
                         * vanilla entityCutoutNoCull — a port stopgap from before the BBS model layer existed.
                         * CUTOUT has no blending: a fragment either fully lands (writing its FULL colour, so a
                         * faded model read as "lighter" over the premultiplied FBO blit instead of transparent)
                         * or is discarded once final alpha drops under 0.1 (the "suddenly disappears" cliff at
                         * the bottom of the alpha slider). The BBS model layer blends, so the form's colour
                         * alpha fades the preview exactly like the world; same entity vertex format, and the
                         * layer keyed on the SAME adopted texture the cutout branch used. */
                        FormOverlay.withOverlay(BBSShaders.getBoundModelLayer(BBSShaders.ModelVariant.SINGLE.withCull(this.isCulling())), tinted).method_60895(built);
                    }
                    else
                    {
                        /* model.culling picks the layer variant. On 1.21.1 it was a global GL toggle
                         * (ModelFormRenderer disabled culling around the whole render when the model
                         * asked for it and restored it afterwards); the pipeline encodes it now.
                         * Depth write stays on: model geometry is solid, so its own semi-transparent
                         * texels must keep occluding the ones behind them even in the deferred pass. */
                        FormTranslucentQueue.submit(built,
                            new BBSShaders.ModelVariant(FormTranslucentQueue.PASS_SINGLE, true, this.isCulling()),
                            BBSModClient.getTextures().getLastBound(), color.a, stencilMap,
                            ModelVAORenderer.captureModelView(stack).getTranslation(new Vector3f()), tinted);
                    }
                }
            }
        }
        else if (this.model instanceof BOBJModel model)
        {
            List<BOBJModelVAO> vaos = model.getVaos();

            if (!vaos.isEmpty())
            {
                stack.method_22903();
                stack.method_22907(class_7833.field_40716.rotationDegrees(180F));

                model.getArmature().setupMatrices();

                /* One draw per mesh; bind that mesh's resolved texture (mesh name = material) —
                 * the draw takes its texture from getLastBound(), so the bind slots per-mesh
                 * material textures back in exactly the way 1.21.1 did. */
                for (BOBJModelVAO vao : vaos)
                {
                    /* A mesh IS its material here, so a material switched off in the material tab
                     * takes the whole mesh out of the draw. */
                    if (!FormMaterialLevels.materialVisible(this.form instanceof ModelForm form ? form : null, vao.data.mesh.name))
                    {
                        continue;
                    }

                    if (textureResolver != null)
                    {
                        Texture meshTexture = textureResolver.apply(vao.data.mesh.name);

                        if (meshTexture != null)
                        {
                            BBSModClient.getTextures().bindTexture(meshTexture);
                        }
                    }

                    /* Per mesh, because a BOBJ mesh IS its material — same level the cubic path
                     * tints at, and the form's own overlay is folded in by combine(). */
                    Color tint = tintable ? FormOverlay.combine((ModelForm) this.form, vao.data.mesh.name, null) : null;

                    if (tint != null)
                    {
                        FormOverlay.swatch(tint);
                    }

                    vao.updateMesh(stencilMap);
                    vao.render(stack, color.r, color.g, color.b, color.a, stencilMap, light, overlay, this.isCulling(), tint);
                }

                stack.method_22909();
            }
        }
    }
}
