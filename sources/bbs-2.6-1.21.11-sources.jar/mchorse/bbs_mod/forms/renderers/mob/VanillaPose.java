package mchorse.bbs_mod.forms.renderers.mob;

import net.minecraft.class_10017;
import net.minecraft.class_10042;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_922;

/**
 * Vanilla's own posing of a living entity's model, without a render: the render state the living
 * entity renderer would draw from, and {@code setAngles} with it. The mob form's offline matrices
 * ({@link MobRigMatrices}) and the CEM stage ({@code CemVanillaStage}) both pose the model this way,
 * from one place, so the two cannot drift apart.
 *
 * <p>Model parts are shared with the world's real entities of that kind. The pose left here is the
 * one every render of them overwrites first thing, so it costs nobody anything — except while an
 * entity render is in flight, which is the one moment the writes would be seen: {@link #renderer}
 * answers null then.</p>
 */
public class VanillaPose
{
    /**
     * The renderer a living entity draws through, or null when there is nothing to pose: an entity that
     * is not living, one no living renderer takes, or an entity render in flight.
     */
    public static class_922 renderer(class_1297 entity)
    {
        if (MobRenderContext.current() != null || !(entity instanceof class_1309))
        {
            return null;
        }

        return class_310.method_1551().method_1561().method_3953(entity) instanceof class_922 renderer ? renderer : null;
    }

    /**
     * Pose the renderer's model for this frame of the entity, the way {@code LivingEntityRenderer.render}
     * does before it draws, and hand back the state it posed from — null when the entity has none.
     *
     * <p>Since 1.21.2 the model is posed from a render STATE rather than from the entity: setAngles
     * takes one, and everything the 1.21.1 call assembled by hand — hand swing, riding, baby, the
     * limb swing, the interpolated yaws and pitch, the scale attribute — is a field on it.
     * getAndUpdateRenderState is the one supported way to fill one, and it is what MobFormRenderer's
     * own draw already uses, so a caller walks exactly the pose the entity is drawn in rather than a
     * second, hand-built approximation of it.</p>
     */
    public static class_10042 animate(class_922 renderer, class_1309 living, float transition)
    {
        class_10017 renderState = class_310.method_1551().method_1561().method_72977(living, transition);

        if (!(renderState instanceof class_10042 state))
        {
            return null;
        }

        renderer.method_4038().method_2819(state);

        return state;
    }
}
