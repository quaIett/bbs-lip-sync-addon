package mchorse.bbs_mod.forms.renderers.utils;

import net.minecraft.class_4587;
import net.minecraft.class_4588;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * Feeds the fluid renderer's chunk format vertices into an entity format buffer.
 *
 * <p>{@link net.minecraft.class_775} writes position, colour, texture,
 * light and normal straight into the buffer, in world (well, chunk local) coordinates and
 * without a matrix, because chunk geometry never needs one. Forms need the entity format
 * instead: it carries an overlay, and it is the format the picking shader is compiled for.
 * So this applies the form's matrix to the vertices and slips the overlay in exactly where
 * the entity format expects it, right after the texture coordinates.</p>
 *
 * <p>Every method returns {@code this}: the fluid renderer chains its calls, and handing back
 * the wrapped buffer at any point in the chain would let the rest of the vertex bypass the
 * overlay.</p>
 */
public class FluidVertexConsumer implements class_4588
{
    private final class_4588 consumer;
    private final Matrix4f position;
    private final Matrix3f normal;
    private final int overlay;

    private final Vector3f temporary = new Vector3f();

    public FluidVertexConsumer(class_4588 consumer, class_4587.class_4665 entry, int overlay)
    {
        this.consumer = consumer;
        this.position = entry.method_23761();
        this.normal = entry.method_23762();
        this.overlay = overlay;
    }

    @Override
    public class_4588 method_22912(float x, float y, float z)
    {
        this.position.transformPosition(x, y, z, this.temporary);
        this.consumer.method_22912(this.temporary.x, this.temporary.y, this.temporary.z);

        return this;
    }

    @Override
    public class_4588 method_1336(int red, int green, int blue, int alpha)
    {
        this.consumer.method_1336(red, green, blue, alpha);

        return this;
    }

    @Override
    public class_4588 method_39415(int argb)
    {
        this.consumer.method_39415(argb);

        return this;
    }

    @Override
    public class_4588 method_22913(float u, float v)
    {
        this.consumer.method_22913(u, v);
        this.consumer.method_60796(this.overlay & 0xFFFF, this.overlay >> 16 & 0xFFFF);

        return this;
    }

    @Override
    public class_4588 method_60796(int u, int v)
    {
        return this;
    }

    @Override
    public class_4588 method_22921(int u, int v)
    {
        this.consumer.method_22921(u, v);

        return this;
    }

    @Override
    public class_4588 method_22914(float x, float y, float z)
    {
        this.normal.transform(x, y, z, this.temporary);
        this.consumer.method_22914(this.temporary.x, this.temporary.y, this.temporary.z);

        return this;
    }

    @Override
    public class_4588 method_75298(float width)
    {
        this.consumer.method_75298(width);

        return this;
    }
}
