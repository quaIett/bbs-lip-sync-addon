package mchorse.bbs_mod.forms.renderers;

import com.mojang.blaze3d.opengl.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import mchorse.bbs_mod.client.BBSRendering;
import mchorse.bbs_mod.client.BBSShaders;
import mchorse.bbs_mod.client.render.picker.PickingReplay;
import mchorse.bbs_mod.forms.CustomVertexConsumerProvider;
import mchorse.bbs_mod.forms.FormRenderCapture;
import mchorse.bbs_mod.forms.FormUtilsClient;
import mchorse.bbs_mod.forms.QueueDispatch;
import mchorse.bbs_mod.forms.forms.StructureForm;
import mchorse.bbs_mod.forms.renderers.utils.FormColorBlend;
import mchorse.bbs_mod.forms.renderers.utils.FormOverlay;
import mchorse.bbs_mod.forms.structure.BakedStructure;
import mchorse.bbs_mod.forms.structure.StructureManager;
import mchorse.bbs_mod.forms.structure.StructureRenderData;
import mchorse.bbs_mod.forms.structure.StructureRenderWorld;
import mchorse.bbs_mod.forms.structure.StructureWorld;
import mchorse.bbs_mod.ui.framework.UIContext;
import mchorse.bbs_mod.utils.MatrixStackUtils;
import mchorse.bbs_mod.utils.colors.Color;
import mchorse.bbs_mod.utils.colors.OverlayBlend;
import mchorse.bbs_mod.utils.joml.Vectors;
import net.minecraft.class_11954;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_765;
import net.minecraft.class_824;
import net.minecraft.class_827;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

/**
 * Renders a {@link StructureForm}: every block of the structure goes through the vanilla
 * block/fluid renderer against a {@link StructureRenderWorld} (smooth AO + biome tint baked
 * at tesselation time, textures from the active resource pack).
 *
 * <p>Normal rendering replays a {@link BakedStructure} (tesselated once per
 * structure/biome/resource generation). The naive per-frame path is kept only for editor
 * picking, where the hijacked picker shader is applied per draw.</p>
 */
public class StructureFormRenderer extends FormRenderer<StructureForm>
{
    private static final Color COLOR = new Color();
    private static final Color OVERLAY = new Color();

    private String lastStructure;
    private String lastBiome;
    private int lastGeneration = -1;

    private StructureRenderData data;
    private StructureRenderWorld world;
    private BakedStructure baked;

    private List<class_2586> blockEntities;
    private final Set<class_2338> erroredBlockEntities = new HashSet<>();

    /** Structure-backed world the block entities are bound to (null until built; falls back to mc.world). */
    private class_1937 structureWorld;

    private final Vector3f offset = new Vector3f();

    public StructureFormRenderer(StructureForm form)
    {
        super(form);
    }

    /** Reload structure/biome when the form properties change, or the manager dropped its cache. */
    private void ensureData()
    {
        int generation = StructureManager.getGeneration();
        String structure = this.form.structure.get();
        String biome = this.form.biome.get();

        /* A new generation means a world switch or a re-scan from the picker: every piece of state
         * below was derived from data (and a client world) that no longer applies */
        if (generation != this.lastGeneration || !Objects.equals(structure, this.lastStructure))
        {
            this.lastGeneration = generation;
            this.lastStructure = structure;

            this.reset();
        }

        if (this.data == null)
        {
            /* The manager can only answer once a world is present — retry until it does */
            this.data = StructureManager.get(structure);

            if (this.data == null)
            {
                return;
            }
        }

        if (this.world == null || !Objects.equals(biome, this.lastBiome))
        {
            this.lastBiome = biome;
            this.world = new StructureRenderWorld(this.data, biome);
        }
    }

    /**
     * Translation from the form's pivot to the structure's own (0, 0, 0) corner. By default that
     * centers the footprint and rests it on the pivot; the form's origin offset moves the pivot
     * through the structure, which shifts the geometry the other way.
     */
    private Vector3f getOffset()
    {
        class_2382 size = this.data.size;
        Vector3f origin = this.form.origin.get();

        return this.offset.set(
            -size.method_10263() / 2F - origin.x,
            -origin.y,
            -size.method_10260() / 2F - origin.z
        );
    }


    /** Drop everything derived from the structure file: it is gone, replaced, or stale. */
    private void reset()
    {
        this.data = null;
        this.world = null;
        this.baked = null;
        this.blockEntities = null;
        this.structureWorld = null;
        this.erroredBlockEntities.clear();
    }

    private void ensureBaked()
    {
        if (this.baked == null || !this.baked.isValidFor(this.world))
        {
            this.baked = BakedStructure.bake(this.data, this.world);
        }
    }

    /**
     * Depth guard for nested forms: a BBS model block saved inside a structure renders its own
     * form, which may itself be (or contain) a structure form — without a cap a self-referential
     * structure would recurse forever.
     */
    private static int blockEntityDepth;

    /** Render chests/signs/beds/... through their vanilla block entity renderers (per frame). */
    private void renderBlockEntities(class_4587 matrices, CustomVertexConsumerProvider consumers, int light, int overlay)
    {
        if (blockEntityDepth >= 2)
        {
            return;
        }

        blockEntityDepth += 1;

        try
        {
            this.doRenderBlockEntities(matrices, consumers, light, overlay);
        }
        finally
        {
            blockEntityDepth -= 1;
        }
    }

    private void doRenderBlockEntities(class_4587 matrices, CustomVertexConsumerProvider consumers, int light, int overlay)
    {
        if (this.blockEntities == null)
        {
            /* Since 1.21.1 a block entity deserialises with the registries, and those come
             * from the client world; with no world yet there is nothing to build them from,
             * so the list stays null and the next frame tries again. */
            class_1937 client = class_310.method_1551().field_1687;

            if (client == null)
            {
                return;
            }

            this.blockEntities = new ArrayList<>();
            this.erroredBlockEntities.clear();

            Map<class_2338, class_2586> byPos = new HashMap<>();

            for (Map.Entry<class_2338, class_2487> e : this.data.getBlockEntities().entrySet())
            {
                try
                {
                    class_2586 blockEntity = class_2586.method_11005(e.getKey(), this.data.getBlockState(e.getKey()), e.getValue(), client.method_30349());

                    if (blockEntity != null)
                    {
                        this.blockEntities.add(blockEntity);
                        byPos.put(e.getKey(), blockEntity);
                    }
                }
                catch (Exception ex)
                {
                    ex.printStackTrace();
                }
            }

            /* Bind them to a structure-backed world so neighbor/light queries resolve within the
             * structure (double chests pair, etc.); null falls back to mc.world below */
            this.structureWorld = StructureWorld.create(this.data, byPos);
        }

        if (this.blockEntities.isEmpty())
        {
            return;
        }

        /* Renamed in 1.21.11: BlockEntityRenderDispatcher is BlockEntityRenderManager. */
        class_824 dispatcher = class_310.method_1551().method_31975();

        for (class_2586 blockEntity : this.blockEntities)
        {
            class_2338 pos = blockEntity.method_11016();

            if (this.erroredBlockEntities.contains(pos))
            {
                continue;
            }

            /* Renderers may query the world (light, double chest neighbors, BBS model blocks). The
             * structure-backed world resolves those against the structure itself; if it could not be
             * built (no client world to borrow registries from), fall back to the real client world */
            blockEntity.method_31662(this.structureWorld != null ? this.structureWorld : class_310.method_1551().field_1687);

            /* Isolated stack: if the renderer throws mid-render, its unbalanced pushes must not
             * corrupt the shared pose stack ("Pose stack not empty" crash) */
            class_4587 local = new class_4587();

            local.method_23760().method_23761().set(matrices.method_23760().method_23761());
            local.method_23760().method_23762().set(matrices.method_23760().method_23762());
            local.method_46416(pos.method_10263(), pos.method_10264(), pos.method_10260());

            try
            {
                /* Block entity renderers only submit commands since 1.21.2, so they go through the
                 * BBS queue and are flushed here — the same path the block form's own entity takes.
                 * The state is built by hand rather than through manager.getRenderState(), which
                 * refuses anything past the renderer's render distance from the camera: a structure
                 * sits wherever the form does, and its chests must not stop opening far from spawn.
                 * The form's own light replaces the light at that position. */
                class_827 renderer = dispatcher.method_3550(blockEntity);

                if (renderer == null)
                {
                    continue;
                }

                class_11954 renderState = renderer.method_74335();

                renderer.method_74331(blockEntity, renderState,
                    class_310.method_1551().method_61966().method_60637(false),
                    class_310.method_1551().field_1773.method_19418().method_71156(), null);

                renderState.field_62676 = light;

                dispatcher.method_3555(renderState, local, QueueDispatch.queue(), QueueDispatch.cameraState());
                QueueDispatch.flush();
            }
            catch (Exception ex)
            {
                /* Renderer incompatible with detached block entities — skip it from now on */
                this.erroredBlockEntities.add(pos);
                ex.printStackTrace();
            }
        }
    }

    @Override
    public void renderInUI(UIContext context, int x1, int y1, int x2, int y2)
    {
        this.ensureData();

        /* 1.21.11: the list draws each cell in the GUI RECORD phase, where an immediate 3D draw
         * cannot composite (two-phase GUI) — getContext().draw() is gone and getMatrices() is 2D.
         * So the thumbnail is submitted as a vanilla special GUI element like every other 3D form
         * type, and the work happens in renderUIPreview inside the off-screen pass. */
        this.submitUIPreview(context, x1, y1, x2, y2);
    }

    @Override
    public void renderUIPreview(class_4587 matrices, float angle, float transition, int x1, int y1, int x2, int y2)
    {
        if (this.world == null)
        {
            /* No structure picked (or not loadable) — render a structure block as the
             * placeholder, the same way the block form renders its preview */
            this.renderPlaceholderBlock(matrices, angle, y1, y2);

            return;
        }

        CustomVertexConsumerProvider consumers = FormUtilsClient.getProvider();
        Matrix4f uiMatrix = getUIPreviewMatrix(angle, y1, y2);

        Color overlay = this.form.overlayColor.get();
        boolean overlayActive = OverlayBlend.isActive(overlay);

        if (overlayActive)
        {
            FormOverlay.swatch(overlay);
        }

        matrices.method_22903();

        try
        {
            MatrixStackUtils.multiply(matrices, uiMatrix);

            class_2382 size = this.data.size;
            float max = Math.max(size.method_10263(), Math.max(size.method_10264(), size.method_10260()));
            float scale = (max > 0 ? 1F / max : 1F) * this.form.uiScale.get();
            Vector3f offset = this.getOffset();

            matrices.method_22905(scale, scale, scale);
            matrices.method_46416(offset.x, offset.y, offset.z);

            matrices.method_23760().method_23762().getScale(Vectors.EMPTY_3F);
            matrices.method_23760().method_23762().scale(1F / Vectors.EMPTY_3F.x, -1F / Vectors.EMPTY_3F.y, 1F / Vectors.EMPTY_3F.z);

            this.ensureBaked();

            Color set = Color.white();
            FormColorBlend.blend(set, this.form.color.get());

            consumers.setUI(true);
            consumers.setLayerMapper(overlayActive ? FormOverlay::withOverlay : null);
            this.baked.render(matrices.method_23760(), consumers, class_765.field_32767, set.getARGBColor());

            consumers.setSubstitute(BBSRendering.getColorConsumer(set));
            this.renderBlockEntities(matrices, consumers, class_765.field_32767, class_4608.field_21444);

            consumers.method_22993();
        }
        finally
        {
            consumers.setSubstitute(null);
            consumers.setUI(false);
            consumers.setLayerMapper(null);
            CustomVertexConsumerProvider.clearRunnables();

            matrices.method_22909();
        }
    }

    private void renderPlaceholderBlock(class_4587 matrices, float angle, int y1, int y2)
    {
        CustomVertexConsumerProvider consumers = FormUtilsClient.getProvider();
        Matrix4f uiMatrix = getUIPreviewMatrix(angle, y1, y2);

        matrices.method_22903();

        try
        {
            MatrixStackUtils.multiply(matrices, uiMatrix);
            matrices.method_22905(this.form.uiScale.get(), this.form.uiScale.get(), this.form.uiScale.get());
            matrices.method_46416(-0.5F, 0F, -0.5F);

            matrices.method_23760().method_23762().getScale(Vectors.EMPTY_3F);
            matrices.method_23760().method_23762().scale(1F / Vectors.EMPTY_3F.x, -1F / Vectors.EMPTY_3F.y, 1F / Vectors.EMPTY_3F.z);

            consumers.setUI(true);
            class_310.method_1551().method_1541().method_3353(class_2246.field_10465.method_9564(), matrices, consumers, class_765.field_32769, class_4608.field_21444);
            consumers.method_22993();
        }
        finally
        {
            consumers.setUI(false);

            matrices.method_22909();
        }
    }

    @Override
    protected void render3D(FormRenderingContext context)
    {
        this.ensureData();

        if (this.world == null)
        {
            return;
        }

        CustomVertexConsumerProvider consumers = FormUtilsClient.getProvider();
        Vector3f offset = this.getOffset();

        Color overlay = this.form.overlayColor.get();
        boolean overlayActive = !context.isPicking() && OverlayBlend.isActive(overlay);

        if (overlayActive)
        {
            FormOverlay.swatch(overlay);
        }

        context.stack.method_22903();
        if (context.world != null)
        {
            context.world.method_22903();
        }

        /* finally guarantees pops/state reset: a renderer failure must degrade to a log line,
         * not corrupt the frame ("Pose stack not empty" + profiler cascade) */
        try
        {
            context.stack.method_46416(offset.x, offset.y, offset.z);
            if (context.world != null)
            {
                context.world.method_46416(offset.x, offset.y, offset.z);
            }

            COLOR.set(context.color);
            FormColorBlend.blend(COLOR, this.form.color.get());

            this.ensureBaked();

            if (context.isPicking())
            {
                /* Capture the structure's vanilla-layer geometry and replay it through the
                 * picker_models pipeline into the stencil, the way every vanilla-rendered form
                 * picks on this branch (see PickingReplay, BlockFormRenderer).
                 *
                 * The 1.21.1 route was a hijack hook that swapped the GLOBAL shader program for the
                 * picker while the layers below drew; 1.21.5+ has no global program to swap — the
                 * picker is a RenderPipeline chosen at the draw itself. So the hook was left setting
                 * nothing but the picking index, the geometry went to the ordinary entity layers and
                 * the structure never reached the pick buffer at all: it was unpickable outright. */
                this.setupTarget(context);

                FormRenderCapture.begin();

                Map<class_1921, List<FormRenderCapture.Captured>> captured;

                try
                {
                    this.baked.render(context.stack.method_23760(), consumers, context.light, 0xFFFFFFFF);

                    /* The block entities are part of the silhouette the eye sees, so they are part
                     * of what the cursor may land on. */
                    this.renderBlockEntities(context.stack, consumers, context.light, context.overlay);
                    consumers.method_22993();
                }
                finally
                {
                    captured = FormRenderCapture.end();
                }

                PickingReplay.draw(captured);
            }
            else
            {
                /* Force blend only when the form is actually faded (tint alpha < 1). For an opaque
                 * structure the terrain layers keep their native state — critical for cutout layers
                 * (leaves, plants): with blend forced on, their mipmapped edges turn semi-transparent
                 * and reveal the back faces behind them ("tearing" at grazing angles). Translucent
                 * blocks (glass/water) still blend through their own entity translucent-cull layer. */
                boolean faded = COLOR.a < 1F;

                if (faded)
                {
                    /* TODO(1.21.11 render): RenderSystem.enableBlend() was removed by the GPU-pipeline rewrite; this state is now encoded by the RenderLayer/RenderPipeline. */
                }

                consumers.setLayerMapper(overlayActive ? FormOverlay::withOverlay : null);
                this.baked.render(context.stack.method_23760(), consumers, context.light, COLOR.getARGBColor());

                /* Block entities still go through the consumer interface — tint them via substitute */
                consumers.setSubstitute(BBSRendering.getColorConsumer(COLOR));
                this.renderBlockEntities(context.stack, consumers, context.light, context.overlay);
            }

            consumers.method_22993();
        }
        finally
        {
            consumers.setSubstitute(null);
            consumers.setLayerMapper(null);
            CustomVertexConsumerProvider.clearRunnables();

            context.stack.method_22909();
            if (context.world != null)
            {
                context.world.method_22909();
            }

            /* TODO(1.21.11 render): RenderSystem.enableDepthTest() was removed by the GPU-pipeline rewrite; this state is now encoded by the RenderLayer/RenderPipeline. */
        }
    }
}
