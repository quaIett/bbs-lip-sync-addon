package mchorse.bbs_mod.forms.renderers;

import com.mojang.blaze3d.systems.RenderSystem;
import mchorse.bbs_mod.client.BBSRendering;
import mchorse.bbs_mod.client.render.picker.PickingReplay;
import mchorse.bbs_mod.forms.CustomVertexConsumerProvider;
import mchorse.bbs_mod.forms.FormRenderCapture;
import mchorse.bbs_mod.forms.FormTranslucentQueue;
import mchorse.bbs_mod.forms.FormUtilsClient;
import mchorse.bbs_mod.forms.forms.ItemForm;
import mchorse.bbs_mod.forms.renderers.utils.FormColorBlend;
import mchorse.bbs_mod.ui.framework.UIContext;
import mchorse.bbs_mod.utils.MatrixStackUtils;
import mchorse.bbs_mod.utils.colors.Color;
import mchorse.bbs_mod.utils.joml.Vectors;
import net.minecraft.class_10442;
import net.minecraft.class_10444;
import net.minecraft.class_11661;
import net.minecraft.class_11788;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_765;
import net.minecraft.class_811;
import net.minecraft.class_918;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.List;
import java.util.Map;

public class ItemFormRenderer extends FormRenderer<ItemForm>
{
    /* Reused per render to avoid per-frame allocation; the form renderers run single-threaded on the
     * client render thread (same assumption as BlockFormRenderer.color). clearAndUpdate() wipes it first. */
    private static final class_10444 renderState = new class_10444();

    public ItemFormRenderer(ItemForm form)
    {
        super(form);
    }

    @Override
    public void renderInUI(UIContext context, int x1, int y1, int x2, int y2)
    {
        /* List/icon preview: submit a special GUI element so the item draws off-screen during the GUI prepare
         * phase. A direct immediate item draw is dropped by the two-phase GUI here (so the item was invisible in
         * form/morph/replay lists), and it also inherited whatever DiffuseLighting state happened to be set (dark
         * in the form-properties editor until the window lost focus). The FBO render pass composites correctly AND
         * binds the form-preview diffuse lighting in BbsFormGuiElementRenderer.lights() — fixing both symptoms.
         * Same path as BlockForm / ModelForm. */
        this.submitUIPreview(context, x1, y1, x2, y2);
    }

    @Override
    public void renderUIPreview(class_4587 stack, float angle, float transition, int x1, int y1, int x2, int y2)
    {
        CustomVertexConsumerProvider consumers = FormUtilsClient.getProvider();

        /* The base renderer pre-translated the stack to the cell (centre, 0.85*height down) + scale(f,f,-f); apply
         * the rest of the original getUIMatrix framing here (cell scale + 22.5 tilt + cursor yaw), then the same
         * recolor + command-queue item draw renderInUI/render3D use. No -0.5 block centering — items render
         * centred at the origin. */
        Matrix4f uiMatrix = getUIPreviewMatrix(angle, y1, y2);

        stack.method_22903();
        MatrixStackUtils.multiply(stack, uiMatrix);
        stack.method_22905(this.form.uiScale.get(), this.form.uiScale.get(), this.form.uiScale.get());

        stack.method_23760().method_23762().getScale(Vectors.EMPTY_3F);
        stack.method_23760().method_23762().scale(1F / Vectors.EMPTY_3F.x, -1F / Vectors.EMPTY_3F.y, 1F / Vectors.EMPTY_3F.z);

        Color set = Color.white();
        FormColorBlend.blend(set, this.form.color.get());

        consumers.setSubstitute(BBSRendering.getColorConsumer(set));
        consumers.setUI(true);
        renderItem(this.form.stack.get(), this.form.modelTransform.get(), stack, consumers, class_310.method_1551().field_1687, class_765.field_32769, class_4608.field_21444);
        consumers.method_22993();
        consumers.setUI(false);
        consumers.setSubstitute(null);

        stack.method_22909();
    }

    @Override
    protected void render3D(FormRenderingContext context)
    {
        CustomVertexConsumerProvider consumers = FormUtilsClient.getProvider();
        int light = context.light;

        context.stack.method_22903();

        if (context.isPicking())
        {
            /* Picking: capture the item's vanilla-layer geometry and replay it through the
             * picker_models pipeline into the stencil — the global-shader swap 1.21.1 used has no
             * 1.21.5+ equivalent, the capture+replay does the same job. */
            this.setupTarget(context);

            FormRenderCapture.begin();

            Map<class_1921, List<FormRenderCapture.Captured>> captured;

            try
            {
                class_1937 pickWorld = context.entity == null ? null : context.entity.getWorld();

                renderItem(this.form.stack.get(), this.form.modelTransform.get(), context.stack, consumers, pickWorld, 0, context.overlay);
                consumers.method_22993();
            }
            finally
            {
                captured = FormRenderCapture.end();
            }

            PickingReplay.draw(captured);

            context.stack.method_22909();

            return;
        }

        /* TODO(1.21.11 render): RenderSystem.enableBlend() is gone; blend state now lives in each
         * RenderLayer's RenderPipeline. */
        CustomVertexConsumerProvider.hijackVertexFormat((l) -> {});

        BlockFormRenderer.color.set(context.color);
        FormColorBlend.blend(BlockFormRenderer.color, this.form.color.get());

        /* Publishing the form's camera-space origin opts its translucent layers into the
         * deferred sorted pass (see CustomVertexConsumerProvider#draw(RenderLayer)). */
        if (!context.isPicking())
        {
            Vector3f origin = context.stack.method_23760().method_23761().getTranslation(new Vector3f());

            FormTranslucentQueue.setSortOrigin(new Matrix4f(RenderSystem.getModelViewMatrix()).transformPosition(origin));
        }

        consumers.setSubstitute(BBSRendering.getColorConsumer(BlockFormRenderer.color));

        /* 1.21.1 called renderItem(stack, modelTransform, light, overlay, context.stack, consumers,
         * entity world, 0). Same faithful command-queue replacement as renderInUI. */
        class_1937 world = context.entity == null ? null : context.entity.getWorld();

        renderItem(this.form.stack.get(), this.form.modelTransform.get(), context.stack, consumers, world, light, context.overlay);
        consumers.method_22993();
        consumers.setSubstitute(null);
        FormTranslucentQueue.setSortOrigin(null);

        CustomVertexConsumerProvider.clearRunnables();

        context.stack.method_22909();

        /* TODO(1.21.11 render): RenderSystem.enableDepthTest() was removed in 1.21.5; depth testing is
         * now encoded per RenderLayer via DepthTestFunction on its pipeline. */
    }

    /**
     * Faithful 1.21.11 replacement for the removed high-level {@code ItemRenderer.renderItem(ItemStack, ...,
     * VertexConsumerProvider, ...)} overload used by the 1.21.1 renderer.
     *
     * <p>The 1.21.4 item-model rewrite resolves an {@link class_1799} into an {@link class_10444} of baked
     * draw layers, then renders it into an {@code OrderedRenderCommandQueue} (bypassing
     * {@link net.minecraft.class_4597}). To preserve the BBS recolor/picking hook
     * (which works by substituting the {@code VertexConsumerProvider}), we:</p>
     * <ol>
     *     <li>resolve the stack into per-layer item commands via {@link class_10442#method_65598} +
     *     {@link class_10444#method_65604} into a private {@link class_11661};</li>
     *     <li>replay each queued {@code ItemCommand} through the surviving low-level static
     *     {@link class_918#method_62476(class_811, class_4587, net.minecraft.class_4597, int, int, int[], java.util.List, net.minecraft.class_1921, class_10444.class_10445)}
     *     (which still accepts a {@code VertexConsumerProvider}) feeding the BBS {@code consumers}.</li>
     * </ol>
     * This mirrors what {@link net.minecraft.class_11687} does internally, but
     * routes geometry through the recolor provider instead of the engine's {@code Immediate}.
     *
     * <p>Also the shared held-item renderer: {@code ModelFormRenderer.renderItems} draws the items a form
     * holds on its bones through here (the 1.21.1 high-level renderItem it used is gone the same way).
     */
    public static void renderItem(class_1799 stack, class_811 displayContext, class_4587 matrices, CustomVertexConsumerProvider consumers, class_1937 world, int light, int overlay)
    {
        renderItem(stack, displayContext, matrices, consumers, world, light, overlay, null);
    }

    /**
     * The same, for an item held by a body: the holder answers vanilla's model predicates (a bow
     * bends and shows its arrow, a shield blocks, a trident lifts). 1.21.4+ takes it as the
     * {@link net.minecraft.class_11566} of the resolve, which {@link class_1309}
     * implements - the seed is vanilla's own from {@code ItemModelManager.updateForLivingEntity}.
     */
    public static void renderItem(class_1799 stack, class_811 displayContext, class_4587 matrices, CustomVertexConsumerProvider consumers, class_1937 world, int light, int overlay, class_1309 holder)
    {
        if (stack == null || stack.method_7960())
        {
            return;
        }

        class_10442 modelManager = class_310.method_1551().method_65386();

        /* Resolve the item into baked per-layer geometry (replaces 1.21.1's implicit model resolution inside
         * the old renderItem). Without a holder this is what updateForNonLivingEntity passes for a
         * free-standing item: no HeldItemContext and seed 0. */
        modelManager.method_65598(renderState, stack, displayContext, world, holder, holder == null ? 0 : holder.method_5628() + displayContext.ordinal());

        class_11661 queue = new class_11661();

        /* light/overlay/outlineColor: outlineColor=0 (no glow outline). render() enqueues one ItemCommand per
         * layer into the queue's batching queues. */
        renderState.method_65604(matrices, queue, light, overlay, 0);

        for (class_11788 batch : queue.method_73532().values())
        {
            for (class_11661.class_11668 command : batch.method_73522())
            {
                /* Replay faithfully (see ItemCommandRenderer#render): push a copy of the captured entry, draw,
                 * pop. The VertexConsumerProvider is the BBS recolor/picking-substituting `consumers`. */
                matrices.method_22903();
                matrices.method_23760().method_66521(command.comp_4498());
                class_918.method_62476(
                    command.comp_4638(),
                    matrices,
                    consumers,
                    command.comp_4500(),
                    command.comp_4501(),
                    command.comp_4639(),
                    command.comp_4640(),
                    command.comp_4641(),
                    command.comp_4642()
                );
                matrices.method_22909();
            }

            /* BBS special-model items (model block, gun) land in the queue as CUSTOM commands —
             * FormRenderCapture.submitForm captures the form's immediate draws and re-emits them via
             * submitCustom. ItemCommand replay alone would silently drop exactly the mod's own items
             * (field opened by bbs.accesswidener; vanilla's CustomCommandRenderer reads it the same way). */
            for (Map.Entry<class_1921, List<class_11661.class_11664>> entry : batch.method_73525().field_62980.entrySet())
            {
                class_4588 buffer = consumers.method_73477(entry.getKey());

                for (class_11661.class_11664 command : entry.getValue())
                {
                    command.comp_4489().render(command.comp_4488(), buffer);
                }
            }
        }
    }
}
