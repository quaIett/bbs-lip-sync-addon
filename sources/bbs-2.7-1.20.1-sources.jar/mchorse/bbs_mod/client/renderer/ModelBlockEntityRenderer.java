package mchorse.bbs_mod.client.renderer;

import com.mojang.blaze3d.systems.RenderSystem;
import mchorse.bbs_mod.BBSMod;
import mchorse.bbs_mod.BBSSettings;
import mchorse.bbs_mod.blocks.entities.ModelBlockEntity;
import mchorse.bbs_mod.blocks.entities.ModelProperties;
import mchorse.bbs_mod.cubic.ModelInstance;
import mchorse.bbs_mod.cubic.model.View;
import mchorse.bbs_mod.entity.ActorEntity;
import mchorse.bbs_mod.forms.FormUtilsClient;
import mchorse.bbs_mod.forms.entities.IEntity;
import mchorse.bbs_mod.forms.forms.Form;
import mchorse.bbs_mod.forms.forms.MobForm;
import mchorse.bbs_mod.forms.forms.ModelForm;
import mchorse.bbs_mod.forms.renderers.FormRenderType;
import mchorse.bbs_mod.forms.renderers.FormRenderingContext;
import mchorse.bbs_mod.forms.renderers.ModelFormRenderer;
import mchorse.bbs_mod.forms.renderers.utils.MatrixCache;
import mchorse.bbs_mod.graphics.Draw;
import mchorse.bbs_mod.mixin.client.EntityRendererDispatcherInvoker;
import mchorse.bbs_mod.mixin.client.WorldRendererAccessor;
import mchorse.bbs_mod.ui.dashboard.UIDashboard;
import mchorse.bbs_mod.ui.framework.UIBaseMenu;
import mchorse.bbs_mod.ui.framework.UIScreen;
import mchorse.bbs_mod.ui.model_blocks.UIModelBlockPanel;
import mchorse.bbs_mod.utils.MathUtils;
import mchorse.bbs_mod.utils.MatrixStackUtils;
import mchorse.bbs_mod.utils.joml.Matrices;
import mchorse.bbs_mod.utils.pose.Transform;
import net.minecraft.class_1088;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3191;
import net.minecraft.class_4184;
import net.minecraft.class_4583;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5614;
import net.minecraft.class_638;
import net.minecraft.class_761;
import net.minecraft.class_827;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.SortedSet;

public class ModelBlockEntityRenderer implements class_827<ModelBlockEntity>
{
    private static ActorEntity entity;

    public static void renderShadow(class_4597 provider, class_4587 matrices, float tickDelta, double x, double y, double z, float tx, float ty, float tz)
    {
        renderShadow(provider, matrices, tickDelta, x, y, z, tx, ty, tz, 0.5F, 1F);
    }

    public static void renderShadow(class_4597 provider, class_4587 matrices, float tickDelta, double x, double y, double z, float tx, float ty, float tz, float radius, float opacity)
    {
        class_638 world = class_310.method_1551().field_1687;

        if (entity == null || entity.method_37908() != world)
        {
            entity = new ActorEntity(BBSMod.ACTOR_ENTITY, world);
        }

        entity.method_23327(x, y, z);
        entity.field_6038 = x;
        entity.field_5971 = y;
        entity.field_5989 = z;
        entity.field_6014 = x;
        entity.field_6036 = y;
        entity.field_5969 = z;

        double distance = class_310.method_1551().method_1561().method_3959(x, y, z);

        opacity = (float) ((1D - distance / 256D) * opacity);

        matrices.method_22903();
        matrices.method_46416(tx, ty, tz);

        EntityRendererDispatcherInvoker.bbs$renderShadow(matrices, provider, entity, opacity, tickDelta, entity.method_37908(), radius);

        matrices.method_22909();
    }

    private static float getHeadYaw(float constraint, float yawDelta, float travel)
    {
        float headLimit = (float) Math.toRadians(constraint);
        float headYawBase = MathUtils.clamp(yawDelta, -headLimit, headLimit);

        float syncStart = (float) Math.toRadians(315D);
        float syncRange = (float) Math.toRadians(45D);
        float t = 0F;

        if (travel >= syncStart)
        {
            t = Math.min(1F, (travel - syncStart) / syncRange);
        }

        return headYawBase * (1F - t);
    }

    public ModelBlockEntityRenderer(class_5614.class_5615 ctx)
    {}

    @Override
    public boolean rendersOutsideBoundingBox(ModelBlockEntity blockEntity)
    {
        return blockEntity.getProperties().isGlobal();
    }

    @Override
    public void render(ModelBlockEntity entity, float tickDelta, class_4587 matrices, class_4597 vertexConsumers, int light, int overlay)
    {
        class_310 mc = class_310.method_1551();
        ModelProperties properties = entity.getProperties();
        Transform transform = properties.getTransform();
        class_2338 pos = entity.method_11016();

        /* While the matrices still sit at the cell's corner. */
        this.renderBreakingOverlay(mc, entity, matrices);

        matrices.method_22903();
        matrices.method_46416(0.5F, 0F, 0.5F);

        if (properties.getForm() != null && this.canRender(entity))
        {
            matrices.method_22903();

            Transform applied = transform;

            if (properties.isLookAt())
            {
                applied = this.applyLookingAnimation(mc, entity, properties, tickDelta);
            }
            else
            {
                IEntity iEntity = entity.getEntity();

                entity.resetLookYaw();
                iEntity.setHeadYaw(0F);
                iEntity.setPrevHeadYaw(0F);
                iEntity.setPitch(0F);
                iEntity.setPrevPitch(0F);
            }

            MatrixStackUtils.applyTransform(matrices, applied);

            int lightAbove = class_761.method_23794(entity.method_10997(), pos.method_10069((int) transform.translate.x, (int) transform.translate.y, (int) transform.translate.z));
            class_4184 camera = mc.field_1773.method_19418();

            RenderSystem.enableDepthTest();
            FormUtilsClient.render(properties.getForm(), new FormRenderingContext()
                .set(FormRenderType.MODEL_BLOCK, entity.getEntity(), matrices, lightAbove, overlay, tickDelta)
                .camera(camera));
            RenderSystem.disableDepthTest();

            if (this.canRenderAxes(entity) && UIBaseMenu.shouldRenderAxes())
            {
                matrices.method_22903();
                MatrixStackUtils.scaleBack(matrices);
                Draw.coolerAxes(matrices, 0.5F, 0.005F);
                matrices.method_22909();
            }

            matrices.method_22909();
        }

        RenderSystem.disableDepthTest();

        if (class_310.method_1551().field_1690.field_1866)
        {
            Draw.renderBox(matrices, -0.5D, 0, -0.5D, 1, 1, 1, 0, 0.5F, 1F, 0.5F);
        }

        matrices.method_22909();

        if (properties.isShadow())
        {
            float tx = 0.5F + transform.translate.x;
            float ty = transform.translate.y;
            float tz = 0.5F + transform.translate.z;
            double x = pos.method_10263() + tx;
            double y = pos.method_10264() + ty;
            double z = pos.method_10260() + tz;

            renderShadow(vertexConsumers, matrices, tickDelta, x, y, z, tx, ty, tz);
        }
    }

    private Transform applyLookingAnimation(class_310 mc, ModelBlockEntity entity, ModelProperties properties, float tickDelta)
    {
        Transform transform = properties.getTransform();
        class_4184 camera = mc.field_1773.method_19418();
        class_243 position = !mc.field_1690.method_31044().method_31034() && mc.field_1724 != null
            ? mc.field_1724.method_5836(tickDelta)
            : camera.method_19326();

        class_2338 pos = entity.method_11016();
        double x = pos.method_10263() + 0.5D + transform.translate.x;
        double y = pos.method_10264() + transform.translate.y;
        double z = pos.method_10260() + 0.5D + transform.translate.z;

        double dx = position.field_1352 - x;
        double dz = position.field_1350 - z;
        double distance = Math.sqrt(dx * dx + dz * dz);

        float initialYaw = lookYaw(transform);
        float yaw = (float) Math.atan2(dx, dz);
        float yawContinuous = entity.updateLookYawContinuous(yaw);
        float yawDelta = yawContinuous - initialYaw;
        float travel = Math.abs(yawDelta) % (MathUtils.PI * 2F);

        Transform finalTransform = transform.copy();
        Form form = properties.getForm();
        boolean lookAt = form instanceof MobForm;
        float headHeight = form.hitboxHeight.get() * form.hitboxEyeHeight.get() * finalTransform.scale.y;
        float constraint = 45F;
        boolean isPitching = true;

        if (form instanceof ModelForm modelForm)
        {
            ModelInstance model = ModelFormRenderer.getModel(modelForm);

            View view = model == null ? null : model.getView();

            if (view != null)
            {
                String headKey = view.headBone;

                lookAt = true;
                constraint = view.constraint;
                isPitching = view.pitch;

                if (FormUtilsClient.getBones(modelForm).contains(headKey))
                {
                    MatrixCache matrices = new MatrixCache();

                    model.captureMatrices(matrices);

                    Matrix4f matrix = matrices.get(headKey).matrix();

                    if (matrix != null)
                    {
                        headHeight = matrix.getTranslation(new Vector3f()).y * finalTransform.scale.y;
                    }
                }
            }
        }

        setLookYaw(finalTransform, yawContinuous);

        if (lookAt)
        {
            IEntity iEntity = entity.getEntity();
            double deltaHead = position.field_1351 - (y + headHeight);
            float pitch = MathUtils.clamp((float) Math.atan2(deltaHead, distance), -MathUtils.PI / 2F, MathUtils.PI / 2F);
            float headYaw = getHeadYaw(constraint, yawDelta, travel);
            float anchorYaw = yawDelta - headYaw;

            if (travel >= (float) Math.toRadians(359D))
            {
                headYaw = 0F;
                anchorYaw = 0F;

                entity.snapLookYawToBase(yaw, initialYaw);
            }

            setLookYaw(finalTransform, initialYaw + anchorYaw);
            headYaw = -MathUtils.toDeg(headYaw);
            pitch = -MathUtils.toDeg(isPitching ? pitch : 0F);

            iEntity.setHeadYaw(headYaw);
            iEntity.setPrevHeadYaw(headYaw);
            iEntity.setPitch(pitch);
            iEntity.setPrevPitch(pitch);
        }

        return finalTransform;
    }

    /**
     * The block transform's ZYX yaw channel, mode-aware: the euler channel directly, or — on a
     * quaternion transform, where the channels are stale — the quat decomposed on the branch
     * nearest those stale channels, so the yaw reads the same value the euler mode would hold
     * (a naive principal decomposition flips branches past ±90° and would read a wrong yaw).
     */
    private static float lookYaw(Transform transform)
    {
        if (transform.rotationMode == Transform.RotationMode.QUATERNION)
        {
            return Matrices.toCompatibleEulerZYXRadians(transform.quat, transform.rotate, new Vector3f()).y;
        }

        return transform.rotate.y;
    }

    /**
     * Writes the ZYX yaw channel mode-aware: the euler channel directly, or the quaternion
     * re-composed about the same compatible decomposition's X/Z tilt with the new yaw — the exact
     * quaternion equivalent of {@code rotate.y = yaw}, so look-at turns a quaternion-mode block
     * identically to a euler one.
     */
    private static void setLookYaw(Transform transform, float yaw)
    {
        if (transform.rotationMode == Transform.RotationMode.QUATERNION)
        {
            Vector3f euler = Matrices.toCompatibleEulerZYXRadians(transform.quat, transform.rotate, new Vector3f());

            transform.quat.rotationZYX(euler.z, yaw, euler.x);

            return;
        }

        transform.rotate.y = yaw;
    }

    /**
     * The vanilla mining cracks, painted over the block's hitbox box. The
     * block renders INVISIBLE, so vanilla's own crumbling pass (which redraws
     * the block model) has nothing to draw on — instead the cracks go onto the
     * body's shape here, through the same decal machinery vanilla uses: the
     * per-stage block-breaking layers on the effect buffers, UVs projected
     * from positions by {@link class_4583}.
     */
    private void renderBreakingOverlay(class_310 mc, ModelBlockEntity entity, class_4587 matrices)
    {
        SortedSet<class_3191> infos = ((WorldRendererAccessor) mc.field_1769).bbs$getBlockBreakingProgressions().get(entity.method_11016().method_10063());

        if (infos == null || infos.isEmpty())
        {
            return;
        }

        int stage = infos.last().method_13988();

        if (stage < 0 || stage >= class_1088.field_21772.size())
        {
            return;
        }

        class_4587.class_4665 entry = matrices.method_23760();
        class_4588 consumer = new class_4583(
            mc.method_22940().method_23001().getBuffer(class_1088.field_21772.get(stage)),
            entry.method_23761(), entry.method_23762(), 1F
        );

        class_238 box = entity.getShape().method_1107();
        int light = class_761.method_23794(entity.method_10997(), entity.method_11016());
        float x1 = (float) box.field_1323, y1 = (float) box.field_1322, z1 = (float) box.field_1321;
        float x2 = (float) box.field_1320, y2 = (float) box.field_1325, z2 = (float) box.field_1324;

        /* Vertices wind counter-clockwise seen from outside each face. */
        quad(consumer, entry, light, 0F, -1F, 0F, x1, y1, z1, x2, y1, z1, x2, y1, z2, x1, y1, z2);
        quad(consumer, entry, light, 0F, 1F, 0F, x1, y2, z2, x2, y2, z2, x2, y2, z1, x1, y2, z1);
        quad(consumer, entry, light, 0F, 0F, -1F, x1, y1, z1, x1, y2, z1, x2, y2, z1, x2, y1, z1);
        quad(consumer, entry, light, 0F, 0F, 1F, x2, y1, z2, x2, y2, z2, x1, y2, z2, x1, y1, z2);
        quad(consumer, entry, light, -1F, 0F, 0F, x1, y1, z2, x1, y2, z2, x1, y2, z1, x1, y1, z1);
        quad(consumer, entry, light, 1F, 0F, 0F, x2, y1, z1, x2, y2, z1, x2, y2, z2, x2, y1, z2);
    }

    private static void quad(class_4588 consumer, class_4587.class_4665 entry, int light, float nx, float ny, float nz, float... xyz)
    {
        for (int i = 0; i < 4; i++)
        {
            consumer.method_22918(entry.method_23761(), xyz[i * 3], xyz[i * 3 + 1], xyz[i * 3 + 2])
                .method_1336(255, 255, 255, 255)
                .method_22913(0F, 0F)
                .method_22922(class_4608.field_21444)
                .method_22916(light)
                .method_23763(entry.method_23762(), nx, ny, nz)
                .method_1344();
        }
    }

    @Override
    public int method_33893()
    {
        return 512;
    }

    private boolean canRenderAxes(ModelBlockEntity entity)
    {
        if (UIScreen.getCurrentMenu() instanceof UIDashboard dashboard)
        {
            if (dashboard.getPanels().panel instanceof UIModelBlockPanel modelBlockPanel)
            {
                /* The selected block shows the interactive gizmo instead of the plain axes. */
                return !modelBlockPanel.isShowingGizmo(entity);
            }
        }

        return false;
    }

    private boolean canRender(ModelBlockEntity entity)
    {
        if (!entity.getProperties().isEnabled())
        {
            return false;
        }

        if (!BBSSettings.renderAllModelBlocks.get())
        {
            return false;
        }

        if (UIScreen.getCurrentMenu() instanceof UIDashboard dashboard)
        {
            if (dashboard.getPanels().panel instanceof UIModelBlockPanel modelBlockPanel)
            {
                return !modelBlockPanel.isEditing(entity) || modelBlockPanel.isRenderingToggled();
            }
        }

        return true;
    }
}