package mchorse.bbs_mod.forms.renderers;

import com.mojang.blaze3d.systems.RenderSystem;
import mchorse.bbs_mod.BBSModClient;
import mchorse.bbs_mod.client.BBSRendering;
import mchorse.bbs_mod.client.BBSShaders;
import mchorse.bbs_mod.forms.FormTranslucentQueue;
import mchorse.bbs_mod.forms.forms.BillboardForm;
import mchorse.bbs_mod.forms.renderers.utils.FormColorBlend;
import mchorse.bbs_mod.forms.renderers.utils.FormOverlay;
import mchorse.bbs_mod.forms.renderers.utils.FramebufferDebug;
import mchorse.bbs_mod.utils.colors.OverlayBlend;
import mchorse.bbs_mod.graphics.texture.Texture;
import mchorse.bbs_mod.resources.Link;
import mchorse.bbs_mod.ui.framework.UIContext;
import mchorse.bbs_mod.utils.MathUtils;
import mchorse.bbs_mod.utils.MatrixStackUtils;
import mchorse.bbs_mod.utils.Quad;
import mchorse.bbs_mod.utils.colors.Color;
import mchorse.bbs_mod.utils.colors.Colors;
import mchorse.bbs_mod.utils.joml.Vectors;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_291;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_5944;
import net.minecraft.class_757;
import net.minecraft.class_765;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL13;

import java.util.function.Supplier;

public class BillboardFormRenderer <T extends BillboardForm> extends FormRenderer<T>
{
    private static final Quad quad = new Quad();
    private static final Quad uvQuad = new Quad();

    private static final Matrix4f matrix = new Matrix4f();

    public BillboardFormRenderer(T form)
    {
        super(form);
    }

    @Override
    public void renderInUI(UIContext context, int x1, int y1, int x2, int y2)
    {
        class_4587 stack = context.batcher.getContext().method_51448();

        stack.method_22903();

        Matrix4f uiMatrix = ModelFormRenderer.getUIMatrix(context, x1, y1, x2, y2);

        this.applyTransforms(uiMatrix, context.getTransition());
        MatrixStackUtils.multiply(stack, uiMatrix);
        stack.method_46416(0F, 1F, 0F);
        stack.method_22905(1.5F, 1.5F, 1.5F);
        stack.method_22905(this.form.uiScale.get(), this.form.uiScale.get(), this.form.uiScale.get());

        class_293 format = class_290.field_1580;

        this.renderModel(format, class_757::method_34508,
            stack,
            class_4608.field_21444, class_765.field_32767, Colors.WHITE,
            context.getTransition(), false
        );

        stack.method_22909();
    }

    @Override
    public void render3D(FormRenderingContext context)
    {
        boolean shading = this.form.shading.get();

        if (BBSRendering.isIrisShadersEnabled())
        {
            shading = true;
        }

        class_293 format = shading ? class_290.field_1580 : class_290.field_1586;
        Supplier<class_5944> shader = this.getShader(context,
            shading ? class_757::method_34508 : class_757::method_35764,
            shading ? BBSShaders::getPickerBillboardProgram : BBSShaders::getPickerBillboardNoShadingProgram
        );

        this.renderModel(format, shader, context.stack, context.overlay, context.light, context.color, context.getTransition(), !context.isPicking());
    }

    /**
     * The texture the quad wears. The video form's renderer swaps this for a
     * decoded video frame; everything else about the quad stays shared.
     */
    protected Texture getTexture()
    {
        Link t = this.form.texture.get();

        return t == null ? null : BBSModClient.getTextures().getTexture(t);
    }

    private void renderModel(class_293 format, Supplier<class_5944> shader, class_4587 matrices, int overlay, int light, int overlayColor, float transition, boolean defer)
    {
        Texture texture = this.getTexture();

        if (texture == null)
        {
            return;
        }

        float w = texture.width;
        float h = texture.height;
        float ow = w;
        float oh = h;

        /* TL = top left, BR = bottom right*/
        Vector4f crop = this.form.crop.get();
        float uvTLx = crop.x / w;
        float uvTLy = crop.y / h;
        float uvBRx = 1 - crop.z / w;
        float uvBRy = 1 - crop.w / h;

        uvQuad.p1.set(uvTLx, uvTLy, 0);
        uvQuad.p2.set(uvBRx, uvTLy, 0);
        uvQuad.p3.set(uvTLx, uvBRy, 0);
        uvQuad.p4.set(uvBRx, uvBRy, 0);

        float uvFinalTLx = uvTLx;
        float uvFinalTLy = uvTLy;
        float uvFinalBRx = uvBRx;
        float uvFinalBRy = uvBRy;

        if (this.form.resizeCrop.get())
        {
            uvFinalTLx = uvFinalTLy = 0F;
            uvFinalBRx = uvFinalBRy = 1F;

            w = w - crop.x - crop.z;
            h = h - crop.y - crop.w;
        }

        /* Calculate quad's size (vertices, not UV) */
        float ratioX = w > h ? h / w : 1F;
        float ratioY = h > w ? w / h : 1F;
        float TLx = (uvFinalTLx - 0.5F) * ratioY;
        float TLy = -(uvFinalTLy - 0.5F) * ratioX;
        float BRx = (uvFinalBRx - 0.5F) * ratioY;
        float BRy = -(uvFinalBRy - 0.5F) * ratioX;

        quad.p1.set(TLx, TLy, 0);
        quad.p2.set(BRx, TLy, 0);
        quad.p3.set(TLx, BRy, 0);
        quad.p4.set(BRx, BRy, 0);

        float offsetX = this.form.offsetX.get();
        float offsetY = this.form.offsetY.get();
        float rotation = this.form.rotation.get();

        if (offsetX != 0F || offsetY != 0F || rotation != 0F)
        {
            float centerX = (crop.x + (ow - crop.z)) / 2F / ow;
            float centerY = (crop.y + (oh - crop.w)) / 2F / ow;

            matrix.identity()
                .translate(centerX, centerY, 0)
                .rotateZ(MathUtils.toRad(rotation))
                .translate(offsetX / ow, offsetY / oh, 0)
                .translate(-centerX, -centerY, 0);

            uvQuad.transform(matrix);
        }

        this.renderQuad(format, texture, shader, matrices, overlay, light, overlayColor, transition, defer);
    }

    private void renderQuad(class_293 format, Texture texture, Supplier<class_5944> shader, class_4587 matrices, int overlay, int light, int overlayColor, float transition, boolean defer)
    {
        class_287 builder = class_289.method_1348().method_1349();
        Color color = new Color().set(overlayColor, true);
        Matrix4f matrix = matrices.method_23760().method_23761();
        Matrix3f normal = matrices.method_23760().method_23762();

        FormColorBlend.blend(color, this.form.color.get());

        if (this.form.billboard.get())
        {
            Matrix4f modelMatrix = matrices.method_23760().method_23761();
            Vector3f scale = Vectors.TEMP_3F;

            modelMatrix.getScale(scale);

            modelMatrix.m00(1).m01(0).m02(0);
            modelMatrix.m10(0).m11(1).m12(0);
            modelMatrix.m20(0).m21(0).m22(1);

            modelMatrix.scale(scale);

            matrices.method_23760().method_23762().identity();
        }

        class_757 gameRenderer = class_310.method_1551().field_1773;

        gameRenderer.method_22974().method_3316();
        gameRenderer.method_22975().method_23209();

        /* The color overlay rides the overlay-texture channel, so it needs the shaded format
         * (the no-shading format has no overlay UV) and steps aside for a hurt flash. Picker
         * programs don't sample unit 1, so this is inert while picking. */
        Color formOverlay = this.form.overlayColor.get();
        boolean overlayActive = format == class_290.field_1580
            && overlay == class_4608.field_21444
            && OverlayBlend.isActive(formOverlay);
        int previousOverlayTexture = overlayActive ? FormOverlay.bind(formOverlay) : 0;

        if (overlayActive)
        {
            overlay = 0;
        }

        class_5944 finalShader = shader.get();

        BBSModClient.getTextures().bindTexture(texture);
        RenderSystem.setShader(() -> finalShader);

        if (FramebufferDebug.inside())
        {
            FramebufferDebug.log("billboard", "shader=" + FramebufferDebug.shader(finalShader)
                + " shaded=" + (format == class_290.field_1580)
                + " texture=" + texture.id + "/translucent=" + texture.hasTranslucency() + " alpha=" + color.a
                + " light=" + light + " overlayActive=" + overlayActive + " defer=" + defer
                + " | " + FramebufferDebug.bindings());
        }

        /* Filter parameters go to whichever texture is bound on the ACTIVE unit, and nothing
         * promises that unit is 0 here: under a shader pack it is whatever unit Iris touched
         * last (unit 2 in practice). A raw bind there put this texture over the lightmap's slot
         * behind GlStateManager's back - its cache still said the lightmap was bound, so the
         * draw never rebound it, and the quad was lit by a texel of its own skin. Going through
         * RenderSystem keeps the real binding and the cache in step, on unit 0, on purpose. */
        RenderSystem.activeTexture(GL13.GL_TEXTURE0);
        RenderSystem.bindTexture(texture.id);
        texture.setFilterMipmap(this.form.linear.get(), this.form.mipmap.get());
        builder.method_1328(class_293.class_5596.field_27379, format);

        /* Front */
        this.fill(format, builder, matrix, quad.p3.x, quad.p3.y, color, uvQuad.p3.x, uvQuad.p3.y, overlay, light, normal, 1F).method_1344();
        this.fill(format, builder, matrix, quad.p2.x, quad.p2.y, color, uvQuad.p2.x, uvQuad.p2.y, overlay, light, normal, 1F).method_1344();
        this.fill(format, builder, matrix, quad.p1.x, quad.p1.y, color, uvQuad.p1.x, uvQuad.p1.y, overlay, light, normal, 1F).method_1344();

        this.fill(format, builder, matrix, quad.p3.x, quad.p3.y, color, uvQuad.p3.x, uvQuad.p3.y, overlay, light, normal, 1F).method_1344();
        this.fill(format, builder, matrix, quad.p4.x, quad.p4.y, color, uvQuad.p4.x, uvQuad.p4.y, overlay, light, normal, 1F).method_1344();
        this.fill(format, builder, matrix, quad.p2.x, quad.p2.y, color, uvQuad.p2.x, uvQuad.p2.y, overlay, light, normal, 1F).method_1344();

        /* Back */
        this.fill(format, builder, matrix, quad.p1.x, quad.p1.y, color, uvQuad.p1.x, uvQuad.p1.y, overlay, light, normal, -1F).method_1344();
        this.fill(format, builder, matrix, quad.p2.x, quad.p2.y, color, uvQuad.p2.x, uvQuad.p2.y, overlay, light, normal, -1F).method_1344();
        this.fill(format, builder, matrix, quad.p3.x, quad.p3.y, color, uvQuad.p3.x, uvQuad.p3.y, overlay, light, normal, -1F).method_1344();

        this.fill(format, builder, matrix, quad.p2.x, quad.p2.y, color, uvQuad.p2.x, uvQuad.p2.y, overlay, light, normal, -1F).method_1344();
        this.fill(format, builder, matrix, quad.p4.x, quad.p4.y, color, uvQuad.p4.x, uvQuad.p4.y, overlay, light, normal, -1F).method_1344();
        this.fill(format, builder, matrix, quad.p3.x, quad.p3.y, color, uvQuad.p3.x, uvQuad.p3.y, overlay, light, normal, -1F).method_1344();

        RenderSystem.defaultBlendFunc();
        RenderSystem.enableBlend();

        boolean linear = this.form.linear.get();
        boolean mipmap = this.form.mipmap.get();
        boolean translucent = texture.hasTranslucency() || color.a < 1F || linear || mipmap;

        if (defer && translucent && FormTranslucentQueue.isActive())
        {
            /* The whole quad defers to the end-of-frame translucent pass: depth testing still
             * hides it behind opaque geometry, while the far-to-near sort blends it correctly
             * against other translucent forms — and it never occludes models behind it.
             * Linear/mipmap sampling manufactures fractional alpha at the edges even from a
             * binary-alpha texture, hence those flags count as translucency. */
            class_291 buffer = new class_291(class_291.class_8555.field_44793);

            buffer.method_1353();
            buffer.method_1352(builder.method_1326());
            class_291.method_1354();

            Matrix4f modelView = new Matrix4f(RenderSystem.getModelViewMatrix());
            Vector3f origin = modelView.transformPosition(matrix.getTranslation(new Vector3f()));
            Vector3f planeNormal = FormTranslucentQueue.quadPlaneNormal(modelView, matrix);

            FormTranslucentQueue.add(new FormTranslucentQueue.VertexBufferCommand(
                buffer, () -> finalShader, texture, modelView, null, origin, planeNormal, true,
                () ->
                {
                    RenderSystem.activeTexture(GL13.GL_TEXTURE0);
                    RenderSystem.bindTexture(texture.id);
                    texture.setFilterMipmap(linear, mipmap);
                },
                () ->
                {
                    RenderSystem.activeTexture(GL13.GL_TEXTURE0);
                    RenderSystem.bindTexture(texture.id);
                    texture.setFilterMipmap(false, false);
                }
            ).overlayColor(overlayActive ? formOverlay : null));
        }
        else
        {
            class_286.method_43433(builder.method_1326());
        }

        if (FramebufferDebug.inside())
        {
            FramebufferDebug.log("billboard", "after draw | " + FramebufferDebug.bindings());
            FramebufferDebug.log("billboard", "after draw | " + FramebufferDebug.glState());
            FramebufferDebug.log("billboard", "after draw | " + FramebufferDebug.samplers());
        }

        RenderSystem.activeTexture(GL13.GL_TEXTURE0);
        RenderSystem.bindTexture(texture.id);
        texture.setFilterMipmap(false, false);

        if (overlayActive)
        {
            FormOverlay.unbind(previousOverlayTexture);
        }

        gameRenderer.method_22974().method_3315();
        gameRenderer.method_22975().method_23213();
    }

    private class_4588 fill(class_293 format, class_4588 consumer, Matrix4f matrix, float x, float y, Color color, float u, float v, int overlay, int light, Matrix3f normal, float nz)
    {
        if (format == class_290.field_1586)
        {
            return consumer.method_22918(matrix, x, y, 0F).method_22913(u, v).method_22916(light).method_22915(color.r, color.g, color.b, color.a);
        }

        return consumer.method_22918(matrix, x, y, 0F).method_22915(color.r, color.g, color.b, color.a).method_22913(u, v).method_22922(overlay).method_22916(light).method_23763(normal, 0F, 0F, nz);
    }
}
