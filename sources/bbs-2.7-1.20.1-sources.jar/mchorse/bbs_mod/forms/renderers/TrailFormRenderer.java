package mchorse.bbs_mod.forms.renderers;

import com.mojang.blaze3d.systems.RenderSystem;
import mchorse.bbs_mod.BBSModClient;
import mchorse.bbs_mod.BBSSettings;
import mchorse.bbs_mod.camera.Camera;
import mchorse.bbs_mod.client.BBSRendering;
import mchorse.bbs_mod.forms.ITickable;
import mchorse.bbs_mod.forms.entities.IEntity;
import mchorse.bbs_mod.forms.forms.TrailForm;
import mchorse.bbs_mod.graphics.Draw;
import mchorse.bbs_mod.graphics.texture.Texture;
import mchorse.bbs_mod.ui.framework.UIContext;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import org.joml.Matrix4f;
import org.joml.Vector3d;
import org.joml.Vector3f;
import org.joml.Vector4f;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class TrailFormRenderer extends FormRenderer<TrailForm> implements ITickable
{
    private int tick;
    private final Map<FormRenderType, ArrayDeque<Trail>> record = new HashMap<>();

    public TrailFormRenderer(TrailForm form)
    {
        super(form);
    }

    @Override
    protected void renderInUI(UIContext context, int x1, int y1, int x2, int y2)
    {
        Texture texture = context.render.getTextures().getTexture(this.form.texture.get());

        float min = Math.min(texture.width, texture.height);
        int ow = (x2 - x1) - 4;
        int oh = (y2 - y1) - 4;

        int w = (int) ((texture.width / min) * ow);
        int h = (int) ((texture.height / min) * ow);

        int x = x1 + (ow - w) / 2 + 2;
        int y = y1 + (oh - h) / 2 + 2;

        context.batcher.fullTexturedBox(texture, x, y, w, h);
    }

    @Override
    protected void render3D(FormRenderingContext context)
    {
        super.render3D(context);

        if (BBSRendering.isIrisShadowPass() || context.type == FormRenderType.ITEM_INVENTORY)
        {
            return;
        }

        if (context.modelRenderer || context.ui)
        {
            class_4587 stack = context.stack;
            float scale = BBSSettings.axesScale.get();
            float axisSize = 1F;
            float axisOffset = 0.01F;
            float outlineSize = 1.01F;
            float outlineOffset = 0.02F;

            axisOffset *= scale;
            outlineOffset *= scale;

            class_287 builder = class_289.method_1348().method_1349();

            builder.method_1328(class_293.class_5596.field_27379, class_290.field_1576);

            Draw.fillBox(builder, stack, -outlineOffset, -outlineSize, -outlineOffset, outlineOffset, outlineSize, outlineOffset, 0, 0, 0);
            Draw.fillBox(builder, stack, -axisOffset, -axisSize, -axisOffset, axisOffset, axisSize, axisOffset, 0, 1, 0);

            RenderSystem.setShader(class_757::method_34540);
            RenderSystem.disableDepthTest();

            class_286.method_43433(builder.method_1326());

            return;
        }

        if (!BBSRendering.isRenderingWorld())
        {
            return;
        }

        class_4587 stack = context.stack;
        Matrix4f camInverse = new Matrix4f(RenderSystem.getInverseViewRotationMatrix());

        Camera camera = context.camera;
        double baseX = camera.position.x;
        double baseY = camera.position.y;
        double baseZ = camera.position.z;

        float current = (float) this.tick + context.transition;
        ArrayDeque<Trail> trails = this.record.computeIfAbsent(context.type, (k) -> new ArrayDeque<>());

        if (!this.form.paused.get())
        {
            Matrix4f modelView = stack.method_23760().method_23761();

            Vector4f top = new Vector4f(0F, 1F, 0F, 1F);
            Vector4f bottom = new Vector4f(0F, -1F, 0F, 1F);

            modelView.transform(top);
            modelView.transform(bottom);
            camInverse.transform(top);
            camInverse.transform(bottom);

            top.mul(1F / top.w);
            bottom.mul(1F / bottom.w);

            Trail record = new Trail();

            record.tick = current;
            record.top = new Vector3d(top.x + baseX, top.y + baseY, top.z + baseZ);
            record.bottom = new Vector3d(bottom.x + baseX, bottom.y + baseY, bottom.z + baseZ);
            record.stop = new Vector3f(top.x - bottom.x, top.y - bottom.y, top.z - bottom.z).lengthSquared() < 1.0E-4D;

            trails.addLast(record);
        }

        boolean loop = this.form.loop.get();
        float length = this.form.length.get();
        float end = current - length;
        Iterator<Trail> it = trails.iterator();
        boolean render = false;
        boolean lastStop = true;

        while (it.hasNext())
        {
            Trail trail = it.next();

            if (trail.tick < end)
            {
                it.remove();
            }
            else
            {
                render |= !trail.stop && !lastStop;
                lastStop = trail.stop;
            }
        }

        if (!render || trails.size() <= 1 || !(length > 0.001D))
        {
            return;
        }

        BBSModClient.getTextures().bindTexture(this.form.texture.get());

        stack.method_22903();

        Trail last = null;
        Trail trail;
        class_287 builder = class_289.method_1348().method_1349();
        Matrix4f m = stack.method_23760().method_23761();

        m.set(camInverse);
        m.invert();

        builder.method_1328(class_293.class_5596.field_27382, class_290.field_1585);

        for (it = trails.iterator(); it.hasNext(); last = trail)
        {
            trail = it.next();

            if (last != null && !last.stop && !trail.stop)
            {
                double x1 = trail.top.x - baseX;
                double x2 = trail.bottom.x - baseX;
                double x3 = last.bottom.x - baseX;
                double x4 = last.top.x - baseX;

                double y1 = trail.top.y - baseY;
                double y2 = trail.bottom.y - baseY;
                double y3 = last.bottom.y - baseY;
                double y4 = last.top.y - baseY;

                double z1 = trail.top.z - baseZ;
                double z2 = trail.bottom.z - baseZ;
                double z3 = last.bottom.z - baseZ;
                double z4 = last.top.z - baseZ;

                if (loop)
                {
                    float u1 = trail.tick / length;
                    float u2 = last.tick / length;

                    builder.method_22918(m, (float) x1, (float) y1, (float) z1).method_22913(u1, 0F).method_1344();
                    builder.method_22918(m, (float) x2, (float) y2, (float) z2).method_22913(u1, 1F).method_1344();
                    builder.method_22918(m, (float) x3, (float) y3, (float) z3).method_22913(u2, 1F).method_1344();
                    builder.method_22918(m, (float) x4, (float) y4, (float) z4).method_22913(u2, 0F).method_1344();
                    /* Other side */
                    builder.method_22918(m, (float) x4, (float) y4, (float) z4).method_22913(u2, 0F).method_1344();
                    builder.method_22918(m, (float) x3, (float) y3, (float) z3).method_22913(u2, 1F).method_1344();
                    builder.method_22918(m, (float) x2, (float) y2, (float) z2).method_22913(u1, 1F).method_1344();
                    builder.method_22918(m, (float) x1, (float) y1, (float) z1).method_22913(u1, 0F).method_1344();
                }
                else
                {
                    float u1 = (current - trail.tick) / length;
                    float u2 = (current - last.tick) / length;

                    builder.method_22918(m, (float) x1, (float) y1, (float) z1).method_22913(u1, 0F).method_1344();
                    builder.method_22918(m, (float) x2, (float) y2, (float) z2).method_22913(u1, 1F).method_1344();
                    builder.method_22918(m, (float) x3, (float) y3, (float) z3).method_22913(u2, 1F).method_1344();
                    builder.method_22918(m, (float) x4, (float) y4, (float) z4).method_22913(u2, 0F).method_1344();
                    /* Other side */
                    builder.method_22918(m, (float) x4, (float) y4, (float) z4).method_22913(u2, 0F).method_1344();
                    builder.method_22918(m, (float) x3, (float) y3, (float) z3).method_22913(u2, 1F).method_1344();
                    builder.method_22918(m, (float) x2, (float) y2, (float) z2).method_22913(u1, 1F).method_1344();
                    builder.method_22918(m, (float) x1, (float) y1, (float) z1).method_22913(u1, 0F).method_1344();
                }
            }
            else
            {
                length = current - trail.tick;
            }
        }

        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableBlend();
        class_286.method_43433(builder.method_1326());
        RenderSystem.enableDepthTest();

        stack.method_22909();
    }

    @Override
    public void tick(IEntity entity)
    {
        this.tick += 1;
    }

    public static class Trail
    {
        public float tick;
        public Vector3d top;
        public Vector3d bottom;
        public boolean stop;
    }
}