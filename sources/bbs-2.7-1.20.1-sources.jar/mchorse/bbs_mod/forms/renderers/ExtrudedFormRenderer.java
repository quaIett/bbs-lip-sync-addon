package mchorse.bbs_mod.forms.renderers;

import com.mojang.blaze3d.systems.RenderSystem;
import mchorse.bbs_mod.BBSModClient;
import mchorse.bbs_mod.client.BBSRendering;
import mchorse.bbs_mod.client.BBSShaders;
import mchorse.bbs_mod.cubic.render.vao.ModelVAO;
import mchorse.bbs_mod.cubic.render.vao.ModelVAORenderer;
import mchorse.bbs_mod.forms.FormTranslucentQueue;
import mchorse.bbs_mod.forms.forms.ExtrudedForm;
import mchorse.bbs_mod.graphics.texture.Texture;
import mchorse.bbs_mod.forms.renderers.utils.FormColorBlend;
import mchorse.bbs_mod.resources.Link;
import mchorse.bbs_mod.ui.framework.UIContext;
import mchorse.bbs_mod.utils.MatrixStackUtils;
import mchorse.bbs_mod.utils.colors.Color;
import mchorse.bbs_mod.utils.colors.Colors;
import mchorse.bbs_mod.utils.joml.Vectors;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_5944;
import net.minecraft.class_757;
import net.minecraft.class_765;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.lwjgl.opengl.GL11;

import java.util.function.Supplier;

public class ExtrudedFormRenderer extends FormRenderer<ExtrudedForm>
{
    public ExtrudedFormRenderer(ExtrudedForm form)
    {
        super(form);
    }

    @Override
    public void renderInUI(UIContext context, int x1, int y1, int x2, int y2)
    {
        class_4587 stack = context.batcher.getContext().method_51448();

        stack.method_22903();

        Matrix4f uiMatrix = ModelFormRenderer.getUIMatrix(context, x1, y1, x2, y2);

        this.applyTransforms(uiMatrix, context.getTransition());
        MatrixStackUtils.multiply(stack, uiMatrix);
        stack.method_46416(0F, 1F, 0F);
        stack.method_22905(1.5F, 1.5F, 4F);
        stack.method_22905(this.form.uiScale.get(), this.form.uiScale.get(), this.form.uiScale.get());

        /* Shading fix */
        stack.method_23760().method_23762().getScale(Vectors.EMPTY_3F);
        stack.method_23760().method_23762().scale(1F / Vectors.EMPTY_3F.x, -1F / Vectors.EMPTY_3F.y, 1F / Vectors.EMPTY_3F.z);

        RenderSystem.depthFunc(GL11.GL_LEQUAL);
        this.renderModel(BBSShaders::getModel,
            stack,
            class_4608.field_21444, class_765.field_32767, Colors.WHITE,
            context.getTransition(), false
        );
        RenderSystem.depthFunc(GL11.GL_ALWAYS);

        stack.method_22909();
    }

    @Override
    protected void render3D(FormRenderingContext context)
    {
        boolean shading = this.form.shading.get();

        if (BBSRendering.isIrisShadersEnabled())
        {
            shading = true;
        }

        class_293 format = shading ? class_290.field_1580 : class_290.field_1586;
        Supplier<class_5944> normal = shading && !BBSRendering.isIrisShadersEnabled()
            ? BBSShaders::getModel
            : (shading ? class_757::method_34508 : class_757::method_35764);
        Supplier<class_5944> shader = this.getShader(context,
            normal,
            shading ? BBSShaders::getPickerBillboardProgram : BBSShaders::getPickerBillboardNoShadingProgram
        );

        this.renderModel(shader, context.stack, context.overlay, context.light, context.color, context.getTransition(), !context.isPicking());
    }

    private void renderModel(Supplier<class_5944> shader, class_4587 matrices, int overlay, int light, int overlayColor, float transition, boolean defer)
    {
        Link texture = this.form.texture.get();
        ModelVAO data = BBSModClient.getTextures().getExtruder().get(texture);

        if (data != null)
        {
            if (this.form.billboard.get())
            {
                Matrix4f modelMatrix = matrices.method_23760().method_23761();
                Vector3f scale = Vectors.TEMP_3F;

                modelMatrix.getScale(scale);

                modelMatrix.m00(1).m01(0).m02(0);
                modelMatrix.m10(0).m11(1).m12(0);
                modelMatrix.m20(0).m21(0).m22(1);

                modelMatrix.scale(scale);

                matrices.method_23760().method_23762().identity();
            }

            Color color = Colors.COLOR.set(overlayColor, true);
            class_757 gameRenderer = class_310.method_1551().field_1773;
            Color formColor = this.form.color.get();

            FormColorBlend.blend(color, formColor);

            Texture textureObject = BBSModClient.getTextures().getTexture(texture);

            BBSModClient.getTextures().bindTexture(textureObject);

            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();

            gameRenderer.method_22974().method_3316();
            gameRenderer.method_22975().method_23209();

            boolean irisWorld = BBSRendering.isIrisShadersEnabled() && BBSRendering.isRenderingWorld();

            /* Same law as model forms under Iris: the draw always runs right now, in the phase
             * its program is meant for (the end-of-frame replay lands after a deferred pack's
             * shading composite — Photon never shades it), and texture translucency at full
             * colour degrades to alpha cutout — transparent texels become holes, semi-transparent
             * ones draw solid. */
            boolean cutout = defer && irisWorld && textureObject != null && textureObject.hasTranslucency()
                && color.a >= 1F;

            class_5944 finalShader = cutout ? class_757.method_34503() : shader.get();
            boolean wasActive = false;

            if (irisWorld)
            {
                wasActive = FormTranslucentQueue.suspend();
            }

            if (cutout)
            {
                RenderSystem.disableBlend();
            }

            try
            {
                if (defer && FormTranslucentQueue.needsSplit(finalShader, null, textureObject, color.a))
                {
                    Matrix4f modelView = ModelVAORenderer.captureModelView(matrices);
                    Matrix3f normalMat = new Matrix3f(matrices.method_23760().method_23762());

                    FormTranslucentQueue.setPassMode(finalShader, FormTranslucentQueue.PASS_OPAQUE);
                    ModelVAORenderer.render(finalShader, data, modelView, normalMat, color.r, color.g, color.b, color.a, light, overlay);
                    FormTranslucentQueue.setPassMode(finalShader, FormTranslucentQueue.PASS_SINGLE);

                    FormTranslucentQueue.add(new FormTranslucentQueue.ModelVAOCommand(data, textureObject, modelView, normalMat, color.r, color.g, color.b, color.a, light, overlay, true));
                }
                else if (defer && FormTranslucentQueue.needsWholeDefer(finalShader, null, color.a))
                {
                    /* A uniform colour fade defers the whole draw into the sorted end-of-frame
                     * pass with depth kept on, so the faded form still self-occludes. */
                    Matrix4f modelView = ModelVAORenderer.captureModelView(matrices);
                    Matrix3f normalMat = new Matrix3f(matrices.method_23760().method_23762());

                    FormTranslucentQueue.add(new FormTranslucentQueue.ModelVAOCommand(data, () -> finalShader, FormTranslucentQueue.PASS_SINGLE, true, textureObject, modelView, normalMat, color.r, color.g, color.b, color.a, light, overlay, true));
                }
                else
                {
                    ModelVAORenderer.render(finalShader, data, matrices, color.r, color.g, color.b, color.a, light, overlay);
                }
            }
            finally
            {
                if (irisWorld)
                {
                    FormTranslucentQueue.restore(wasActive);
                }
            }

            RenderSystem.disableBlend();

            gameRenderer.method_22974().method_3315();
            gameRenderer.method_22975().method_23213();
        }
    }
}
