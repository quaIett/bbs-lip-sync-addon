package mchorse.bbs_mod.forms.renderers.mob;

import mchorse.bbs_mod.forms.renderers.utils.MatrixCache;
import mchorse.bbs_mod.mixin.client.LivingEntityRendererInvoker;
import mchorse.bbs_mod.utils.pose.Pose;
import mchorse.bbs_mod.utils.pose.Transform;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_630;
import net.minecraft.class_922;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

import java.util.IdentityHashMap;
import java.util.Map;

/**
 * Where a mob form's bones are, in the form's own space.
 *
 * <p>The one place the space convention lives. Vanilla walks from the form's stack through
 * {@code setupTransforms} (which yaws by {@code 180 - bodyYaw}, and the form pins body yaw to zero)
 * and then {@code scale(-1, -1, 1)}, so the model's frame ends up turned 180 degrees about X
 * relative to the form: Y down, Z backwards. Turning it back by 180 degrees about Z lands it where
 * the model form's bones already are — the same frame {@code renderBodyParts} falls back to when it
 * has no matrix for a bone (a plain 180 degree yaw), so a body part behaves the same whichever kind
 * of form it hangs off.</p>
 *
 * <p>The correction is written as a {@code scale(-1, -1, 1)} rather than a {@code rotateZ(PI)}
 * because it is exactly that matrix, with no sine-of-pi residue. Its determinant is +1: this is a
 * rotation, not a mirror, so an attached form is not flipped.</p>
 */
public class MobRigMatrices
{
    /**
     * Records one part, given the frame vanilla was on BEFORE the part posed itself (the parent's
     * frame, i.e. the stack at the head of {@code ModelPart.rotate}). The part's own pivot,
     * rotation and scale are re-applied here instead of being read back out of a captured matrix,
     * which keeps both flavours the cache wants — the frame at the pivot before the bone rotates,
     * and the full one — exact and inverse-free.
     */
    public static void put(MatrixCache cache, Matrix4f baseInverse, String bone, class_630 part, Matrix4f parent)
    {
        Matrix4f origin = new Matrix4f(baseInverse).mul(parent);

        origin.translate(part.field_3657 / 16F, part.field_3656 / 16F, part.field_3655 / 16F);

        Matrix4f matrix = new Matrix4f(origin);

        if (part.field_3654 != 0F || part.field_3675 != 0F || part.field_3674 != 0F)
        {
            matrix.rotate(new Quaternionf().rotationZYX(part.field_3674, part.field_3675, part.field_3654));
        }

        if (part.field_37938 != 1F || part.field_37939 != 1F || part.field_37940 != 1F)
        {
            matrix.scale(part.field_37938, part.field_37939, part.field_37940);
        }

        matrix.scale(-1F, -1F, 1F);
        origin.scale(-1F, -1F, 1F);

        cache.put(bone, matrix, origin);
    }

    /**
     * Where every bone sits WITHOUT rendering anything.
     *
     * <p>The gizmo, the anchor system, trackers and the motion path all ask a form for its bone
     * matrices several times a frame, at arbitrary ticks, and treat the call as a question rather
     * than a draw. So this replays vanilla's own preamble — angles, then the transform chain the
     * living entity renderer sets up — and walks the part tree for matrices, instead of running a
     * second {@code EntityRenderDispatcher.render} that would re-enter item and armor rendering
     * and touch GL state from inside what the callers think is a read.</p>
     *
     * <p>Model parts are shared with the world's real entities, so everything written here is put
     * back in a finally. It also refuses to run while an entity render is in flight, which is the
     * one moment those writes would be seen by someone else.</p>
     */
    public static void evaluate(class_1297 entity, MobRig rig, Pose pose, Pose poseOverlay, float transition, MatrixCache cache)
    {
        class_922 renderer = VanillaPose.renderer(entity);

        if (rig == null || renderer == null)
        {
            return;
        }

        class_1309 living = (class_1309) entity;
        LivingEntityRendererInvoker invoker = (LivingEntityRendererInvoker) renderer;
        Map<class_630, Transform> saved = new IdentityHashMap<>();
        float bodyYaw = class_3532.method_17821(transition, living.field_6220, living.field_6283);
        float animationProgress = invoker.bbs$getAnimationCounter(living, transition);

        try
        {
            VanillaPose.animate(renderer, living, transition);

            MobPoseApplier.apply(rig, MobPoseApplier.merge(pose, poseOverlay), saved);

            class_4587 stack = new class_4587();

            /* Since 1.21.1 the entity carries a scale attribute: vanilla scales the stack by it
             * and hands it to setupTransforms, so the rig has to walk the same chain. */
            float entityScale = living.method_55693();

            stack.method_22905(entityScale, entityScale, entityScale);
            invoker.bbs$setupTransforms(living, stack, animationProgress, bodyYaw, transition, entityScale);
            stack.method_22905(-1F, -1F, 1F);
            invoker.bbs$scale(living, stack, transition);
            stack.method_46416(0F, -1.501F, 0F);

            Matrix4f baseInverse = new Matrix4f();

            for (String root : rig.getRootGroupKeys())
            {
                walk(cache, baseInverse, rig, stack, rig.part(root));
            }
        }
        finally
        {
            MobPoseApplier.restore(saved);
        }
    }

    /**
     * The same descent {@code ModelPart.render} makes, minus the drawing — including its two
     * early-outs, so a bone that would not be drawn does not get a matrix here either and the two
     * paths agree on which bones exist.
     */
    private static void walk(MatrixCache cache, Matrix4f baseInverse, MobRig rig, class_4587 stack, class_630 part)
    {
        if (part == null || !part.field_3665)
        {
            return;
        }

        Map<String, class_630> children = IBBSModelPart.of(part).bbs$children();

        if (part.method_32087() && children.isEmpty())
        {
            return;
        }

        String bone = rig.name(part);

        if (bone != null)
        {
            put(cache, baseInverse, bone, part, stack.method_23760().method_23761());
        }

        stack.method_22903();
        part.method_22703(stack);

        for (class_630 child : children.values())
        {
            walk(cache, baseInverse, rig, stack, child);
        }

        stack.method_22909();
    }
}
