package mchorse.bbs_mod.forms.renderers.mob;

import net.minecraft.class_4588;

/**
 * A pass-through vertex consumer whose only job is to be unrecognisable to Sodium.
 *
 * <p>Sodium accelerates entity rendering by injecting into {@code ModelPart.render}: it converts
 * the consumer to its own {@code VertexBufferWriter}, CANCELS the vanilla method and draws the
 * whole subtree itself from a copied part tree — passing one light value down to every part it
 * draws. That is fatal to per-bone picking, which is exactly a per-part light value, and it also
 * means vanilla's own recursion (and therefore any hook on it) never runs.
 *
 * <p>Sodium's conversion returns null for a consumer it doesn't know, and it then declines instead
 * of cancelling. So for the pick pass — one entity, once, off the hot path — the buffer is handed
 * over wrapped, Sodium steps aside, and vanilla walks the parts one at a time the way the id
 * mixin needs.</p>
 */
public class MobPickerVertexConsumer implements class_4588
{
    private final class_4588 consumer;

    public MobPickerVertexConsumer(class_4588 consumer)
    {
        this.consumer = consumer;
    }

    @Override
    public class_4588 method_22912(float x, float y, float z)
    {
        return this.consumer.method_22912(x, y, z);
    }

    @Override
    public class_4588 method_1336(int red, int green, int blue, int alpha)
    {
        return this.consumer.method_1336(red, green, blue, alpha);
    }

    @Override
    public class_4588 method_22913(float u, float v)
    {
        return this.consumer.method_22913(u, v);
    }

    @Override
    public class_4588 method_60796(int u, int v)
    {
        return this.consumer.method_60796(u, v);
    }

    @Override
    public class_4588 method_22921(int u, int v)
    {
        return this.consumer.method_22921(u, v);
    }

    @Override
    public class_4588 method_22914(float x, float y, float z)
    {
        return this.consumer.method_22914(x, y, z);
    }
}
