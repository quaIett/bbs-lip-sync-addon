package mchorse.bbs_mod.forms.renderers.mob;

import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.StringReader;
import mchorse.bbs_mod.forms.entities.EntityState;
import mchorse.bbs_mod.forms.entities.IEntity;
import mchorse.bbs_mod.mixin.EntityInvoker;
import mchorse.bbs_mod.mixin.LimbAnimatorAccessor;
import mchorse.bbs_mod.utils.PlayerUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_2487;
import net.minecraft.class_2522;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_745;
import net.minecraft.class_7923;
import java.util.UUID;

/**
 * A vanilla entity standing in for a form's actor, so vanilla's own model code can be run for it.
 *
 * <p>The mob form renders through the game's entity renderer, and a CEM model runs the vanilla model's
 * animation under its pack's program ({@code CemVanillaStage}); both need a real {@link class_1297} of the
 * right kind that vanilla's code will accept, posed the way the form's actor is. This makes one — an
 * entity type's own instance in the client world, or a player for the player's model — and keeps it in
 * step with the actor tick by tick: the limbs, the hand swing, head and body yaw, the position, the
 * flags vanilla's animation reads, the equipment, the age. The entity is remade when what it is made
 * from changes.</p>
 */
public class MobStandIn
{
    public static final GameProfile WIDE = new GameProfile(UUID.fromString("b99a2400-28a8-4288-92dc-924beafbf756"), "McHorseYT");
    public static final GameProfile SLIM = new GameProfile(UUID.fromString("5477bd28-e672-4f87-a209-c03cf75f3606"), "osmiq");

    private class_1297 entity;

    private String lastId = "";
    private String lastNbt = "";
    private boolean lastSlim;

    private float prevHandSwing;
    private float prevYawHead;
    private float prevPitch;

    /** The entity standing in, or null while there is none — see {@link #ensure}. */
    public class_1297 entity()
    {
        return this.entity;
    }

    /**
     * The entity for an id, made on the first ask and remade when the id, the NBT or the arm width
     * changes. Null when the game has no world to make it in, or no such kind of entity: an id the
     * registry does not know is not the pig it answers with by default. The player has no entity type
     * to create from — asked for one ({@code player}), a player of the given arm width stands in.
     */
    public class_1297 ensure(String id, String nbt, boolean slim, boolean player)
    {
        if (!this.lastId.equals(id) || !this.lastNbt.equals(nbt) || slim != this.lastSlim)
        {
            this.lastId = id;
            this.lastNbt = nbt;
            this.lastSlim = slim;
            this.entity = null;
        }

        class_638 world = class_310.method_1551().field_1687;

        if (this.entity != null || world == null)
        {
            return this.entity;
        }

        class_2487 compound = new class_2487();

        try
        {
            compound = (new class_2522(new StringReader(nbt))).method_10727();
        }
        catch (Exception e)
        {}

        class_2960 identifier = class_2960.method_12829(id);
        class_1299<?> type = identifier != null && class_7923.field_41177.method_10250(identifier) ? class_7923.field_41177.method_10223(identifier) : null;

        this.entity = type == null ? null : type.method_5883(world);

        if (this.entity == null && player)
        {
            this.entity = new class_745(world, slim ? SLIM : WIDE);
            this.entity.method_5841().method_12778(PlayerUtils.ProtectedAccess.getModelParts(), (byte) 0b1111111);
        }

        if (this.entity != null)
        {
            compound.method_10582("id", id);
            this.entity.method_5651(compound);
            this.entity.field_5960 = true;
        }

        return this.entity;
    }

    /** Step the entity and bring it in line with the actor: what vanilla's animation will read off it next frame. */
    public void tick(IEntity source)
    {
        if (this.entity == null)
        {
            return;
        }

        this.entity.method_5773();

        this.entity.field_6004 = this.prevPitch;
        this.entity.field_5982 = 0F;

        if (this.entity instanceof class_1309 livingEntity)
        {
            livingEntity.field_6259 = this.prevYawHead;
            livingEntity.field_6220 = 0F;

            /* Limb swing is so ugly */
            if (livingEntity.field_42108 instanceof LimbAnimatorAccessor a && source.getLimbAnimator() instanceof LimbAnimatorAccessor b)
            {
                a.setPrevSpeed(b.getPrevSpeed());
                a.setSpeed(b.getSpeed());
                a.setPos(b.getPos());
            }

            /* Arm swing */
            float handSwingProgress = source.getHandSwingProgress(0F);

            if (handSwingProgress < this.prevHandSwing)
            {
                this.prevHandSwing = 0;
            }

            if (handSwingProgress > 0 && this.prevHandSwing == 0)
            {
                livingEntity.method_6104(class_1268.field_5808);
            }

            this.prevHandSwing = handSwingProgress;
        }

        this.entity.method_36456(0F);
        this.entity.method_5847(source.getHeadYaw() - source.getBodyYaw());
        this.entity.method_36457(source.getPitch());
        this.entity.method_5636(0F);

        this.entity.method_23327(source.getX(), source.getY(), source.getZ());
        this.entity.method_24830(source.isOnGround());
        this.entity.method_5660(source.isSneaking());
        this.entity.method_5728(source.isSprinting());
        this.entity.method_5796(source.isSwimming());
        ((EntityInvoker) this.entity).bbs$setFlag(EntityState.FALL_FLYING_FLAG, source.isFallFlying());
        this.entity.method_18380(EntityState.pose(source));

        /* Since 1.21.1 equipStack belongs to LivingEntity, not Entity */
        if (this.entity instanceof class_1309 living)
        {
            living.method_5673(class_1304.field_6173, source.getEquipmentStack(class_1304.field_6173));
            living.method_5673(class_1304.field_6171, source.getEquipmentStack(class_1304.field_6171));
            living.method_5673(class_1304.field_6169, source.getEquipmentStack(class_1304.field_6169));
            living.method_5673(class_1304.field_6174, source.getEquipmentStack(class_1304.field_6174));
            living.method_5673(class_1304.field_6172, source.getEquipmentStack(class_1304.field_6172));
            living.method_5673(class_1304.field_6166, source.getEquipmentStack(class_1304.field_6166));
        }

        this.entity.field_6012 = source.getAge();
        this.entity.field_5960 = true;

        this.prevYawHead = source.getHeadYaw() - source.getBodyYaw();
        this.prevPitch = source.getPitch();
    }
}
