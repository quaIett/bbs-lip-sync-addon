package mchorse.bbs_mod.api.client.events;

import mchorse.bbs_mod.ui.properties.PropertyGroup;
import mchorse.bbs_mod.ui.properties.PropertyGroups;

/**
 * Posted on the client once BBS has declared the property groups of its own kinds of objects.
 *
 * <p>A property group is what a properties panel shows for an object — its sections and rows.
 * An addon needs this only for a kind of object of its own making.</p>
 */
public class RegisterPropertyGroupsEvent
{
    public <T> void register(Class<T> type, PropertyGroup<T> group)
    {
        PropertyGroups.register(type, group);
    }
}
