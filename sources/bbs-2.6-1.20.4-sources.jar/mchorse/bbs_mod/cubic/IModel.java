package mchorse.bbs_mod.cubic;

import mchorse.bbs_mod.bobj.BOBJBone;
import mchorse.bbs_mod.cubic.data.animation.Animation;
import mchorse.bbs_mod.cubic.data.model.ModelGroup;
import mchorse.bbs_mod.forms.entities.IEntity;
import mchorse.bbs_mod.utils.pose.Pose;

import java.util.Collection;
import java.util.Set;

public interface IModel extends IBoneHierarchy
{
    public Pose createPose();

    public void resetPose();

    public void applyPose(Pose pose);

    /**
     * Record every bone's channels-phase orient/offset, right after the channels evaluate, so a
     * skipped re-evaluation can rewind the constraint stack's writes with {@link #restoreChannels()}
     * — IK/physics blend FROM the evaluated state and must not stack on their own previous output.
     */
    public void snapshotChannels();

    public void restoreChannels();

    public Set<String> getShapeKeys();

    public String getAnchor();

    public Collection<String> getAllGroupKeys();

    /**
     * The bone that name addresses, or null when this model has no such bone. The one lookup
     * every poser needs: what used to be "is this a cubic model or a BOBJ one, and which of the
     * two bone maps do I reach into" is now this call plus {@link RigBone}.
     */
    public RigBone getBone(String name);

    /**
     * Every bone of the skeleton, in the order it is evaluated (parents before children). The
     * counterpart of {@link #getBone} for stages that sweep the whole rig — limits, physics,
     * debug overlays — and the reason they no longer need one loop per model flavour.
     */
    /**
     * Whether the skeleton is authored facing the other way, so anything drawn in model space
     * over it — the IK and physics overlays — has to turn 180° about Y to line up. True for BOBJ.
     */
    public default boolean isFacingFlipped()
    {
        return false;
    }

    public Collection<? extends RigBone> getRigBones();

    public Collection<ModelGroup> getAllGroups();

    public Collection<BOBJBone> getAllBOBJBones();

    public void apply(IEntity target, Animation action, float tick, float blend, float transition, boolean skipInitial);

    public void postApply(IEntity target, Animation action, float tick, float transition);
}