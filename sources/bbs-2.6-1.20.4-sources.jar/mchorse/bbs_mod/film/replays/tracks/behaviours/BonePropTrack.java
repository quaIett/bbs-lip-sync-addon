package mchorse.bbs_mod.film.replays.tracks.behaviours;

import mchorse.bbs_mod.film.replays.tracks.TrackBehaviour;
import mchorse.bbs_mod.film.replays.tracks.TrackBlend;
import mchorse.bbs_mod.film.replays.tracks.TrackContext;
import mchorse.bbs_mod.film.replays.tracks.TrackId;
import mchorse.bbs_mod.forms.FormUtils;
import mchorse.bbs_mod.forms.forms.Form;
import mchorse.bbs_mod.forms.forms.ModelForm;
import mchorse.bbs_mod.forms.forms.utils.FormBone;
import mchorse.bbs_mod.settings.values.base.BaseKeyframeFactoryValue;
import mchorse.bbs_mod.utils.keyframes.KeyframeChannel;
import mchorse.bbs_mod.utils.keyframes.KeyframeSegment;
import mchorse.bbs_mod.utils.keyframes.factories.IKeyframeFactory;

/**
 * One property of one bone — its constraints, its IK scalars, its physics scalars. Behaves exactly
 * like {@link PropertyTrack}: the track drives the bone property's runtime value, which the
 * matching runtime (constraints, IK solver, physics) reads each frame; off the end of the track the
 * runtime value is dropped and the bone falls back to its own static setting.
 *
 * <p>Which value the track drives is asked of the bone itself, by the property's id: the value type
 * is the property's own (one object serves as the form's static setting and as the keyframe), so
 * there is no table of property names here and no mirror class between the track and the form.</p>
 */
public class BonePropTrack implements TrackBehaviour
{
    /** A neutral bone to ask what a property keys without touching any form. */
    private static final FormBone TEMPLATE = new FormBone("");

    /** The bone's value this track addresses, or null when the bone has no such animatable property. */
    public static BaseKeyframeFactoryValue<?> property(FormBone bone, TrackId track)
    {
        return bone.get(track.property()) instanceof BaseKeyframeFactoryValue<?> value ? value : null;
    }

    @Override
    public IKeyframeFactory factory(TrackId track)
    {
        BaseKeyframeFactoryValue<?> value = property(TEMPLATE, track);

        return value == null ? null : value.getFactory();
    }

    @Override
    public void apply(TrackContext context, TrackId track, KeyframeChannel channel, float tick, float blend)
    {
        if (!(FormUtils.getForm(context.root(), track.formPath()) instanceof ModelForm modelForm))
        {
            return;
        }

        KeyframeSegment segment = channel.find(tick);

        if (segment != null)
        {
            /* The bone may have never been touched statically — a track alone must still drive it.
             * An all-neutral bone is not persisted, so this leaves no trace in saved data. */
            BaseKeyframeFactoryValue value = property(modelForm.bones.getOrCreate(track.subject()), track);

            if (value != null)
            {
                value.setRuntimeValue(TrackBlend.value(channel, value.get(), segment, blend));
            }
        }
        else if (blend >= 1F)
        {
            this.reset(context.root(), track);
        }
    }

    @Override
    public void reset(Form root, TrackId track)
    {
        if (FormUtils.getForm(root, track.formPath()) instanceof ModelForm modelForm)
        {
            FormBone bone = modelForm.bones.getBone(track.subject());
            BaseKeyframeFactoryValue<?> value = bone == null ? null : property(bone, track);

            if (value != null)
            {
                value.setRuntimeValue(null);
            }
        }
    }
}
