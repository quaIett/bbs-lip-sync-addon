package mchorse.bbs_mod.film.replays.tracks.behaviours;

import mchorse.bbs_mod.film.replays.tracks.TrackBehaviour;
import mchorse.bbs_mod.film.replays.tracks.TrackBlend;
import mchorse.bbs_mod.film.replays.tracks.TrackContext;
import mchorse.bbs_mod.film.replays.tracks.TrackId;
import mchorse.bbs_mod.forms.FormUtils;
import mchorse.bbs_mod.forms.forms.BodyPart;
import mchorse.bbs_mod.forms.forms.Form;
import mchorse.bbs_mod.settings.values.base.BaseKeyframeFactoryValue;
import mchorse.bbs_mod.utils.keyframes.KeyframeChannel;
import mchorse.bbs_mod.utils.keyframes.KeyframeSegment;
import mchorse.bbs_mod.utils.keyframes.factories.IKeyframeFactory;

/**
 * One value of a body part itself — its attachment transform. Behaves like {@link PropertyTrack}:
 * the track drives the value's runtime, which the renderer reads when it places the part on its
 * bone; off the end of the track the runtime is dropped and the part sits at its static offset.
 *
 * <p>Which value is asked of the part by the property id, on a neutral part when there is no form
 * to ask, so the track knows the value type without a table of its own.</p>
 */
public class PartPropTrack implements TrackBehaviour
{
    private static final BodyPart TEMPLATE = new BodyPart("");

    /** The part value this track addresses, or null when the part has no such animatable value. */
    public static BaseKeyframeFactoryValue<?> property(BodyPart part, TrackId track)
    {
        return part.get(track.property()) instanceof BaseKeyframeFactoryValue<?> value ? value : null;
    }

    @Override
    public IKeyframeFactory factory(TrackId track)
    {
        BaseKeyframeFactoryValue<?> value = property(TEMPLATE, track);

        return value == null ? null : value.getFactory();
    }

    @Override
    public void apply(TrackContext context, TrackId track, KeyframeChannel channel, float tick, float blend)
    {
        BodyPart part = FormUtils.getBodyPart(context.root(), track.formPath());
        BaseKeyframeFactoryValue value = part == null ? null : property(part, track);

        if (value == null)
        {
            return;
        }

        KeyframeSegment segment = channel.find(tick);

        if (segment != null)
        {
            value.setRuntimeValue(TrackBlend.value(channel, value.get(), segment, blend));
        }
        else if (blend >= 1F)
        {
            value.setRuntimeValue(null);
        }
    }

    @Override
    public void reset(Form root, TrackId track)
    {
        BodyPart part = FormUtils.getBodyPart(root, track.formPath());
        BaseKeyframeFactoryValue<?> value = part == null ? null : property(part, track);

        if (value != null)
        {
            value.setRuntimeValue(null);
        }
    }
}
