package mchorse.bbs_mod.film.replays.tracks;

/**
 * Every kind of track a film can animate. The kind is what a track <em>is</em> — until now it was
 * re-derived from the channel id by string matching in seven different places, each knowing a
 * different subset of the kinds (see {@link TrackId}).
 *
 * <p>A kind carries no behaviour yet; that arrives with the track registry, which moves the value
 * factory, the apply/reset step, the seed and the presentation onto the kind itself.</p>
 */
public enum TrackKind
{
    /**
     * A plain form property, addressed by its own id ({@code color}, {@code texture},
     * {@code transform}...). Only a visible value is one: the pose is a static setting of the form,
     * animated bone by bone through {@link #BONE} tracks, never as a whole.
     */
    PROPERTY("property"),

    /**
     * A body part: not a value at all, but the row its form's tracks fold under, so a part's
     * name is written once instead of prefixing every track it owns.
     */
    BODY_PART("body_part"),

    /**
     * One value of a body part itself (its attachment transform) as opposed to a value of the form
     * inside it: the part and its form both have a transform, and only the address says which one.
     * Folds under the part row like the form values do.
     */
    PART_PROP("part_prop"),

    /** One bone of a model form's pose, the per-limb track that folds under the form's pose track. */
    BONE("bone"),

    /**
     * One property of one bone ({@code constraints}, {@code ik}, {@code physics}) — the bone's own
     * value in {@code ModelForm.bones}, folding under the bone's pose track. Mirrors
     * {@link #MATERIAL_PROP}: the subject names the bone, the property names which of its values.
     */
    BONE_PROP("bone_prop"),

    /** The texture override of one material of a model form. */
    MATERIAL_TEXTURE("material_texture"),

    /** One appearance property (color, glow, culling, a PBR slider) of one material of a model form. */
    MATERIAL_PROP("material_prop"),

    /** The world-space target of one IK controller. */
    IK_TARGET("ik_target"),

    /** The world-space pole target of one IK controller. */
    POLE_TARGET("pole_target"),

    /** The world-space target of one physics chain, addressed by its root bone. */
    PHYSICS_TARGET("physics_target");

    /** Stable name of the kind in saved data. Never derive it from {@link #name()} — renaming the constant would break films. */
    public final String key;

    private TrackKind(String key)
    {
        this.key = key;
    }

    public static TrackKind byKey(String key)
    {
        for (TrackKind kind : values())
        {
            if (kind.key.equals(key))
            {
                return kind;
            }
        }

        return null;
    }

    /**
     * Whether this kind drives a solver target (IK, pole, physics) rather than a value of the form itself.
     * Those only apply inside a film — they are laid over the form's solver config for one frame and
     * dropped again — so a timeline that is not a film's does not offer them.
     */
    public boolean isSolver()
    {
        return this != PROPERTY && this != BODY_PART && this != PART_PROP && this != BONE && this != BONE_PROP
            && this != MATERIAL_TEXTURE && this != MATERIAL_PROP;
    }
}
