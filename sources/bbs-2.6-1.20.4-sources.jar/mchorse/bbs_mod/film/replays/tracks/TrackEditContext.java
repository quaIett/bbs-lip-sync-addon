package mchorse.bbs_mod.film.replays.tracks;

import mchorse.bbs_mod.film.replays.FormProperties;
import mchorse.bbs_mod.forms.FormUtils;
import mchorse.bbs_mod.forms.forms.Form;
import mchorse.bbs_mod.forms.forms.IPosedForm;
import mchorse.bbs_mod.settings.values.base.BaseKeyframeFactoryValue;
import mchorse.bbs_mod.settings.values.base.BaseValue;
import mchorse.bbs_mod.settings.values.base.BaseValueBasic;
import mchorse.bbs_mod.settings.values.base.EditContext;
import mchorse.bbs_mod.settings.values.core.ValuePose;
import mchorse.bbs_mod.utils.keyframes.Keyframe;
import mchorse.bbs_mod.utils.keyframes.KeyframeChannel;
import mchorse.bbs_mod.utils.keyframes.KeyframeSegment;
import mchorse.bbs_mod.utils.keyframes.factories.IKeyframeFactory;
import mchorse.bbs_mod.utils.pose.Pose;
import mchorse.bbs_mod.utils.pose.PoseTransform;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/**
 * Edits made while a set of tracks is underneath — a film's replay, or a form's animation state:
 * a property those tracks animate takes a key on the frame the cursor is on, everything else is
 * written as the value it always was.
 *
 * <p>"Animated" means the track holds keyframes. An empty channel is what a track looks like
 * before anyone animated the property, and it drives nothing — so it is no track at all here.</p>
 *
 * <p>The pose is the one value a form animates by parts: each bone of it has a track of its own.
 * An edit of the pose is therefore taken bone by bone — a changed bone with a track is keyed,
 * a changed bone without one is written into the pose.</p>
 *
 * <p>Everything is asked live: which tracks, which tick, and whether the timeline is even open. A
 * context is pushed once for the editor's lifetime and answers for whatever that editor shows now.</p>
 */
public class TrackEditContext implements EditContext.IEditContext
{
    private final Supplier<FormProperties> properties;
    private final IntSupplier tick;
    private final BooleanSupplier active;

    /** Whether an edit of a property nobody animated yet should start animating it (see {@link #autoTracks}). */
    private BooleanSupplier autoTracks = () -> false;

    /** How the host brings a track into view in its timeline, when it has one — see {@link #reveal(BaseValue)}. */
    private Consumer<TrackId> reveal;

    /**
     * @param properties the tracks a key would land in — null when there are none right now
     * @param tick       where the cursor is
     * @param active     whether the timeline is open in front of the user; when it is not, the
     *                   edit goes into the value even if tracks exist
     */
    public TrackEditContext(Supplier<FormProperties> properties, IntSupplier tick, BooleanSupplier active)
    {
        this.properties = properties;
        this.tick = tick;
        this.active = active;
    }

    /**
     * "Auto tracks": with this on, an edit of a property that has no track makes one, with a key at
     * the cursor holding the edited value — the track appears by itself instead of the value
     * changing. Off, the edit of an unanimated property is the plain write it always was.
     */
    public TrackEditContext autoTracks(BooleanSupplier autoTracks)
    {
        this.autoTracks = autoTracks;

        return this;
    }

    private boolean isAuto()
    {
        return this.autoTracks.getAsBoolean() && this.getProperties() != null;
    }

    public TrackEditContext reveal(Consumer<TrackId> reveal)
    {
        this.reveal = reveal;

        return this;
    }

    /** Whether "go to track" can be offered here: the host has a timeline to show the row in. */
    public boolean canReveal()
    {
        return this.reveal != null;
    }

    /**
     * Bring the property's track into view in the host's timeline — unfolded, scrolled to, lit up
     * for a moment. Nothing else moves: not the cursor, not the selection.
     */
    public void reveal(BaseValue property)
    {
        TrackId track = TrackAddress.of(property);

        if (this.reveal != null && track != null)
        {
            this.reveal.accept(track);
        }
    }

    /** The active context, when it is one with tracks underneath; null in an editor with none. */
    public static TrackEditContext current()
    {
        return EditContext.current() instanceof TrackEditContext context ? context : null;
    }

    public FormProperties getProperties()
    {
        return this.active.getAsBoolean() ? this.properties.get() : null;
    }

    /* The key on the cursor: what a panel shows for an animated value, and what its edit lands on */

    /** The key sitting exactly on the cursor, or null. */
    public Keyframe keyAt(KeyframeChannel channel)
    {
        return channel == null ? null : channel.keyAt(this.getTick());
    }

    /**
     * The key on the cursor, made when the track has none there from what the track reads at the
     * cursor — so bringing it into being moves nothing. An edit of an animated value lands here.
     * Null for a track with no keys at all.
     */
    public Keyframe ensureKeyAt(KeyframeChannel channel)
    {
        return channel == null ? null : channel.ensureKeyAt(this.getTick());
    }

    public Keyframe keyAtCursor(BaseValue property)
    {
        return this.keyAt(this.track(property));
    }

    public Keyframe ensureKeyAtCursor(BaseValue property)
    {
        return this.ensureKeyAt(this.track(property));
    }

    /** The animated track of one bone of this pose — the channel with keys — or null. */
    public KeyframeChannel boneTrack(ValuePose pose, String bone)
    {
        FormProperties properties = this.getProperties();
        IPosedForm form = this.posedForm(pose);

        if (properties == null || form == null || bone == null || bone.isEmpty())
        {
            return null;
        }

        KeyframeChannel channel = properties.get(TrackAddress.bone(form, bone));

        return channel == null || channel.isEmpty() ? null : channel;
    }

    public int getTick()
    {
        return this.tick.getAsInt();
    }

    /** The animated track of this property — the channel with keys — or null. */
    public KeyframeChannel track(BaseValue property)
    {
        FormProperties properties = this.getProperties();

        if (properties == null)
        {
            return null;
        }

        KeyframeChannel channel = properties.get(TrackAddress.of(property));

        return channel == null || channel.isEmpty() ? null : channel;
    }

    /** Whether this property could be animated here at all — it has an address and there are tracks to hold it. */
    public boolean canAnimate(BaseValue property)
    {
        return this.getProperties() != null && TrackAddress.of(property) != null;
    }

    /**
     * Start animating the property: its track is made (if absent) and takes a first key at the
     * cursor holding the value the property has now, so nothing visibly changes at the moment
     * the track appears.
     */
    public KeyframeChannel animate(BaseValueBasic<?> property)
    {
        FormProperties properties = this.getProperties();
        TrackId track = TrackAddress.of(property);

        if (properties == null || track == null || !(property instanceof BaseKeyframeFactoryValue<?> typed))
        {
            return null;
        }

        KeyframeChannel existing = properties.get(track);
        KeyframeChannel channel = existing != null ? existing : properties.register(track, typed.getFactory());

        if (channel == null)
        {
            return null;
        }

        IKeyframeFactory factory = typed.getFactory();
        Object first = factory.copy(property.getOriginalValue());

        BaseValue.edit(properties, (p) -> channel.insert(this.getTick(), first));

        return channel;
    }

    /**
     * Stop animating the property: the value keeps what the track showed at the cursor (the
     * frame the user is looking at), and the track is dropped.
     */
    public void removeTrack(BaseValueBasic property)
    {
        FormProperties properties = this.getProperties();
        TrackId track = TrackAddress.of(property);
        KeyframeChannel channel = properties == null ? null : properties.get(track);

        if (channel == null)
        {
            return;
        }

        KeyframeSegment segment = channel.find(this.getTick());
        Object shown = segment == null ? null : channel.getFactory().copy(segment.createInterpolated());

        BaseValue.edit(properties, (p) -> p.remove(track));

        if (shown != null)
        {
            property.set(shown);
        }
    }

    @Override
    public boolean routes(BaseValueBasic<?> property)
    {
        if (property instanceof ValuePose pose && (!this.boneTracks(pose).isEmpty() || (this.isAuto() && this.posedForm(pose) != null)))
        {
            return true;
        }

        KeyframeChannel channel = this.track(property);

        if (channel != null)
        {
            return property instanceof BaseKeyframeFactoryValue<?> typed && channel.getFactory() == typed.getFactory();
        }

        return this.isAuto() && this.canAnimate(property) && property instanceof BaseKeyframeFactoryValue<?>;
    }

    @Override
    public boolean commit(BaseValueBasic<?> property, Object value)
    {
        if (property instanceof ValuePose pose && value instanceof Pose edited)
        {
            Map<String, KeyframeChannel> tracks = this.boneTracks(pose);

            if (!tracks.isEmpty() || (this.isAuto() && this.posedForm(pose) != null))
            {
                this.commitPose(pose, edited, tracks);

                return true;
            }
        }

        KeyframeChannel channel = this.track(property);

        if (channel == null && this.isAuto() && property instanceof BaseKeyframeFactoryValue<?> typed && TrackAddress.of(property) != null)
        {
            /* Auto tracks: the property starts animating with this very edit. */
            channel = this.getProperties().register(TrackAddress.of(property), typed.getFactory());
        }

        if (channel == null || !(property instanceof BaseKeyframeFactoryValue<?> typed) || channel.getFactory() != typed.getFactory())
        {
            /* Not animated (or animated as something else, which is not the same property at all):
             * the edit is of the value, exactly as before. */
            return false;
        }

        this.key(channel, value);

        return true;
    }

    /**
     * A key at the cursor holding the value. A key made between two others takes the interpolation
     * of the one before it, so the curve the user was looking at keeps its character where the new
     * key split it.
     */
    private void key(KeyframeChannel channel, Object value)
    {
        int tick = this.getTick();
        KeyframeSegment segment = channel.find(tick);
        int index = channel.insert(tick, channel.getFactory().copy(value));
        Keyframe keyframe = channel.get(index);

        if (segment != null && segment.a != keyframe && segment.a.getTick() < tick)
        {
            keyframe.copyOverExtra(segment.a);
        }
    }

    /* The pose, bone by bone */

    /** The form whose pose this is, or null for a pose value that is not a form's. */
    private IPosedForm posedForm(ValuePose pose)
    {
        return pose.getParent() instanceof IPosedForm form && form.getPose() == pose ? form : null;
    }

    /** The animated per-bone tracks of the pose's form, by bone. */
    private Map<String, KeyframeChannel> boneTracks(ValuePose pose)
    {
        FormProperties properties = this.getProperties();
        IPosedForm form = this.posedForm(pose);

        if (properties == null || form == null)
        {
            return Collections.emptyMap();
        }

        String path = FormUtils.getPath((Form) form);
        Map<String, KeyframeChannel> tracks = new HashMap<>();

        for (Map.Entry<TrackId, KeyframeChannel> entry : properties.tracks.entrySet())
        {
            TrackId id = entry.getKey();

            if (id.is(TrackKind.BONE) && id.formPath().equals(path) && !entry.getValue().isEmpty())
            {
                tracks.put(id.subject(), entry.getValue());
            }
        }

        return tracks;
    }

    /**
     * Take a pose edit bone by bone. {@code edited} is what the widget produced; the pose itself
     * still holds what it held before the edit. Every bone that differs between the two either
     * gets a key on its track, or — having no track — its new transform written into the pose.
     */
    private void commitPose(ValuePose pose, Pose edited, Map<String, KeyframeChannel> tracks)
    {
        Pose current = pose.getOriginalValue();
        Set<String> bones = new HashSet<>(current.transforms.keySet());

        bones.addAll(edited.transforms.keySet());

        for (String bone : bones)
        {
            PoseTransform before = current.transforms.get(bone);
            PoseTransform after = edited.transforms.get(bone);

            if (Objects.equals(before, after))
            {
                continue;
            }

            KeyframeChannel channel = tracks.get(bone);

            if (channel == null && this.isAuto() && this.posedForm(pose) != null)
            {
                /* Auto tracks: a bone moved for the first time gets its track with this edit. */
                channel = this.getProperties().getOrCreate(TrackAddress.bone(this.posedForm(pose), bone));
            }

            if (channel != null)
            {
                this.key(channel, after != null ? after : new PoseTransform());
            }
            else if (after == null)
            {
                current.transforms.remove(bone);
            }
            else
            {
                current.getOrCreate(bone).copy(after);
            }
        }
    }
}
