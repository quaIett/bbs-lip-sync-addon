package mchorse.bbs_mod.film.replays.tracks;

import mchorse.bbs_mod.film.replays.tracks.behaviours.BonePropTrack;
import mchorse.bbs_mod.film.replays.tracks.behaviours.PartPropTrack;
import mchorse.bbs_mod.forms.FormUtils;
import mchorse.bbs_mod.forms.forms.BodyPart;
import mchorse.bbs_mod.forms.forms.Form;
import mchorse.bbs_mod.forms.forms.IPosedForm;
import mchorse.bbs_mod.forms.forms.ModelForm;
import mchorse.bbs_mod.forms.forms.utils.FormBone;
import mchorse.bbs_mod.forms.forms.utils.FormMaterial;
import mchorse.bbs_mod.settings.values.base.BaseKeyframeFactoryValue;
import mchorse.bbs_mod.settings.values.base.BaseValue;
import mchorse.bbs_mod.settings.values.base.BaseValueBasic;
import mchorse.bbs_mod.utils.StringUtils;

/**
 * The link between a property and its track: which track a value of a form is animated by, and
 * which value a track drives. Both answers are read off the value's place in the form — a value
 * of the form itself is a plain property track, a value of a bone or a material is that bone's or
 * material's property track — so a form can be asked "animate this" about any of its values,
 * with no table of names in between.
 *
 * <p>Only what is a value can be addressed this way. A bone's pose transform is not one (it lives
 * inside the form's pose), so it has an explicit door of its own below.</p>
 */
public class TrackAddress
{
    /**
     * The track animating this value, or null when the value is not something a film animates
     * (a static setting, an invisible value, a value of no form).
     */
    public static TrackId of(BaseValue property)
    {
        if (!(property instanceof BaseKeyframeFactoryValue<?>))
        {
            return null;
        }

        BaseValue owner = property.getParent();

        /* A form's own value is a track only while it is visible — an invisible one is a static
         * setting, the same rule the track catalog lists by. A bone's or a material's values are
         * all marked invisible (they are not the form's), and are all animatable. */
        if (owner instanceof Form form)
        {
            return property.isVisible() ? TrackId.property(FormUtils.getPath(form), property.getId()) : null;
        }

        if (owner instanceof FormBone bone && bone.getParent() != null && bone.getParent().getParent() instanceof ModelForm form)
        {
            return TrackId.boneProp(FormUtils.getPath(form), bone.getId(), property.getId());
        }

        if (owner instanceof FormMaterial material && material.getParent() != null && material.getParent().getParent() instanceof ModelForm form)
        {
            return TrackId.materialProp(FormUtils.getPath(form), material.getId(), property.getId());
        }

        /* A value of a body part itself: only the known ones, addressed by the path of the part. */
        if (owner instanceof BodyPart part && part.getManager() != null && part.getManager().getOwner() != null)
        {
            for (String known : TrackId.PART_PROPS_ALL)
            {
                if (known.equals(property.getId()))
                {
                    return TrackId.partProp(StringUtils.combinePaths(FormUtils.getPath(part.getManager().getOwner()), part.getId()), known);
                }
            }

            return null;
        }

        return null;
    }

    /** The track of one bone's pose transform — the one thing a form animates that is not a value. */
    public static TrackId bone(IPosedForm form, String bone)
    {
        return TrackId.bone(FormUtils.getPath((Form) form), bone);
    }

    /** The value a track drives, under this root form; null for a track that drives no value of its own. */
    public static BaseValueBasic<?> property(Form root, TrackId track)
    {
        if (root == null || track == null)
        {
            return null;
        }

        switch (track.kind())
        {
            case PROPERTY:
                return FormUtils.getProperty(root, track.toKey());

            case BONE_PROP:
            {
                if (!(FormUtils.getForm(root, track.formPath()) instanceof ModelForm form))
                {
                    return null;
                }

                FormBone bone = form.bones.getBone(track.subject());

                return bone == null ? null : BonePropTrack.property(bone, track);
            }

            case PART_PROP:
            {
                BodyPart part = FormUtils.getBodyPart(root, track.formPath());

                return part == null ? null : PartPropTrack.property(part, track);
            }

            case MATERIAL_PROP:
            {
                if (!(FormUtils.getForm(root, track.formPath()) instanceof ModelForm form))
                {
                    return null;
                }

                return form.materials.get(track.material()) instanceof FormMaterial material
                    && material.get(track.property()) instanceof BaseValueBasic<?> value ? value : null;
            }

            default:
                return null;
        }
    }
}
