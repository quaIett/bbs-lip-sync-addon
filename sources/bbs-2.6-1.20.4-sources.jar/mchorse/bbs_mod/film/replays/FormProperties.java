package mchorse.bbs_mod.film.replays;

import mchorse.bbs_mod.data.types.BaseType;
import mchorse.bbs_mod.data.types.ListType;
import mchorse.bbs_mod.data.types.MapType;
import mchorse.bbs_mod.film.replays.tracks.TrackBehaviour;
import mchorse.bbs_mod.film.replays.tracks.TrackBehaviours;
import mchorse.bbs_mod.film.replays.tracks.TrackContext;
import mchorse.bbs_mod.film.replays.tracks.TrackId;
import mchorse.bbs_mod.film.replays.tracks.TrackKind;
import mchorse.bbs_mod.forms.FormUtils;
import mchorse.bbs_mod.forms.forms.Form;
import mchorse.bbs_mod.forms.forms.IPosedForm;
import mchorse.bbs_mod.settings.values.base.BaseKeyframeFactoryValue;
import mchorse.bbs_mod.settings.values.base.BaseValue;
import mchorse.bbs_mod.settings.values.core.ValueGroup;
import mchorse.bbs_mod.utils.MathUtils;
import mchorse.bbs_mod.utils.keyframes.Keyframe;
import mchorse.bbs_mod.utils.keyframes.KeyframeChannel;
import mchorse.bbs_mod.utils.keyframes.factories.IKeyframeFactory;


import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Every track of one replay (or one animation state): a channel of keyframes per address.
 *
 * <p>The address is a {@link TrackId}, not a string — what a track animates is decided once, when
 * the track is made or read, instead of being re-derived from its id by every piece of code that
 * touches it.</p>
 */
public class FormProperties extends ValueGroup
{
    /** Id of the form property holding the whole pose — the track a form's bone tracks hang under. */
    /**
     * Saved-data key of the track list. Its presence is what tells the new format from the old one,
     * which was a map of channel id to channel.
     */
    private static final String TRACKS = "tracks";

    public final Map<TrackId, KeyframeChannel> tracks = new LinkedHashMap<>();

    /**
     * Tracks that were read but could not be understood — an unknown kind, or a channel whose
     * value factory this build does not have. Both mean an addon that is not loaded.
     *
     * <p>They are kept verbatim and written back out on save. Dropping them was worse than it
     * looked: opening a film once without the addon and saving it took the animation with it,
     * and nothing said so.</p>
     */
    private final List<MapType> foreignTracks = new ArrayList<>();

    public FormProperties(String id)
    {
        super(id);
    }

    public void shift(float tick)
    {
        for (KeyframeChannel<?> value : this.tracks.values())
        {
            for (Keyframe<?> keyframe : value.getKeyframes())
            {
                keyframe.setTick(keyframe.getTick() + tick);
            }
        }
    }

    /* Access */

    public KeyframeChannel get(TrackId track)
    {
        return track == null ? null : this.tracks.get(track);
    }

    public boolean has(TrackId track)
    {
        return track != null && this.tracks.containsKey(track);
    }

    /**
     * The track at this address, made if it isn't there yet.
     *
     * @param root  form the addresses are relative to; only a {@link TrackKind#PROPERTY} track needs
     *              it, since a plain property keys whatever its own value keys
     */
    public KeyframeChannel getOrCreate(Form root, TrackId track)
    {
        if (track == null)
        {
            return null;
        }

        KeyframeChannel channel = this.tracks.get(track);

        if (channel != null)
        {
            return channel;
        }

        if (track.is(TrackKind.PROPERTY))
        {
            BaseValue property = FormUtils.getProperty(root, track.toKey());

            return property == null ? null : this.create(property);
        }

        return this.register(track, TrackBehaviours.factory(track));
    }

    /** Every kind but {@link TrackKind#PROPERTY}, whose factory has to be looked up on the form. */
    public KeyframeChannel getOrCreate(TrackId track)
    {
        return this.getOrCreate(null, track);
    }

    public KeyframeChannel getOrCreate(Form root, String key)
    {
        return this.getOrCreate(root, TrackId.parse(key));
    }

    /** Make the track of a form property, keyed by the path the property sits at. */
    public KeyframeChannel create(BaseValue property)
    {
        if (property.isVisible() && property instanceof BaseKeyframeFactoryValue<?> keyframeFactoryValue)
        {
            TrackId track = TrackId.parse(FormUtils.getPropertyPath(property));

            if (track == null)
            {
                return null;
            }

            return this.register(track, keyframeFactoryValue.getFactory());
        }

        return null;
    }

    public KeyframeChannel register(TrackId track, IKeyframeFactory factory)
    {
        if (track == null || factory == null)
        {
            return null;
        }

        KeyframeChannel channel = this.tracks.get(track);

        if (channel == null)
        {
            channel = new KeyframeChannel(track.toKey(), factory);

            this.put(track, channel);
        }

        return channel;
    }

    /** Take a channel as this track, replacing whatever stood there. */
    public void put(TrackId track, KeyframeChannel channel)
    {
        if (track == null || channel == null)
        {
            return;
        }

        KeyframeChannel previous = this.tracks.put(track, channel);

        if (previous != null)
        {
            this.remove(previous);
        }

        this.add(channel);
    }

    public void remove(TrackId track)
    {
        KeyframeChannel channel = this.tracks.remove(track);

        if (channel != null)
        {
            this.remove(channel);
        }
    }

    /* Playback */

    public void applyProperties(Form form, float tick)
    {
        this.applyProperties(form, tick, 1F);
    }

    public void applyProperties(Form form, float tick, float blend)
    {
        this.apply(TrackContext.of(form), tick, blend);
    }

    /**
     * Lay every track over the form at the given tick.
     *
     * <p>Bone tracks go last, and behind a reset: the form's runtime pose is dropped first, so the
     * bones layer over the form's own pose rather than over last frame's result.</p>
     */
    public void apply(TrackContext context, float tick, float blend)
    {
        if (context.root() == null)
        {
            return;
        }

        float clampedBlend = MathUtils.clamp(blend, 0F, 1F);
        Map<TrackId, KeyframeChannel> boneTracks = new LinkedHashMap<>();

        for (Map.Entry<TrackId, KeyframeChannel> entry : this.tracks.entrySet())
        {
            if (entry.getKey().is(TrackKind.BONE))
            {
                boneTracks.put(entry.getKey(), entry.getValue());
            }
            else
            {
                apply(context, entry.getKey(), entry.getValue(), tick, clampedBlend);
            }
        }

        Set<String> processedForms = new HashSet<>();

        for (TrackId track : boneTracks.keySet())
        {
            String formPath = track.formPath();

            if (!processedForms.add(formPath))
            {
                continue;
            }

            if (FormUtils.getForm(context.root(), formPath) instanceof IPosedForm posedForm)
            {
                posedForm.getPose().setRuntimeValue(null);
            }
        }

        for (Map.Entry<TrackId, KeyframeChannel> entry : boneTracks.entrySet())
        {
            apply(context, entry.getKey(), entry.getValue(), tick, clampedBlend);
        }
    }

    private static void apply(TrackContext context, TrackId track, KeyframeChannel channel, float tick, float blend)
    {
        TrackBehaviour behaviour = TrackBehaviours.of(track);

        if (behaviour != null)
        {
            behaviour.apply(context, track, channel, tick, blend);
        }
    }

    /** Let go of every track, so the form shows what it shows on its own again. */
    public void resetProperties(Form form)
    {
        if (form == null)
        {
            return;
        }

        for (TrackId track : this.tracks.keySet())
        {
            TrackBehaviour behaviour = TrackBehaviours.of(track);

            if (behaviour != null)
            {
                behaviour.reset(form, track);
            }
        }
    }

    public void cleanUp()
    {
        Iterator<Map.Entry<TrackId, KeyframeChannel>> it = this.tracks.entrySet().iterator();

        while (it.hasNext())
        {
            KeyframeChannel next = it.next().getValue();

            if (next.isEmpty())
            {
                it.remove();
                this.remove(next);
            }
        }
    }

    /**
     * Put aside the tracks of values the form has but does not animate. An invisible value is a
     * static setting of the form, never a track — the whole-pose track of an older film is the
     * case — and a track for one is data, not an animation: it joins the foreign tracks, kept
     * verbatim and written back on save, and stops being a row anywhere. Asked once the form is
     * known, since only the form can say which of its values are visible.
     */
    public void retire(Form root)
    {
        if (root == null)
        {
            return;
        }

        Iterator<Map.Entry<TrackId, KeyframeChannel>> it = this.tracks.entrySet().iterator();

        while (it.hasNext())
        {
            Map.Entry<TrackId, KeyframeChannel> entry = it.next();
            TrackId track = entry.getKey();

            if (!track.is(TrackKind.PROPERTY))
            {
                continue;
            }

            BaseValue property = FormUtils.getProperty(root, track.toKey());

            if (property == null || property.isVisible())
            {
                continue;
            }

            if (!entry.getValue().isEmpty())
            {
                this.foreignTracks.add(write(track, entry.getValue()));
            }

            it.remove();
            this.remove(entry.getValue());
        }
    }

    /* Serialisation */

    @Override
    public BaseType toData()
    {
        ListType list = new ListType();

        for (Map.Entry<TrackId, KeyframeChannel> entry : this.tracks.entrySet())
        {
            KeyframeChannel channel = entry.getValue();

            if (channel.isEmpty())
            {
                continue;
            }

            list.add(write(entry.getKey(), channel));
        }

        for (MapType foreign : this.foreignTracks)
        {
            list.add(foreign.copy());
        }

        MapType map = new MapType();

        map.put(TRACKS, list);

        return map;
    }

    /** One saved track: its address in pieces and its channel. */
    private static MapType write(TrackId track, KeyframeChannel channel)
    {
        MapType data = new MapType();

        data.putString("kind", track.kind().key);

        if (!track.formPath().isEmpty())
        {
            data.putString("form", track.formPath());
        }

        if (!track.subject().isEmpty())
        {
            data.putString("subject", track.subject());
        }

        if (!track.property().isEmpty())
        {
            data.putString("prop", track.property());
        }

        data.put("channel", channel.toData());

        return data;
    }

    @Override
    public void fromData(BaseType data)
    {
        this.removeAll();
        this.tracks.clear();
        this.foreignTracks.clear();

        if (!data.isMap())
        {
            return;
        }

        MapType map = data.asMap();

        if (map.has(TRACKS) && map.get(TRACKS).isList())
        {
            this.readTracks(map.getList(TRACKS));
        }
    }

    private void readTracks(ListType list)
    {
        for (int i = 0; i < list.size(); i++)
        {
            if (!list.get(i).isMap())
            {
                continue;
            }

            MapType data = list.get(i).asMap();
            TrackKind kind = TrackKind.byKey(data.getString("kind"));

            if (kind == null)
            {
                this.foreignTracks.add((MapType) data.copy());

                continue;
            }

            TrackId track = new TrackId(kind, data.getString("form"), data.getString("subject"), data.getString("prop"));
            KeyframeChannel channel = new KeyframeChannel(track.toKey(), null);

            channel.fromData(data.getMap("channel"));

            /* The factory is written next to the keyframes; a channel saved with one this build no
             * longer knows can't be read at all, so the track is kept as data rather than as a
             * half-alive channel. */
            if (channel.getFactory() == null)
            {
                this.foreignTracks.add((MapType) data.copy());

                continue;
            }

            this.put(track, channel);
        }
    }
}
