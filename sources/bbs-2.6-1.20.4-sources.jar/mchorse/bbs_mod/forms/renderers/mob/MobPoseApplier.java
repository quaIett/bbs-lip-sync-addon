package mchorse.bbs_mod.forms.renderers.mob;

import mchorse.bbs_mod.utils.pose.Pose;
import mchorse.bbs_mod.utils.pose.PoseTransform;
import mchorse.bbs_mod.utils.pose.Transform;
import net.minecraft.class_630;
import org.joml.Vector3f;

import java.util.Map;

/**
 * Writes a pose onto a vanilla model's parts, and takes it back off again.
 *
 * <p>Vanilla model parts are shared by every entity of that kind in the world, so the pose is
 * ADDED on top of the angles {@code setAngles} just computed and the originals are put aside to be
 * restored the moment the render is over. Both halves live here because the film's offline matrix
 * evaluation needs exactly the same pair, and a second copy of this arithmetic is how the two
 * would quietly drift apart.</p>
 */
public class MobPoseApplier
{
    /** A part's put-aside transform, plus whether the part was hidden before the pose hid it. */
    private static class SavedTransform extends Transform
    {
        public boolean hidden;
    }

    public static void apply(MobRig rig, Pose pose, Map<class_630, Transform> saved)
    {
        if (rig == null || pose == null)
        {
            return;
        }

        for (class_630 part : rig.ordered())
        {
            PoseTransform poseTransform = rig.resolve(pose, rig.name(part));

            if (poseTransform == null)
            {
                continue;
            }

            SavedTransform transform = new SavedTransform();

            transform.hidden = part.field_38456;
            part.field_38456 |= !poseTransform.visible;

            transform.translate.set(part.field_3657, part.field_3656, part.field_3655);
            transform.rotate.set(part.field_3654, part.field_3675, part.field_3674);
            transform.scale.set(part.field_37938, part.field_37939, part.field_37940);

            /* Vanilla ModelPart holds euler pitch/yaw/roll only, so a quaternion pose bone is
             * decomposed to its euler equivalent here instead of reading the stale rotate triple. */
            Vector3f rotation = poseTransform.getEulerRotation(new Vector3f());

            part.field_3657 += poseTransform.translate.x;
            part.field_3656 += poseTransform.translate.y;
            part.field_3655 += poseTransform.translate.z;
            part.field_3654 += rotation.x;
            part.field_3675 += rotation.y;
            part.field_3674 += rotation.z;
            part.field_37938 += poseTransform.scale.x - 1F;
            part.field_37939 += poseTransform.scale.y - 1F;
            part.field_37940 += poseTransform.scale.z - 1F;

            saved.putIfAbsent(part, transform);
        }
    }

    public static void restore(Map<class_630, Transform> saved)
    {
        for (Map.Entry<class_630, Transform> entry : saved.entrySet())
        {
            class_630 part = entry.getKey();
            Transform transform = entry.getValue();

            if (transform instanceof SavedTransform original)
            {
                part.field_38456 = original.hidden;
            }

            part.field_3657 = transform.translate.x;
            part.field_3656 = transform.translate.y;
            part.field_3655 = transform.translate.z;
            part.field_3654 = transform.rotate.x;
            part.field_3675 = transform.rotate.y;
            part.field_3674 = transform.rotate.z;
            part.field_37938 = transform.scale.x;
            part.field_37939 = transform.scale.y;
            part.field_37940 = transform.scale.z;
        }

        saved.clear();
    }
}
