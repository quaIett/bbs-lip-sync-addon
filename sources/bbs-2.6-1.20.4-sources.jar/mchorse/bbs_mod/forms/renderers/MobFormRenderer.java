package mchorse.bbs_mod.forms.renderers;

import com.mojang.blaze3d.systems.RenderSystem;
import mchorse.bbs_mod.BBSModClient;
import mchorse.bbs_mod.client.BBSShaders;
import mchorse.bbs_mod.cubic.IBoneHierarchy;
import mchorse.bbs_mod.forms.CustomVertexConsumerProvider;
import mchorse.bbs_mod.forms.FormTranslucentQueue;
import mchorse.bbs_mod.forms.FormUtilsClient;
import mchorse.bbs_mod.forms.ITickable;
import mchorse.bbs_mod.forms.entities.IEntity;
import mchorse.bbs_mod.forms.forms.BodyPart;
import mchorse.bbs_mod.forms.forms.Form;
import mchorse.bbs_mod.forms.forms.MobForm;
import mchorse.bbs_mod.forms.renderers.mob.MobRenderContext;
import mchorse.bbs_mod.forms.renderers.mob.MobPickerVertexConsumer;
import mchorse.bbs_mod.forms.renderers.mob.MobRig;
import mchorse.bbs_mod.forms.renderers.mob.MobRigMatrices;
import mchorse.bbs_mod.forms.renderers.mob.MobRigs;
import mchorse.bbs_mod.forms.renderers.mob.MobStandIn;
import mchorse.bbs_mod.forms.renderers.utils.MatrixCache;
import mchorse.bbs_mod.forms.renderers.utils.MatrixCacheEntry;
import mchorse.bbs_mod.resources.Link;
import mchorse.bbs_mod.ui.framework.UIContext;
import mchorse.bbs_mod.utils.MathUtils;
import mchorse.bbs_mod.utils.MatrixStackUtils;
import mchorse.bbs_mod.utils.StringUtils;
import mchorse.bbs_mod.utils.joml.Vectors;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_630;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_922;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.lwjgl.opengl.GL11;

import java.util.List;
import java.util.Map;

public class MobFormRenderer extends FormRenderer<MobForm> implements ITickable
{
    private final MatrixCache bones = new MatrixCache();

    /** The vanilla entity this form renders through, kept in step with the form's actor — see {@link MobStandIn}. */
    private final MobStandIn standIn = new MobStandIn();

    private class_1297 entity;

    public static MobRig getRig(MobForm form)
    {
        return FormUtilsClient.getRenderer(form) instanceof MobFormRenderer renderer ? renderer.getRig() : null;
    }

    public MobFormRenderer(MobForm form)
    {
        super(form);
    }

    @Override
    public List<String> getBones()
    {
        MobRig rig = this.getRig();

        return rig == null ? super.getBones() : rig.getGroupKeysInHierarchyOrder();
    }

    @Override
    public IBoneHierarchy getBoneHierarchy()
    {
        return this.getRig();
    }

    /**
     * The skeleton of the vanilla model this form renders through, or null while there is no
     * entity yet or the entity does not render through a living entity renderer.
     */
    public MobRig getRig()
    {
        this.ensureEntity();

        if (this.entity != null && class_310.method_1551().method_1561().method_3953(this.entity) instanceof class_922 renderer)
        {
            return MobRigs.of(renderer.method_4038());
        }

        return null;
    }

    /**
     * Claims one pick id for the form and one per bone, in the order the parts drew with (see
     * {@code MobRenderContext.partLight}). Same contract as the model form's
     * {@code ModelInstance.fillStencilMap}: the shader adds the part's offset to the form's base
     * id, so the registration order here IS the decoding table.
     */
    @Override
    protected void updateStencilMap(FormRenderingContext context)
    {
        MobRig rig = this.getRig();

        context.stencilMap.addPicking(this.form, "");

        if (rig != null)
        {
            for (class_630 part : rig.ordered())
            {
                context.stencilMap.addPicking(this.form, rig.name(part));
            }
        }
    }

    private boolean hasBoundBodyParts()
    {
        for (BodyPart part : this.form.parts.getAllTyped())
        {
            if (!part.bone.get().isEmpty())
            {
                return true;
            }
        }

        return false;
    }

    /**
     * Body parts bound to a bone ride that bone's frame; the rest stay exactly where they were,
     * in the form's own space. Only parts that name a bone the model actually has move, so nothing
     * that was authored before mob bones existed shifts underfoot.
     */
    @Override
    public void renderBodyParts(FormRenderingContext context)
    {
        for (BodyPart part : this.form.parts.getAllTyped())
        {
            Matrix4f matrix = part.filterBoneMatrix(this.bones.get(part.bone.get()).matrix());

            if (matrix == null)
            {
                this.renderBodyPart(part, context);

                continue;
            }

            context.stack.method_22903();
            if (context.world != null)
            {
                context.world.method_22903();
            }

            MatrixStackUtils.multiply(context.stack, matrix);
            if (context.world != null)
            {
                MatrixStackUtils.multiply(context.world, matrix);
            }

            this.renderBodyPart(part, context);

            context.stack.method_22909();
            if (context.world != null)
            {
                context.world.method_22909();
            }
        }

        this.bones.clear();
    }

    /**
     * The same bones, asked for outside a render - what the gizmo, the anchor system, trackers and
     * the motion path read. Body parts recurse through their bone's frame, so a form anchored to a
     * mob's head resolves under {@code <path>/head} the way a model form's bones do.
     */
    @Override
    public void collectMatrices(IEntity entity, class_4587 stack, MatrixCache matrices, String prefix, float transition)
    {
        this.ensureEntity();

        Matrix4f mm = new Matrix4f();
        Matrix4f oo = new Matrix4f();

        stack.method_22903();
        this.applyTransforms(stack, true, transition);
        oo.set(stack.method_23760().method_23761());
        stack.method_22909();

        stack.method_22903();
        this.applyTransforms(stack, false, transition);
        mm.set(stack.method_23760().method_23761());

        matrices.put(prefix, mm, oo);

        MatrixCache collected = new MatrixCache();

        MobRigMatrices.evaluate(this.entity, this.getRig(), this.form.pose.get(), transition, collected);

        for (Map.Entry<String, MatrixCacheEntry> entry : collected.entrySet())
        {
            Matrix4f matrix = new Matrix4f();
            Matrix4f o = new Matrix4f();

            stack.method_22903();
            MatrixStackUtils.multiply(stack, entry.getValue().matrix());
            matrix.set(stack.method_23760().method_23761());
            stack.method_22909();

            stack.method_22903();
            MatrixStackUtils.multiply(stack, entry.getValue().origin());
            o.set(stack.method_23760().method_23761());
            stack.method_22909();

            matrices.put(StringUtils.combinePaths(prefix, entry.getKey()), matrix, o);
        }

        for (BodyPart part : this.form.parts.getAllTyped())
        {
            Form form = part.getForm();

            if (form == null)
            {
                continue;
            }

            Matrix4f matrix = part.filterBoneMatrix(collected.get(part.bone.get()).matrix());

            stack.method_22903();

            if (matrix != null)
            {
                MatrixStackUtils.multiply(stack, matrix);
            }

            MatrixStackUtils.applyTransform(stack, part.transform.get());
            FormUtilsClient.getRenderer(form).collectMatrices(entity, stack, matrices, StringUtils.combinePaths(prefix, part.getId()), transition);

            stack.method_22909();
        }

        stack.method_22909();
    }

    private void bindTexture()
    {
        Link link = this.form.texture.get();

        if (link != null)
        {
            BBSModClient.getTextures().bindTexture(link);
        }
    }

    private void ensureEntity()
    {
        this.entity = this.standIn.ensure(this.form.mobID.get(), this.form.mobNBT.get(), this.form.slim.get(), this.form.isPlayer());
    }

    @Override
    protected void renderInUI(UIContext context, int x1, int y1, int x2, int y2)
    {
        this.ensureEntity();

        if (this.entity != null)
        {
            class_4587 stack = context.batcher.getContext().method_51448();

            stack.method_22903();

            Matrix4f uiMatrix = ModelFormRenderer.getUIMatrix(context, x1, y1, x2, y2);
            CustomVertexConsumerProvider consumers = FormUtilsClient.getProvider();
            float scale = this.form.uiScale.get();
            float width = this.entity.method_17681();
            float height = this.entity.method_17682();

            scale = scale * Math.min(1.8F / Math.max(width, height), 1F);

            this.applyTransforms(uiMatrix, context.getTransition());
            MatrixStackUtils.multiply(stack, uiMatrix);
            stack.method_22905(scale, scale, scale);

            if (!this.form.mobID.get().equals("minecraft:ender_dragon"))
            {
                stack.method_22907(class_7833.field_40716.rotation(MathUtils.PI));
            }

            stack.method_23760().method_23762().getScale(Vectors.EMPTY_3F);
            stack.method_23760().method_23762().scale(1F / Vectors.EMPTY_3F.x, -1F / Vectors.EMPTY_3F.y, 1F / Vectors.EMPTY_3F.z);

            BooleanHolder first = new BooleanHolder();

            CustomVertexConsumerProvider.hijackVertexFormat((layer) ->
            {
                if (!first.bool)
                {
                    this.bindTexture();

                    first.bool = true;
                }
            });

            MobRenderContext mob = MobRenderContext.push(this.getRig(), this.form.pose.get());

            consumers.setUI(true);

            try
            {
                class_310.method_1551().method_1561().method_3954(this.entity, 0D, 0D, 0D, 0F, context.getTransition(), stack, consumers, class_765.field_32769);
                consumers.method_22993();
            }
            finally
            {
                mob.pop();
            }

            consumers.setUI(false);

            CustomVertexConsumerProvider.clearRunnables();

            stack.method_22909();

            RenderSystem.depthFunc(GL11.GL_ALWAYS);
        }
    }

    @Override
    protected void render3D(FormRenderingContext context)
    {
        this.ensureEntity();

        if (this.entity != null)
        {
            /* The vanilla entity pipeline below leaves its own value in the
             * global model-view matrix, so the non-UI cleanup used to wipe it
             * to identity. That identity leaked out of any render that is NOT
             * the film viewport: a placed model block with a mob form nuked
             * the matrix every world frame and the whole UI over it fell
             * apart. Snapshot and restore instead - the film viewport enters
             * here with identity anyway, so its old contract holds. */
            Matrix4f modelView = new Matrix4f(RenderSystem.getModelViewMatrix());

            CustomVertexConsumerProvider consumers = FormUtilsClient.getProvider();
            int light = context.light;
            BooleanHolder first = new BooleanHolder();

            if (context.isPicking())
            {
                CustomVertexConsumerProvider.hijackVertexFormat((layer) ->
                {
                    if (!first.bool)
                    {
                        this.bindTexture();

                        first.bool = true;
                    }

                    /* The picker shader must be (re)applied for every layer, not just the
                     * first one. Entities like the piglin render held items (e.g. the golden
                     * sword) through Minecraft's own item rendering, which adds extra render
                     * layers. If those layers aren't forced onto the picker shader, they get
                     * drawn with vanilla item shaders, leaking GL/shader state that breaks the
                     * picking of any subsequent entity rendered into the stencil framebuffer. */
                    this.setupTarget(context, BBSShaders.getPickerModelsProgram());
                    RenderSystem.setShader(BBSShaders::getPickerModelsProgram);
                });

                /* Sodium's entity fast path cancels ModelPart.render and draws the whole subtree
                 * itself with ONE light value, which is precisely the channel the per-bone ids
                 * ride. It steps aside for a consumer it cannot convert, so the pick pass - one
                 * entity, off the hot path - hands it a plain wrapper and gets vanilla's
                 * part-by-part recursion back. */
                consumers.setSubstitute(MobPickerVertexConsumer::new);

                light = 0;
            }
            else
            {
                CustomVertexConsumerProvider.hijackVertexFormat((layer) ->
                {
                    if (!first.bool)
                    {
                        this.bindTexture();

                        first.bool = true;
                    }
                });
            }

            context.stack.method_22903();
            if (context.world != null)
            {
                context.world.method_22903();
            }

            if (this.form.mobID.get().equals("minecraft:ender_dragon"))
            {
                context.stack.method_22907(class_7833.field_40716.rotation(MathUtils.PI));
                if (context.world != null)
                {
                    context.world.method_22907(class_7833.field_40716.rotation(MathUtils.PI));
                }
            }

            if (this.entity instanceof class_1309 entity)
            {
                int u = context.overlay & '\uffff';
                int v = context.overlay >> 16 & '\uffff';

                entity.field_6235 = v != 10 ? 100 : 0;
            }

            /* Publishing the form's camera-space origin opts its translucent layers (slime
             * bodies, ghost textures) into the deferred sorted pass. */
            if (!context.isPicking())
            {
                Vector3f origin = context.stack.method_23760().method_23761().getTranslation(new Vector3f());

                FormTranslucentQueue.setSortOrigin(new Matrix4f(RenderSystem.getModelViewMatrix()).transformPosition(origin));
            }

            this.bones.clear();

            /* Where the bones are, for the body parts riding them. The same evaluation the gizmo
             * and the anchors read, rather than a capture taken during the render: with Sodium
             * installed vanilla's part recursion does not run at all in a normal frame, and
             * sharing the one evaluation also means the gizmo and the part it moves cannot
             * disagree. */
            if (this.hasBoundBodyParts())
            {
                MobRigMatrices.evaluate(this.entity, this.getRig(), this.form.pose.get(), context.getTransition(), this.bones);
            }

            MobRenderContext mob = MobRenderContext.push(this.getRig(), this.form.pose.get()).picking(context.stencilMap);

            try
            {
                class_310.method_1551().method_1561().method_3954(this.entity, 0D, 0D, 0D, 0F, context.getTransition(), context.stack, consumers, light);
            }
            finally
            {
                mob.pop();
                consumers.setSubstitute(null);
            }

            consumers.method_22993();
            FormTranslucentQueue.setSortOrigin(null);
            CustomVertexConsumerProvider.clearRunnables();

            context.stack.method_22909();

            if (context.world != null)
            {
                context.world.method_22909();
            }

            /* When this MobForm is a body part rendered inside a 2D list/preview (context.ui),
             * it reaches here through the 3D path. The viewport cleanup below would leak into
             * the ongoing 2D batch: resetting the shared model-view matrix to identity drops
             * the GUI transform, so every UI element drawn afterwards lands off-screen — the
             * "half the UI disappears" bug when a MobForm is nested under a ModelForm. In the
             * UI, match the known-good top-level renderInUI path (just fix the depth func,
             * leave the model-view matrix untouched). The 3D viewport keeps its cleanup. */
            if (context.ui)
            {
                RenderSystem.depthFunc(GL11.GL_ALWAYS);
            }
            else
            {
                RenderSystem.enableDepthTest();
                RenderSystem.getModelViewMatrix().set(modelView);
            }
        }
    }

    @Override
    public void tick(IEntity entity)
    {
        this.ensureEntity();
        this.standIn.tick(entity);
    }

    private static class BooleanHolder
    {
        public boolean bool;
    }
}
