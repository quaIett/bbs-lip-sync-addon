package mchorse.bbs_mod.forms.forms;

import mchorse.bbs_mod.ui.utils.icons.Icons;
import mchorse.bbs_mod.ui.utils.icons.Icon;
import mchorse.bbs_mod.settings.values.core.ValuePose;
import mchorse.bbs_mod.settings.values.numeric.ValueBoolean;
import mchorse.bbs_mod.settings.values.core.ValueLink;
import mchorse.bbs_mod.settings.values.core.ValueString;
import mchorse.bbs_mod.utils.pose.Pose;

public class MobForm extends Form implements IPosedForm
{
    /** Also what its main tab in the form editor wears — see {@link Form#getIcon()}. */
    public static final Icon ICON = Icons.MORPH;

    public final ValueString mobID = new ValueString("mobId", "minecraft:chicken");
    public final ValueString mobNBT = new ValueString("mobNbt", "");

    public final ValueLink texture = new ValueLink("texture", null);
    public final ValueBoolean slim = new ValueBoolean("slim", false);

    public final ValuePose pose = new ValuePose("pose", new Pose());

    public final ValueBoolean boneTracks = new ValueBoolean("bone_tracks", true);

    public MobForm()
    {
        this.slim.invisible();
        this.boneTracks.invisible();

        this.add(this.mobID);
        this.add(this.mobNBT);
        this.pose.invisible();
        this.add(this.pose);
        this.add(this.texture);
        this.add(this.slim);
        this.add(this.boneTracks);
    }

    @Override
    public ValuePose getPose()
    {
        return this.pose;
    }

    @Override
    public boolean hasBoneTracks()
    {
        return this.boneTracks.get();
    }

    @Override
    protected String getDefaultDisplayName()
    {
        return this.mobID.get().isEmpty() ? super.getDefaultDisplayName() : this.mobID.get();
    }

    public boolean isPlayer()
    {
        return this.mobID.get().equals("minecraft:player");
    }

    @Override
    public Icon getIcon()
    {
        return ICON;
    }

}