package mchorse.bbs_mod.forms;

import com.mojang.logging.LogUtils;
import mchorse.bbs_mod.BBSMod;
import mchorse.bbs_mod.data.types.BaseType;
import mchorse.bbs_mod.data.types.MapType;
import mchorse.bbs_mod.forms.forms.BodyPart;
import mchorse.bbs_mod.forms.forms.Form;
import mchorse.bbs_mod.forms.forms.IPosedForm;
import mchorse.bbs_mod.forms.forms.ModelForm;
import mchorse.bbs_mod.settings.values.base.BaseValue;
import mchorse.bbs_mod.settings.values.base.BaseValueBasic;
import mchorse.bbs_mod.settings.values.core.ValuePose;
import mchorse.bbs_mod.utils.StringUtils;
import mchorse.bbs_mod.utils.pose.PoseTransform;
import mchorse.bbs_mod.utils.pose.Transform;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class FormUtils
{
    private static final org.slf4j.Logger LOGGER = LogUtils.getLogger();

    public static final String PATH_SEPARATOR = "/";

    public static boolean isPoseProperty(String name)
    {
        return name.startsWith("transform")
            || name.startsWith("pose")
            || name.startsWith("shape_keys");
    }

    /**
     * The euler rotation the renderer sums UNDER the pose's own channels for {@code bone}: the
     * model's rest rotation and the animator's actions, which the pose track cannot see. Feeds the
     * gizmo's {@code GizmoDrag.additiveRotationBase}, so a drag composes its deltas at the bone's
     * EFFECTIVE angles instead of the pose's own channels.
     *
     * @return the base in radians, or {@code null} when there is no purely additive base to speak
     *         of: {@code editedTrack} is not a posed form's pose, or the bone's transform merges
     *         multiplicatively (a quaternion contributor turns the merge into a quaternion product)
     *         — that composition the drag's parent-frame recovery absorbs on its own.
     */
    public static Vector3f additivePoseRotationBase(ValuePose editedTrack, String bone)
    {
        return additivePoseRotationBase(editedTrack, bone, null);
    }

    /**
     * The overload fed by the renderer's EVALUATED channel rotation for the bone (radians, rest +
     * actions + pose): the base is then {@code evaluated − the pose's own contribution}. Falls back
     * to zero when {@code evaluatedRadians} is {@code null} (no model bone entry).
     */
    public static Vector3f additivePoseRotationBase(ValuePose editedTrack, String bone, Vector3f evaluatedRadians)
    {
        Form form = getForm(editedTrack);

        if (!(form instanceof IPosedForm posedForm) || posedForm.getPose() != editedTrack)
        {
            return null;
        }

        PoseTransform transform = editedTrack.get().transforms.get(bone);
        Vector3f editedContribution = new Vector3f();

        if (transform != null)
        {
            /* A fixed bone is lerped toward rest, not summed — no additive base to speak of. */
            if (transform.rotationMode == Transform.RotationMode.QUATERNION || transform.fix != 0F)
            {
                return null;
            }

            editedContribution.set(transform.rotate);
        }

        return evaluatedRadians == null ? new Vector3f() : new Vector3f(evaluatedRadians).sub(editedContribution);
    }

    public static Form fromData(BaseType data)
    {
        if (data instanceof MapType map)
        {
            return fromData(map);
        }

        return null;
    }

    public static Form fromData(MapType data)
    {
        if (data == null)
        {
            return null;
        }

        try
        {
            return BBSMod.getForms().fromData(data);
        }
        catch (Exception e)
        {
            /* A form id this build has no class for comes back as a stand-in now (see
             * UnknownForm), so what reaches here is data that is genuinely broken. That still
             * ends in a lost form — but it no longer ends in silence, which is how a
             * switched-off addon used to eat a scene. */
            LOGGER.error("Failed to read a form out of {}!", data, e);
        }

        return null;
    }

    public static MapType toData(Form form)
    {
        return form == null ? null : BBSMod.getForms().toData(form);
    }

    public static Form copy(Form form)
    {
        if (form != null)
        {
            FormArchitect forms = BBSMod.getForms();

            return forms.fromData(forms.toData(form));
        }

        return null;
    }

    public static Form getRoot(Form form)
    {
        while (form.getParent() != null)
        {
            form = form.getParentForm();
        }

        return form;
    }

    public static Form getForm(BaseValue property)
    {
        if (property.getParent() instanceof Form form)
        {
            return form;
        }

        return null;
    }

    /**
     * Resolve a body-part path — {@code /}-separated stable part ids — starting at {@code form}.
     * Each segment names a part of the current form and steps into that part's form.
     */
    /**
     * Split cache for the two path walkers below: they run per track per frame over a small,
     * stable set of authored paths, and {@code String.split} allocated a fresh array (plus a
     * regex pass) for each. Concurrent map — tracks apply on the client, actions on the server.
     */
    private static final Map<String, String[]> SPLIT_PATHS = new ConcurrentHashMap<>();

    private static String[] splitPath(String path)
    {
        /* A runaway set of generated paths must not pin memory forever. */
        if (SPLIT_PATHS.size() > 4096)
        {
            SPLIT_PATHS.clear();
        }

        return SPLIT_PATHS.computeIfAbsent(path, (p) -> p.split(PATH_SEPARATOR));
    }

    public static Form getForm(Form form, String path)
    {
        for (String s : splitPath(path))
        {
            BodyPart part = form.parts.get(s) instanceof BodyPart bodyPart ? bodyPart : null;

            if (part == null || part.getForm() == null)
            {
                break;
            }

            form = part.getForm();
        }

        return form;
    }

    /**
     * The body-part path of {@code form} from its root — the stable ids of the parts it hangs
     * under, outermost first; empty for the root form itself.
     */
    /**
     * The body part a path names — the part itself, not the form inside it. Null for the root path
     * (the root form hangs off no part) and for a path that does not resolve.
     */
    public static BodyPart getBodyPart(Form root, String path)
    {
        if (root == null || path == null || path.isEmpty())
        {
            return null;
        }

        int split = path.lastIndexOf(PATH_SEPARATOR);
        Form owner = split < 0 ? root : getForm(root, path.substring(0, split));
        String id = split < 0 ? path : path.substring(split + PATH_SEPARATOR.length());

        return owner != null && owner.parts.get(id) instanceof BodyPart part ? part : null;
    }

    public static String getPath(Form form)
    {
        List<String> path = new ArrayList<>();

        appendPartPath(form, path);
        Collections.reverse(path);

        return String.join(PATH_SEPARATOR, path);
    }

    /* Form properties utils */

    /** The property address: its owner form path with the property id as the last segment. */
    public static String getPropertyPath(BaseValue property)
    {
        List<String> path = new ArrayList<>();

        path.add(property.getId());
        appendPartPath(getForm(property), path);
        Collections.reverse(path);

        return String.join(PATH_SEPARATOR, path);
    }

    /** Collect the ids of the body parts above {@code form}, innermost first, into {@code path}. */
    private static void appendPartPath(Form form, List<String> path)
    {
        BaseValue value = form;

        while (value != null)
        {
            if (value instanceof BodyPart part)
            {
                path.add(part.getId());
            }

            value = value.getParent();
        }
    }

    public static List<String> collectPropertyPaths(Form form)
    {
        List<String> properties = new ArrayList<>();

        collectPropertyPaths(form, properties, "");

        /* There is no need to animate body part anchor properties */
        Iterator<String> it = properties.iterator();

        while (it.hasNext())
        {
            if (it.next().endsWith("/anchor"))
            {
                it.remove();
            }
        }

        return properties;
    }

    public static void collectPropertyPaths(Form form, List<String> properties, String prefix)
    {
        if (form == null)
        {
            return;
        }

        for (BaseValue property : form.getAll())
        {
            if (property.isVisible())
            {
                properties.add(StringUtils.combinePaths(prefix, property.getId()));
            }
        }

        for (BodyPart part : form.parts.getAllTyped())
        {
            String newPrefix = StringUtils.combinePaths(prefix, part.getId());

            collectPropertyPaths(part.getForm(), properties, newPrefix);
        }
    }

    /**
     * Resolve a property path — the stable ids of the body parts leading to the owning form,
     * followed by the property's id. A segment that is neither a property nor a part of the
     * current form ends the walk: the path is orphaned (its part was removed or the channel was
     * authored against another form) and resolves to nothing.
     */
    public static BaseValueBasic getProperty(Form form, String path)
    {
        if (form == null)
        {
            return null;
        }

        for (String segment : splitPath(path))
        {
            BaseValueBasic property = form.getBasic(segment);

            if (property != null)
            {
                return property;
            }

            BodyPart part = form.parts.get(segment) instanceof BodyPart bodyPart ? bodyPart : null;

            if (part == null || part.getForm() == null)
            {
                return null;
            }

            form = part.getForm();
        }

        return null;
    }
}