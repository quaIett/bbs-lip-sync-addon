package mchorse.bbs_mod.actions.types.item;

import mchorse.bbs_mod.actions.SuperFakePlayer;
import mchorse.bbs_mod.film.Film;
import mchorse.bbs_mod.film.replays.Replay;
import mchorse.bbs_mod.settings.values.mc.ValueItemStack;
import mchorse.bbs_mod.settings.values.numeric.ValueBoolean;
import mchorse.bbs_mod.settings.values.numeric.ValueInt;
import mchorse.bbs_mod.utils.clips.Clip;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_6880;
import net.minecraft.class_9701;

/**
 * Vanilla's "released the use button" moment: a drawn bow firing its arrow, a
 * trident flying off, a crossbow snapping loaded. Playback re-runs
 * ItemStack.onStoppedUsing() on the fake player, so the projectile is a real
 * server entity with real physics, aimed by the replay's recorded rotations.
 */
public class ReleaseUseItemActionClip extends ItemActionClip
{
    /** Ticks the item was held drawn; restores the vanilla charge on playback. */
    public final ValueInt charge = new ValueInt("charge", 0, 0, 72000);

    /**
     * The ammo vanilla picked during the take. Lent to the fake player's other
     * hand, because its own inventory has no arrows to shoot.
     */
    public final ValueItemStack projectile = new ValueItemStack("projectile");

    /**
     * The take riptided instead of throwing: a riptide trident released while
     * touching water or rain launches its owner and stays in their hand. That
     * condition is the WORLD's, not the item's, and the fake player replaying
     * the release stands dry in whatever world the film plays in - so it's
     * decided at record time and carried here.
     */
    public final ValueBoolean riptide = new ValueBoolean("riptide", false);

    public ReleaseUseItemActionClip()
    {
        super();

        this.add(this.charge);
        this.add(this.projectile);
        this.add(this.riptide);
    }

    @Override
    public void applyAction(class_1309 actor, SuperFakePlayer player, Film film, Replay replay, int tick)
    {
        class_1268 hand = this.hand.get() ? class_1268.field_5808 : class_1268.field_5810;
        class_1268 other = this.hand.get() ? class_1268.field_5810 : class_1268.field_5808;
        class_1799 stack = this.itemStack.get().method_7972();
        class_1799 projectile = this.projectile.get();

        this.applyPositionRotation(player, replay, tick);

        if (this.riptide.get())
        {
            this.applyRiptide(actor, player, stack);

            return;
        }

        /* Use clips leave the fake player's "using an item" flag raised, and a
         * raised flag makes setCurrentHand() refuse to work */
        player.method_6021();
        player.method_6122(hand, stack);

        if (!projectile.method_7960())
        {
            player.method_6122(other, projectile.method_7972());
        }

        player.method_6019(hand);
        stack.method_7930(player.method_37908(), player, Math.max(0, stack.method_7935(player) - this.charge.get()));
        player.method_6021();
        player.method_6122(hand, class_1799.field_8037);
        player.method_6122(other, class_1799.field_8037);
    }

    /**
     * The riptide half of {@code TridentItem.onStoppedUsing} (javap 1.21.1):
     * no trident flies, the owner spins for 20 ticks and the sound the riptide
     * enchantment carries plays. Vanilla's shove ({@code addVelocity}) is
     * deliberately left out - the film already knows where the body goes, and
     * a push on top of that would fight the recorded flight.
     *
     * <p>{@code onStoppedUsing} is not re-run at all here: the fake player
     * stands dry in the playback world, so vanilla would take the other branch
     * and throw the trident the take never let go of.</p>
     */
    private void applyRiptide(class_1309 actor, SuperFakePlayer player, class_1799 stack)
    {
        /* 1.21.1 keeps the three riptide sounds in the enchantment's own data
         * instead of picking one by level, and answers with the throw sound for
         * a trident that spins without one. */
        class_6880<class_3414> sound = class_1890
            .method_60165(stack, class_9701.field_51654)
            .orElse(class_3417.field_15001);

        /* The spin is tracked data, so this is what makes every client show
         * the body whirling - the animator poses it from the same flag.
         * useRiptide() belongs to PlayerEntity; an actor is not one, so it
         * gets the two fields that method sets (javap 1.21.1), and vanilla's
         * own tick counts the spin down and clears the flag from there. */
        if (actor instanceof class_1657 playerActor)
        {
            playerActor.method_40126(20, 8F, stack);
        }
        else if (actor != null)
        {
            actor.field_6261 = 20;
            actor.method_6085(4, true);
        }

        player.method_37908().method_60511(null, player.method_23317(), player.method_23318(), player.method_23321(), sound, class_3419.field_15248, 1F, 1F);
    }

    @Override
    protected Clip create()
    {
        return new ReleaseUseItemActionClip();
    }
}
