package mchorse.bbs_mod.forms;

import com.mojang.blaze3d.systems.RenderSystem;
import mchorse.bbs_mod.client.BBSRendering;
import mchorse.bbs_mod.forms.renderers.utils.RecolorVertexConsumer;
import mchorse.bbs_mod.utils.colors.Color;
import net.minecraft.class_1921;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_291;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_9799;
import net.minecraft.class_9801;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.lwjgl.opengl.GL11;

import java.util.SequencedMap;
import java.util.function.Consumer;
import java.util.function.Function;

public class CustomVertexConsumerProvider extends class_4597.class_4598
{
    private static Consumer<class_1921> runnables;

    private Function<class_4588, class_4588> substitute;
    private Color overlay;
    private boolean ui;

    public static void drawLayer(class_1921 layer)
    {
        if (runnables != null)
        {
            runnables.accept(layer);
        }
    }

    public static void hijackVertexFormat(Consumer<class_1921> runnable)
    {
        runnables = runnable;
    }

    public static void clearRunnables()
    {
        runnables = null;
    }

    public CustomVertexConsumerProvider(class_9799 allocator, SequencedMap<class_1921, class_9799> layers)
    {
        super(allocator, layers);
    }

    public void setSubstitute(Function<class_4588, class_4588> substitute)
    {
        this.substitute = substitute;

        if (this.substitute == null)
        {
            RecolorVertexConsumer.newColor = null;
        }
    }

    /**
     * The color overlay a deferred layer has to be drawn with. A layer that defers is drawn from
     * the translucent queue long after the renderer's per-layer hook unbound the overlay texture,
     * so the color travels with the command instead. Null while nothing sets one.
     */
    public void setOverlay(Color overlay)
    {
        this.overlay = overlay;
    }

    public void setUI(boolean ui)
    {
        this.ui = ui;
    }

    @Override
    public class_4588 getBuffer(class_1921 renderLayer)
    {
        class_4588 buffer = super.getBuffer(renderLayer);

        if (this.substitute != null)
        {
            class_4588 apply = this.substitute.apply(buffer);

            if (apply != null)
            {
                return apply;
            }
        }

        return buffer;
    }

    /**
     * Translucent layers of buffered forms (blocks, items) defer into the frame's sorted
     * translucent queue instead of drawing immediately — otherwise their semi-transparent
     * pixels write depth mid-frame and occlude forms drawn after them. Active only when the
     * current form renderer published its sort origin (never in picking or UI paths).
     */
    @Override
    public void method_22994(class_1921 layer)
    {
        Vector3f origin = FormTranslucentQueue.getSortOrigin();

        /* Text layers defer only inside a recorded group (labels), where the group preserves
         * the text-over-background order. */
        boolean textLayer = FormTranslucentQueue.isGroupOpen() && layer.method_23031() == class_290.field_20888;

        if (origin == null || !FormTranslucentQueue.isActive() || !(textLayer || isDeferrableTranslucent(layer)))
        {
            super.method_22994(layer);

            return;
        }

        /* Same bookkeeping as the vanilla draw (claim the layer's pending builder, sort a
         * translucent layer's quads, clear the current layer), except the built geometry is
         * retained in our own vertex buffer and replayed by the queue instead of drawn now. */
        class_287 builder = this.field_52157.remove(layer);

        if (builder == null)
        {
            return;
        }

        class_9801 built = builder.method_60794();

        if (built != null)
        {
            if (layer.method_60894())
            {
                built.method_60819(this.field_20953.getOrDefault(layer, this.field_52156), RenderSystem.getVertexSorting());
            }

            /* Uploading the layer's buffer here is what the immediate provider's own draw would
             * have done — including the vertex layout Iris pins around it. */
            boolean extended = BBSRendering.beginIrisBufferUpload(builder);
            class_291 buffer = new class_291(class_291.class_8555.field_44793);

            try
            {
                buffer.method_1353();
                buffer.method_1352(built);
                class_291.method_1354();
            }
            finally
            {
                BBSRendering.endIrisBufferUpload(extended);
            }

            FormTranslucentQueue.add(new FormTranslucentQueue.RenderLayerCommand(layer, buffer, new Matrix4f(RenderSystem.getModelViewMatrix()), new Vector3f(origin)).overlayColor(this.overlay));
        }

        if (layer.equals(this.field_52158))
        {
            this.field_52158 = null;
        }
    }

    private static boolean isDeferrableTranslucent(class_1921 layer)
    {
        String name = layer.toString();

        return name.contains("translucent") && !name.contains("glint");
    }

    @Override
    public void method_22993()
    {
        super.method_22993();

        if (this.ui)
        {
            /* Force back the depth func because it seems like stuff rendered by a vertex
             * consumer is resetting the depth func to GL_LESS, and since this vertex consumer
             * is designed  */
            RenderSystem.depthFunc(GL11.GL_ALWAYS);
        }
    }
}
