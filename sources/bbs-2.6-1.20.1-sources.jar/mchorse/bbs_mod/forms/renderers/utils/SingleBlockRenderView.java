package mchorse.bbs_mod.forms.renderers.utils;

import net.minecraft.class_1920;
import net.minecraft.class_1944;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3568;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_638;
import net.minecraft.class_6539;

/**
 * A world of exactly one block, sitting at {@link class_2338#field_10980} with air all around it.
 *
 * <p>Fluids are the one thing vanilla never bakes into a block model: a water or lava state
 * renders as {@link net.minecraft.class_2464#field_11455}, and its geometry gets
 * generated per chunk section by {@link net.minecraft.class_775},
 * which needs a world to ask about neighbours, light and the biome tint. A form has no world,
 * so it hands the fluid renderer this one: air on every side (so every face draws), the
 * form's own packed light, and the biome tint read from wherever the camera stands.</p>
 *
 * <p>The origin is not arbitrary — the fluid renderer emits vertices at
 * {@code pos.getX() & 15}, chunk local coordinates, so only a position at a section corner
 * puts the block into 0..1.</p>
 */
public class SingleBlockRenderView implements class_1920
{
    /** Water tint of the plains biome — the fallback when there is no world to sample. */
    private static final int DEFAULT_TINT = 0x3F76E4;

    private class_2680 state = class_2246.field_10124.method_9564();
    private class_3610 fluidState = class_3612.field_15906.method_15785();
    private int light;

    public SingleBlockRenderView set(class_2680 state, int light)
    {
        this.state = state;
        this.fluidState = state.method_26227();
        this.light = light;

        return this;
    }

    @Override
    public class_2680 method_8320(class_2338 pos)
    {
        return pos.equals(class_2338.field_10980) ? this.state : class_2246.field_10124.method_9564();
    }

    @Override
    public class_3610 method_8316(class_2338 pos)
    {
        return pos.equals(class_2338.field_10980) ? this.fluidState : class_3612.field_15906.method_15785();
    }

    @Override
    public class_2586 method_8321(class_2338 pos)
    {
        return null;
    }

    @Override
    public float method_24852(class_2350 direction, boolean shaded)
    {
        if (!shaded)
        {
            return 1F;
        }

        return switch (direction)
        {
            case field_11033 -> 0.5F;
            case field_11043, field_11035 -> 0.8F;
            case field_11039, field_11034 -> 0.6F;
            default -> 1F;
        };
    }

    @Override
    public class_3568 method_22336()
    {
        /* Never reached: both light lookups below are overridden, and they are the only
         * things that would go through a lighting provider. */
        return null;
    }

    @Override
    public int method_8314(class_1944 type, class_2338 pos)
    {
        return type == class_1944.field_9284 ? (this.light >> 20) & 0xF : (this.light >> 4) & 0xF;
    }

    @Override
    public int method_22335(class_2338 pos, int ambientDarkness)
    {
        return Math.max(this.method_8314(class_1944.field_9284, pos) - ambientDarkness, this.method_8314(class_1944.field_9282, pos));
    }

    @Override
    public int method_23752(class_2338 pos, class_6539 colorResolver)
    {
        class_638 world = class_310.method_1551().field_1687;

        if (world != null)
        {
            /* The form has no place in the world of its own — biome tint comes from where
             * the camera is, so a water form matches the water it stands next to. */
            return world.method_23752(class_2338.method_49638(class_310.method_1551().field_1773.method_19418().method_19326()), colorResolver);
        }

        return DEFAULT_TINT;
    }

    @Override
    public int method_31605()
    {
        return 384;
    }

    @Override
    public int method_31607()
    {
        return -64;
    }
}
