package mchorse.bbs_mod.forms.renderers.mob;

import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.class_583;

/**
 * The rig cache, keyed by the {@link class_583} INSTANCE.
 *
 * <p>Not by entity class, which is what the mob form used to do: a slim and a wide player are both
 * {@code OtherClientPlayerEntity} but render through two different {@code PlayerEntityModel}
 * instances, so whichever drew first won the cache and the pose was then written into the other
 * model's parts. Models are per-renderer singletons, so one entry per model is also the smallest
 * the cache can be.</p>
 */
public class MobRigs
{
    private static final Map<class_583, MobRig> CACHE = new WeakHashMap<>();

    public static MobRig of(class_583 model)
    {
        if (model == null)
        {
            return null;
        }

        return CACHE.computeIfAbsent(model, MobRig::new);
    }

    public static void clear()
    {
        CACHE.clear();
    }
}
