package mchorse.bbs_mod.forms.renderers.mob;

import mchorse.bbs_mod.mixin.client.LivingEntityRendererInvoker;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_583;
import net.minecraft.class_922;

/**
 * Vanilla's own posing of a living entity's model, without a render: the flags the living entity
 * renderer sets before drawing, then {@code animateModel} and {@code setAngles} with the numbers it
 * would pass. The mob form's offline matrices ({@link MobRigMatrices}) and the CEM stage
 * ({@code CemVanillaStage}) both pose the model this way, from one place, so the two cannot drift apart.
 *
 * <p>Model parts are shared with the world's real entities of that kind. The pose left here is the
 * one every render of them overwrites first thing, so it costs nobody anything — except while an
 * entity render is in flight, which is the one moment the writes would be seen: {@link #renderer}
 * answers null then.</p>
 */
public class VanillaPose
{
    /**
     * The renderer a living entity draws through, or null when there is nothing to pose: an entity that
     * is not living, one no living renderer takes, or an entity render in flight.
     */
    public static class_922 renderer(class_1297 entity)
    {
        if (MobRenderContext.current() != null || !(entity instanceof class_1309))
        {
            return null;
        }

        return class_310.method_1551().method_1561().method_3953(entity) instanceof class_922 renderer ? renderer : null;
    }

    /** Pose the renderer's model for this frame of the entity, the way {@code LivingEntityRenderer.render} does before it draws. */
    public static void animate(class_922 renderer, class_1309 living, float transition)
    {
        class_583 model = renderer.method_4038();
        LivingEntityRendererInvoker invoker = (LivingEntityRendererInvoker) renderer;

        model.field_3447 = invoker.bbs$getHandSwingProgress(living, transition);
        model.field_3449 = living.method_5765();
        model.field_3448 = living.method_6109();

        float bodyYaw = class_3532.method_17821(transition, living.field_6220, living.field_6283);
        float headYaw = class_3532.method_17821(transition, living.field_6259, living.field_6241);
        float pitch = class_3532.method_16439(transition, living.field_6004, living.method_36455());
        float animationProgress = invoker.bbs$getAnimationCounter(living, transition);
        float limbDistance = 0F;
        float limbAngle = 0F;

        if (!living.method_5765() && living.method_5805())
        {
            limbDistance = Math.min(living.field_42108.method_48570(transition), 1F);
            limbAngle = living.field_42108.method_48572(transition) * (living.method_6109() ? 3F : 1F);
        }

        model.method_2816(living, limbAngle, limbDistance, transition);
        model.method_2819(living, limbAngle, limbDistance, animationProgress, headYaw - bodyYaw, pitch);
    }
}
