package mchorse.bbs_mod.forms.entities;

import mchorse.bbs_mod.cubic.jem.CemVariables;
import mchorse.bbs_mod.film.replays.ReplayKeyframes;
import mchorse.bbs_mod.forms.forms.Form;
import mchorse.bbs_mod.utils.AABB;
import mchorse.bbs_mod.utils.interps.Lerps;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4050;
import net.minecraft.class_8080;
import java.util.HashMap;
import java.util.Map;

public class StubEntity implements IEntity
{
    private class_1937 world;
    private int age;

    private Form form;
    private boolean sneaking;
    private boolean sprinting;
    private boolean onGround = true;
    private boolean swimming;
    private boolean riding;
    private boolean flying;
    private boolean fallFlying;
    private float fallDistance;
    private int hurtTimer;
    private int deathTime;

    /** Hands every stub its own {@link #getId()}: a number that stays put for the life of the instance. */
    private static int nextId;

    private final int id = nextId++;

    private float prevLeaningPitch;
    private float leaningPitch;
    private int roll;

    private class_243 prevVelocity = class_243.field_1353;

    private double prevX;
    private double prevY;
    private double prevZ;
    private double x;
    private double y;
    private double z;

    private float prevYaw;
    private float prevHeadYaw;
    private float prevPitch;
    private float prevBodyYaw;
    private float prevPrevBodyYaw;

    private float yaw;
    private float headYaw;
    private float pitch;
    private float bodyYaw;

    private int armSwing;

    private class_243 velocity = class_243.field_1353;

    private float[] extraVariables = new float[10];
    private float[] prevExtraVariables = new float[10];

    private class_8080 limbAnimator = new class_8080();
    private final Map<class_1304, class_1799> items = new HashMap<>();
    private final class_1799[] hotbar = new class_1799[ReplayKeyframes.HOTBAR_SIZE];

    public StubEntity(class_1937 world)
    {
        this.world = world;
    }

    public StubEntity()
    {
        for (class_1304 value : class_1304.values())
        {
            this.items.put(value, class_1799.field_8037);
        }
    }

    @Override
    public void setWorld(class_1937 world)
    {
        this.world = world;
    }

    @Override
    public class_1937 getWorld()
    {
        return this.world;
    }

    @Override
    public Form getForm()
    {
        return this.form;
    }

    @Override
    public void setForm(Form form)
    {
        this.form = form;
    }

    @Override
    public class_1799 getEquipmentStack(class_1304 slot)
    {
        return this.items.getOrDefault(slot, class_1799.field_8037);
    }

    @Override
    public void setEquipmentStack(class_1304 slot, class_1799 stack)
    {
        if (stack == null)
        {
            stack = class_1799.field_8037;
        }

        this.items.put(slot, stack);
    }

    @Override
    public class_1799 getHotbarStack(int slot)
    {
        class_1799 stack = slot >= 0 && slot < this.hotbar.length ? this.hotbar[slot] : null;

        return stack == null ? class_1799.field_8037 : stack;
    }

    @Override
    public void setHotbarStack(int slot, class_1799 stack)
    {
        if (slot >= 0 && slot < this.hotbar.length)
        {
            this.hotbar[slot] = stack == null ? class_1799.field_8037 : stack;
        }
    }

    @Override
    public int getSelectedSlot()
    {
        return 0;
    }

    @Override
    public boolean isSneaking()
    {
        return this.sneaking;
    }

    @Override
    public void setSneaking(boolean sneaking)
    {
        this.sneaking = sneaking;
    }

    @Override
    public boolean isSprinting()
    {
        return this.sprinting;
    }

    @Override
    public void setSprinting(boolean sprinting)
    {
        this.sprinting = sprinting;
    }

    @Override
    public boolean isOnGround()
    {
        return this.onGround;
    }

    @Override
    public void setOnGround(boolean ground)
    {
        this.onGround = ground;
    }

    @Override
    public boolean isSwimming()
    {
        return this.swimming;
    }

    @Override
    public void setSwimming(boolean swimming)
    {
        this.swimming = swimming;
    }

    @Override
    public boolean isRiding()
    {
        return this.riding;
    }

    @Override
    public void setRiding(boolean riding)
    {
        this.riding = riding;
    }

    @Override
    public boolean isFlying()
    {
        return this.flying;
    }

    @Override
    public void setFlying(boolean flying)
    {
        this.flying = flying;
    }

    @Override
    public void swingArm()
    {
        this.armSwing = 6;
    }

    @Override
    public float getHandSwingProgress(float tickDelta)
    {
        return this.armSwing <= 0 ? 0F : 1F - (this.armSwing - tickDelta) / 6F;
    }

    /** This one stands in for an actor; it never spawned. See {@link IEntity#isStandIn()}. */
    @Override
    public boolean isStandIn()
    {
        return true;
    }

    /** Lazily made: an entity that never renders a CEM model never allocates one. */
    private CemVariables cemVariables;

    /**
     * The CEM variables of this entity, made on first use — every CEM model rendered on it shares them,
     * which is how a pack's cape follows its body. See {@link CemVariables}.
     */
    @Override
    public CemVariables getCemVariables()
    {
        if (this.cemVariables == null)
        {
            this.cemVariables = new CemVariables();
        }

        return this.cemVariables;
    }

    @Override
    public int getAge()
    {
        return this.age;
    }

    @Override
    public void setAge(int ticks)
    {
        this.age = ticks;
    }

    @Override
    public float getFallDistance()
    {
        return this.fallDistance;
    }

    @Override
    public void setFallDistance(float fallDistance)
    {
        this.fallDistance = fallDistance;
    }

    @Override
    public int getHurtTimer()
    {
        return this.hurtTimer;
    }

    @Override
    public void setHurtTimer(int hurtTimer)
    {
        this.hurtTimer = hurtTimer;
    }

    @Override
    public int getDeathTime()
    {
        return this.deathTime;
    }

    @Override
    public void setDeathTime(int deathTime)
    {
        this.deathTime = deathTime;
    }

    @Override
    public int getId()
    {
        return this.id;
    }

    @Override
    public double getX()
    {
        return this.x;
    }

    @Override
    public double getPrevX()
    {
        return this.prevX;
    }

    @Override
    public void setPrevX(double x)
    {
        this.prevX = x;
    }

    @Override
    public double getY()
    {
        return this.y;
    }

    @Override
    public double getPrevY()
    {
        return this.prevY;
    }

    @Override
    public void setPrevY(double y)
    {
        this.prevY = y;
    }

    @Override
    public double getZ()
    {
        return this.z;
    }

    @Override
    public double getPrevZ()
    {
        return this.prevZ;
    }

    @Override
    public void setPrevZ(double z)
    {
        this.prevZ = z;
    }

    @Override
    public void setPosition(double x, double y, double z)
    {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    @Override
    public double getEyeHeight()
    {
        return 1.8F * 0.9F;
    }

    @Override
    public class_243 getVelocity()
    {
        return this.velocity;
    }

    @Override
    public void setVelocity(float x, float y, float z)
    {
        this.velocity = new class_243(x, y, z);
    }

    @Override
    public float getYaw()
    {
        return this.yaw;
    }

    @Override
    public float getPrevYaw()
    {
        return this.prevYaw;
    }

    @Override
    public void setYaw(float yaw)
    {
        this.yaw = yaw;
    }

    @Override
    public void setPrevYaw(float prevYaw)
    {
        this.prevYaw = prevYaw;
    }

    @Override
    public float getHeadYaw()
    {
        return this.headYaw;
    }

    @Override
    public float getPrevHeadYaw()
    {
        return this.prevHeadYaw;
    }

    @Override
    public void setHeadYaw(float headYaw)
    {
        this.headYaw = headYaw;
    }

    @Override
    public void setPrevHeadYaw(float prevHeadYaw)
    {
        this.prevHeadYaw = prevHeadYaw;
    }

    @Override
    public float getPitch()
    {
        return this.pitch;
    }

    @Override
    public float getPrevPitch()
    {
        return this.prevPitch;
    }

    @Override
    public void setPitch(float pitch)
    {
        this.pitch = pitch;
    }

    @Override
    public void setPrevPitch(float prevPitch)
    {
        this.prevPitch = prevPitch;
    }

    @Override
    public float getBodyYaw()
    {
        return this.bodyYaw;
    }

    @Override
    public float getPrevBodyYaw()
    {
        return this.prevBodyYaw;
    }

    @Override
    public float getPrevPrevBodyYaw()
    {
        return this.prevPrevBodyYaw;
    }

    @Override
    public void setBodyYaw(float bodyYaw)
    {
        this.bodyYaw = bodyYaw;
    }

    @Override
    public void setPrevBodyYaw(float prevBodyYaw)
    {
        this.prevBodyYaw = prevBodyYaw;
    }

    @Override
    public void setPrevPrevBodyYaw(float prevPrevBodyYaw)
    {
        this.prevPrevBodyYaw = prevPrevBodyYaw;
    }

    @Override
    public float[] getExtraVariables()
    {
        return this.extraVariables;
    }

    @Override
    public float[] getPrevExtraVariables()
    {
        return this.prevExtraVariables;
    }

    @Override
    public AABB getPickingHitbox()
    {
        Form form = this.getForm();
        float w = 0.6F;
        float h = 1.8F;

        if (form != null && form.hitbox.get())
        {
            w = form.hitboxWidth.get();
            h = form.hitboxHeight.get();
        }

        return new AABB(
            this.getX() - w / 2, this.getY(), this.getZ() - w / 2,
            w, h, w
        );
    }

    @Override
    public void update()
    {
        float delta = (float) class_3532.method_33825(this.x - this.prevX, 0D, this.z - this.prevZ);
        float speed = Math.min(delta * 4F, 1F);

        this.limbAnimator.method_48568(speed, 0.4F, 1.0F);

        this.armSwing -= 1;
        this.age += 1;

        this.prevX = this.x;
        this.prevY = this.y;
        this.prevZ = this.z;

        this.prevPrevBodyYaw = this.prevBodyYaw;
        this.prevLeaningPitch = this.leaningPitch;
        this.prevVelocity = this.velocity;

        this.prevYaw = this.yaw;
        this.prevHeadYaw = this.headYaw;
        this.prevPitch = this.pitch;
        this.prevBodyYaw = this.bodyYaw;

        for (int i = 0; i < this.extraVariables.length; i++)
        {
            this.prevExtraVariables[i] = this.extraVariables[i];
        }
    }

    @Override
    public class_8080 getLimbAnimator()
    {
        return this.limbAnimator;
    }

    @Override
    public float getLimbPos(float tickDelta)
    {
        /* 1.21.11: getPos(tickDelta) became getAnimationProgress(tickDelta) (the ever-growing walk phase) */
        return this.limbAnimator.method_48572(tickDelta);
    }

    @Override
    public float getLimbSpeed(float tickDelta)
    {
        /* 1.21.11: getSpeed(tickDelta) became getAmplitude(tickDelta) (interpolated limb swing amount) */
        return this.limbAnimator.method_48570(tickDelta);
    }

    @Override
    public float getLeaningPitch(float tickDelta)
    {
        return Lerps.lerp(this.prevLeaningPitch, this.leaningPitch, tickDelta);
    }

    @Override
    public void setLeaningPitch(float leaningPitch)
    {
        this.leaningPitch = leaningPitch;
    }

    /**
     * A stub is never anywhere, so being in water is read off the lean: vanilla only grows it
     * while swimming, and swimming is what the flag is asked about - it picks whether the body
     * lies flat or follows the pitch.
     */
    @Override
    public boolean isTouchingWater()
    {
        return this.leaningPitch > 0F;
    }

    @Override
    public class_4050 getEntityPose()
    {
        return EntityState.pose(this);
    }

    @Override
    public int getRoll()
    {
        return this.roll;
    }

    @Override
    public void setRoll(int roll)
    {
        this.roll = roll;
    }

    @Override
    public boolean isFallFlying()
    {
        return this.fallFlying;
    }

    @Override
    public void setFallFlying(boolean fallFlying)
    {
        this.fallFlying = fallFlying;
    }

    @Override
    public class_243 getRotationVec(float transition)
    {
        float pitch = Lerps.lerp(this.prevPitch, this.pitch, transition);
        float yaw = Lerps.lerp(this.prevYaw, this.yaw, transition);

        return class_243.method_1030(pitch, yaw);
    }

    @Override
    public class_243 lerpVelocity(float transition)
    {
        return this.prevVelocity.method_35590(this.velocity, transition);
    }

    @Override
    public boolean isUsingRiptide()
    {
        return false;
    }
}