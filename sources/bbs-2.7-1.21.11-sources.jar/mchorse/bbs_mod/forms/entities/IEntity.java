package mchorse.bbs_mod.forms.entities;

import mchorse.bbs_mod.cubic.jem.CemVariables;
import mchorse.bbs_mod.forms.forms.Form;
import mchorse.bbs_mod.utils.AABB;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_4050;
import net.minecraft.class_8080;

/**
 * Interface that provides access to an "Entity" within forms for rendering
 * and updating.
 */
public interface IEntity
{
    public void setWorld(class_1937 world);

    public class_1937 getWorld();

    public Form getForm();

    public void setForm(Form form);

    public class_1799 getEquipmentStack(class_1304 slot);

    public void setEquipmentStack(class_1304 slot, class_1799 stack);

    /**
     * Hotbar cell at given index. Entities without a hotbar of their own (mobs, actors) still
     * answer for slot 0 with their main hand, since {@link #getSelectedSlot()} keeps them there
     * - so "the hand is the selected hotbar slot" holds for everyone.
     */
    public class_1799 getHotbarStack(int slot);

    public void setHotbarStack(int slot, class_1799 stack);

    /**
     * Whether the main hand is a view of the hotbar rather than a slot of its own.
     *
     * On a player it is: the hand is the selected cell, so writing to it means writing into
     * whichever cell is selected at that instant - and during playback the selection can still
     * be a frame behind, which drops the item into the cell the player just left.
     */
    public default boolean isMainHandInHotbar()
    {
        return false;
    }

    public int getSelectedSlot();

    public boolean isSneaking();

    public void setSneaking(boolean sneaking);

    public boolean isSprinting();

    public void setSprinting(boolean sprinting);

    public boolean isOnGround();

    public void setOnGround(boolean ground);

    public boolean isSwimming();

    public void setSwimming(boolean swimming);

    /**
     * Whether the entity rides something. A replay only writes the fact down - it never mounts
     * anyone, since the frame already says where the rider is - so this drives the pose and the
     * animation and nothing else.
     */
    public boolean isRiding();

    public void setRiding(boolean riding);

    /** Creative flight, as opposed to {@link #isFallFlying()}, which is an elytra. */
    public boolean isFlying();

    public void setFlying(boolean flying);

    public void swingArm();

    public float getHandSwingProgress(float tickDelta);

    public int getAge();

    /**
     * Whether this stands in for an actor rather than wrapping a Minecraft entity that actually spawned.
     *
     * <p>It is the age that makes the difference. A stand-in's age counts from the moment BBS made the
     * object — a film loading, a panel opening — not from a spawn in the world, and an animation that
     * treats a small age as "just spawned" then replays a spawn every time.</p>
     */
    public default boolean isStandIn()
    {
        return false;
    }

    /**
     * The CEM variables of this entity, or null when this implementation keeps none (every CEM model on
     * it then animates on its own, the way they all did before).
     *
     * <p>OptiFine scopes a pack's {@code var.*}/{@code varb.*} to the entity, so its models can read each
     * other — see {@link CemVariables}. Created on first use: an entity that never renders a .jem never
     * allocates one.</p>
     */
    public default CemVariables getCemVariables()
    {
        return null;
    }

    public void setAge(int ticks);

    public float getFallDistance();

    public void setFallDistance(float fallDistance);

    public int getHurtTimer();

    public void setHurtTimer(int hurtTimer);

    /** A stable identity for per-entity variety (CEM's {@code id}): the MC entity id, or a per-instance number for a stub. */
    public default int getId()
    {
        return 0;
    }

    /** Ticks since the entity died (vanilla {@code LivingEntity.deathTime}); 0 while alive. */
    public default int getDeathTime()
    {
        return 0;
    }

    /**
     * Only a body drawn by something else has this written to it: a real entity counts its own
     * death, a stub is told about the one its actor shell is going through (see the film
     * controller), and everything else has no death to speak of.
     */
    public default void setDeathTime(int deathTime)
    {}

    /** Whether something rides this entity — the opposite of {@link #isRiding()}. */
    public default boolean isRidden()
    {
        return false;
    }

    /** Whether this is the baby variant of its kind. */
    public default boolean isChild()
    {
        return false;
    }

    /**
     * Vanilla's health for an entity that declares none: a whole one. Zero is not a neutral stand-in
     * for "unknown" — a CEM pack reads health as a fraction of the maximum and poses the entity by it,
     * so Fresh Animations' iron golem, whose whole file is written around {@code if(health<=15, ...)},
     * spent every frame in its dying posture, and its magma cube divided by {@code sqrt(max_health)}.
     */
    public static final float FULL_HEALTH = 20F;

    /** Health left, in half-hearts, as CEM's {@code health}. */
    public default float getHealth()
    {
        return FULL_HEALTH;
    }

    /** Health at full, in half-hearts, as CEM's {@code max_health}. Never zero: packs divide by it. */
    public default float getMaxHealth()
    {
        return FULL_HEALTH;
    }

    /** On fire, as CEM's {@code is_burning}. */
    public default boolean isBurning()
    {
        return false;
    }

    /** Standing in lava, as CEM's {@code is_in_lava}. */
    public default boolean isInLava()
    {
        return false;
    }

    /** Holding onto a ladder or a vine, as CEM's {@code is_climbing}. */
    public default boolean isClimbing()
    {
        return false;
    }

    /** Crawling under a low ceiling, as CEM's {@code is_crawling}. */
    public default boolean isCrawling()
    {
        return false;
    }

    /**
     * Sitting down, as CEM's {@code is_sitting} — a tamed pet ordered to stay, a fox asleep, a roosting
     * bat. It is a pose the entity holds, not a posture the animation passes through.
     */
    public default boolean isSitting()
    {
        return false;
    }

    /** Tamed by a player, as CEM's {@code is_tamed}. */
    public default boolean isTamed()
    {
        return false;
    }

    /** Attacking or angered, as CEM's {@code is_aggressive}. */
    public default boolean isAggressive()
    {
        return false;
    }

    /** Riding a player's shoulder, as CEM's {@code is_on_shoulder} — a parrot, and nothing else in vanilla. */
    public default boolean isOnShoulder()
    {
        return false;
    }

    /**
     * Which arm the main hand is, as CEM's {@code is_right_handed}. Vanilla's default, and not a detail:
     * Fresh Animations' player asks it twenty times over and hands every idle sway, every equipment pose
     * and every block to one arm or the other by the answer, so a false one mirrors the whole model.
     */
    public default boolean isRightHanded()
    {
        return true;
    }

    /** Eating, drinking, drawing a bow, raising a shield — as CEM's {@code is_using_item}. */
    public default boolean isUsingItem()
    {
        return false;
    }

    /** Holding a shield up, as CEM's {@code is_blocking}. */
    public default boolean isBlocking()
    {
        return false;
    }

    /** Mid-swing — which arm is {@link #isSwingingOffHand()}'s business. */
    public default boolean isSwinging()
    {
        return false;
    }

    /** Whether the swing belongs to the off hand rather than the main one. */
    public default boolean isSwingingOffHand()
    {
        return false;
    }

    /** How hard the entity walks forward, as CEM's {@code move_forward}: its own input, not its velocity. */
    public default float getForwardSpeed()
    {
        return 0F;
    }

    /** The same sideways, as CEM's {@code move_strafing}. */
    public default float getSidewaysSpeed()
    {
        return 0F;
    }

    public double getX();

    public double getPrevX();

    public void setPrevX(double x);

    public double getY();

    public double getPrevY();

    public void setPrevY(double y);

    public double getZ();

    public double getPrevZ();

    public void setPrevZ(double z);

    public void setPosition(double x, double y, double z);

    public double getEyeHeight();

    public class_243 getVelocity();

    public void setVelocity(float x, float y, float z);

    public float getYaw();

    public float getPrevYaw();

    public void setYaw(float yaw);

    public void setPrevYaw(float prevYaw);

    public float getHeadYaw();

    public float getPrevHeadYaw();

    public void setHeadYaw(float headYaw);

    public void setPrevHeadYaw(float prevHeadYaw);

    public float getPitch();

    public float getPrevPitch();

    public void setPitch(float pitch);

    public void setPrevPitch(float prevPitch);

    public float getBodyYaw();

    public float getPrevBodyYaw();

    public float getPrevPrevBodyYaw();

    public void setBodyYaw(float bodyYaw);

    public void setPrevBodyYaw(float prevBodyYaw);

    public void setPrevPrevBodyYaw(float prevPrevBodyYaw);

    public float[] getExtraVariables();

    public float[] getPrevExtraVariables();

    public AABB getPickingHitbox();

    public void update();

    public default void copy(IEntity entity)
    {
        this.setForm(entity.getForm());

        for (EntityState state : EntityState.values())
        {
            state.set(this, state.get(entity));
        }

        this.setFallDistance(entity.getFallDistance());
        this.setHurtTimer(entity.getHurtTimer());

        this.setPrevX(entity.getPrevX());
        this.setPrevY(entity.getPrevY());
        this.setPrevZ(entity.getPrevZ());
        this.setPosition(entity.getX(), entity.getY(), entity.getZ());

        this.setPrevYaw(entity.getPrevYaw());
        this.setPrevHeadYaw(entity.getPrevHeadYaw());
        this.setPrevPitch(entity.getPrevPitch());
        this.setPrevBodyYaw(entity.getPrevBodyYaw());
        this.setPrevPrevBodyYaw(entity.getPrevPrevBodyYaw());

        this.setYaw(entity.getYaw());
        this.setHeadYaw(entity.getHeadYaw());
        this.setPitch(entity.getPitch());
        this.setBodyYaw(entity.getBodyYaw());

        this.setVelocity((float) entity.getVelocity().field_1352, (float) entity.getVelocity().field_1351, (float) entity.getVelocity().field_1350);

        float[] extraVariables = this.getExtraVariables();
        float[] prevExtraVariables = this.getPrevExtraVariables();

        for (int i = 0; i < extraVariables.length; i++)
        {
            extraVariables[i] = entity.getExtraVariables()[i];
            prevExtraVariables[i] = entity.getPrevExtraVariables()[i];
        }
    }

    public class_8080 getLimbAnimator();

    public float getLimbPos(float tickDelta);

    public float getLimbSpeed(float tickDelta);

    /* Swimming */

    public float getLeaningPitch(float tickDelta);

    /**
     * How far the body has leant into a swim, 0 to 1.
     *
     * <p>Vanilla grows this a step per tick while the entity is in a swimming pose. A replay
     * can't do that: a timeline is random access, and anything a playback accumulates tick by
     * tick is wrong the moment someone scrubs to the middle of a swim. So the lean is recorded
     * as a value of its own and handed back here.</p>
     */
    public void setLeaningPitch(float leaningPitch);

    public boolean isTouchingWater();

    public class_4050 getEntityPose();

    public int getRoll();

    /** Ticks of roll, which ramps the elytra's dive and spins a riptide. Recorded, not counted. */
    public void setRoll(int roll);

    public boolean isFallFlying();

    public void setFallFlying(boolean fallFlying);

    public class_243 getRotationVec(float transition);

    public class_243 lerpVelocity(float transition);

    public boolean isUsingRiptide();
}