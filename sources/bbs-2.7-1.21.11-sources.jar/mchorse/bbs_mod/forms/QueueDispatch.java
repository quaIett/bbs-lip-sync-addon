package mchorse.bbs_mod.forms;

import net.minecraft.class_11659;
import net.minecraft.class_11684;
import net.minecraft.class_12075;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import org.joml.Quaternionf;

/**
 * BBS's own command queue + flusher for drawing vanilla-rendered things (entities, their held
 * items, name-tag text, fire) OUTSIDE the world's entity pass — in the film's form pass and in
 * UI viewports.
 *
 * <p>The 1.21.2 render-state split removed every immediate entity-drawing API: renderers only
 * <em>submit commands</em> into an {@link class_11659}, and the queue is flushed
 * once per frame by the world's {@link class_11684}. BBS draws forms at its own moments
 * (AFTER_ENTITIES, editor FBO passes), so it owns a private queue and flushes it synchronously:
 * submit through {@link #queue()}, then {@link #flush()} right after. The dispatcher is built
 * over {@link FormUtilsClient#getProvider()} — the BBS recolor/substitution provider — so every
 * command family renders through the same {@code VertexConsumerProvider} the rest of the form
 * pipeline uses (and the substitution hooks keep working).
 *
 * <p>Layered customs (the new particle path) are deliberately NOT flushed through the vanilla
 * {@code LayeredCustomCommandRenderer}: it binds the client framebuffer directly (checked against
 * the 1.21.11 bytecode), which would punch UI-viewport draws onto the screen. Nothing BBS submits
 * uses them; the world's own particles go through the world's dispatcher as always.
 *
 * <p>Render thread only, non-reentrant by design (a flush must complete before the next submit
 * cycle; nested form-in-form draws all land in the same cycle before the single flush).
 */
public class QueueDispatch
{
    private static class_11684 dispatcher;

    private static class_11684 get()
    {
        if (dispatcher == null)
        {
            class_310 mc = class_310.method_1551();

            dispatcher = new class_11684(
                new net.minecraft.class_11661(),
                mc.method_1541(),
                FormUtilsClient.getProvider(),
                mc.method_72703(),
                mc.method_22940().method_23003(),
                mc.method_22940().method_23001(),
                mc.field_1772
            );
        }

        return dispatcher;
    }

    public static class_11659 queue()
    {
        return get().method_73003();
    }

    /** The dispatcher itself — {@code ImmediateGui} builds its private GuiRenderer over it. */
    public static class_11684 dispatcher()
    {
        return get();
    }

    /**
     * Render everything submitted since the last flush through the BBS provider. The caller still
     * owns the provider's {@code draw()} (this only replays commands into it), matching how the
     * other form renderers batch-then-draw.
     */
    public static void flush()
    {
        get().method_73002();
    }

    /**
     * A camera render state for the active vanilla camera — fire billboards read its orientation.
     */
    public static class_12075 cameraState()
    {
        class_4184 camera = class_310.method_1551().field_1773.method_19418();
        class_12075 state = new class_12075();
        class_243 pos = camera.method_71156();

        state.field_63079 = true;
        state.field_63078 = pos;
        state.field_63080 = pos;
        state.field_63077 = camera.method_19328();
        state.field_63081 = new Quaternionf(camera.method_23767());

        return state;
    }
}
