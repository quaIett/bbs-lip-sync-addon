package mchorse.bbs_mod.forms.renderers;

import mchorse.bbs_mod.camera.Camera;
import mchorse.bbs_mod.forms.entities.IEntity;
import mchorse.bbs_mod.ui.framework.elements.utils.StencilMap;
import mchorse.bbs_mod.utils.MathUtils;
import mchorse.bbs_mod.utils.interps.Lerps;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_7833;

public class FormRenderingContext
{
    public FormRenderType type;
    public IEntity entity;
    public class_4587 stack;
    public class_4587 world;
    public int light;
    public int overlay;
    public float transition;
    public final Camera camera = new Camera();
    public StencilMap stencilMap;
    public boolean ui;
    public int color;
    public boolean modelRenderer;
    public long modelRendererTick;

    public FormRenderingContext()
    {}

    public FormRenderingContext set(FormRenderType type, IEntity entity, class_4587 stack, int light, int overlay, float transition)
    {
        this.type = type == null ? FormRenderType.ENTITY : type;
        this.entity = entity;
        this.stack = stack;

        /* Reused, not reallocated: set() runs per replay per frame, and nothing retains the
         * stack itself (readers snapshot matrices). The drain guards against a render that
         * left it unbalanced. */
        if (this.world == null)
        {
            this.world = new class_4587();
        }
        else
        {
            while (!this.world.method_67795())
            {
                this.world.method_22909();
            }

            this.world.method_34426();
        }
        this.light = light;
        this.overlay = overlay;
        this.transition = transition;
        this.stencilMap = null;
        this.ui = false;
        this.color = 0xffffffff;

        if (entity != null && (this.type == FormRenderType.ENTITY || this.type == FormRenderType.MODEL_BLOCK))
        {
            double x = Lerps.lerp(entity.getPrevX(), entity.getX(), transition);
            double y = Lerps.lerp(entity.getPrevY(), entity.getY(), transition);
            double z = Lerps.lerp(entity.getPrevZ(), entity.getZ(), transition);

            float bodyYaw = Lerps.lerp(entity.getPrevBodyYaw(), entity.getBodyYaw(), transition);

            this.world.method_22904(x, y, z);
            this.world.method_22907(class_7833.field_40716.rotationDegrees(-bodyYaw));
        }

        return this;
    }

    public FormRenderingContext camera(Camera camera)
    {
        this.camera.copy(camera);
        this.camera.updateView();

        return this;
    }

    public FormRenderingContext camera(net.minecraft.class_4184 camera)
    {
        this.camera.position.set(camera.method_71156().field_1352, camera.method_71156().field_1351, camera.method_71156().field_1350);
        this.camera.rotation.set(MathUtils.toRad(-camera.method_19329()), MathUtils.toRad(camera.method_19330()), 0F);
        this.camera.fov = MathUtils.toRad(class_310.method_1551().field_1690.method_41808().method_41753());
        this.camera.view.identity().rotate(camera.method_23767());

        return this;
    }

    public FormRenderingContext stencilMap(StencilMap stencilMap)
    {
        this.stencilMap = stencilMap;

        return this;
    }

    public FormRenderingContext inUI()
    {
        this.ui = true;

        return this;
    }

    public FormRenderingContext color(int color)
    {
        this.color = color;

        return this;
    }

    /**
     * Mark this as a {@link mchorse.bbs_mod.ui.framework.elements.utils.UIModelRenderer}
     * viewport and hand it that viewport's clock.
     *
     * <p>The tick is here because form ticking in an editor is opt-in
     * ({@link mchorse.bbs_mod.ui.forms.editors.utils.UIPickableFormRenderer#updatable()})
     * and off in the plain form editor. Anything that has to keep moving in a
     * preview regardless &mdash; particles, say &mdash; cannot wait to be
     * ticked and has to run off this instead.
     */
    public FormRenderingContext modelRenderer(long tick)
    {
        this.modelRenderer = true;
        this.modelRendererTick = tick;

        return this;
    }

    public float getTransition()
    {
        return this.transition;
    }

    public boolean isPicking()
    {
        return this.stencilMap != null;
    }

    public int getPickingIndex()
    {
        return this.stencilMap == null ? -1 : this.stencilMap.objectIndex;
    }
}
