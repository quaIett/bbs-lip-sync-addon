package mchorse.bbs_mod.forms.renderers;

import com.mojang.blaze3d.systems.RenderSystem;
import mchorse.bbs_mod.client.BBSRendering;
import mchorse.bbs_mod.client.render.picker.PickingReplay;
import mchorse.bbs_mod.forms.CustomVertexConsumerProvider;
import mchorse.bbs_mod.forms.FormRenderCapture;
import mchorse.bbs_mod.forms.FormTranslucentQueue;
import mchorse.bbs_mod.forms.FormUtilsClient;
import mchorse.bbs_mod.forms.QueueDispatch;
import mchorse.bbs_mod.forms.forms.BlockForm;
import mchorse.bbs_mod.forms.renderers.utils.FluidVertexConsumer;
import mchorse.bbs_mod.forms.renderers.utils.FormColorBlend;
import mchorse.bbs_mod.forms.renderers.utils.FormOverlay;
import mchorse.bbs_mod.forms.renderers.utils.SingleBlockRenderView;
import mchorse.bbs_mod.ui.framework.UIContext;
import mchorse.bbs_mod.utils.MatrixStackUtils;
import mchorse.bbs_mod.utils.colors.Color;
import mchorse.bbs_mod.utils.colors.OverlayBlend;
import mchorse.bbs_mod.utils.joml.Vectors;
import net.minecraft.class_11954;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3610;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_4696;
import net.minecraft.class_765;
import net.minecraft.class_811;
import net.minecraft.class_824;
import net.minecraft.class_827;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.List;
import java.util.Map;

public class BlockFormRenderer extends FormRenderer<BlockForm>
{
    public static final Color color = new Color();

    private final SingleBlockRenderView fluidView = new SingleBlockRenderView();

    private class_2586 blockEntity;
    private class_2680 blockEntityState;

    public BlockFormRenderer(BlockForm form)
    {
        super(form);
    }

    @Override
    public void renderInUI(UIContext context, int x1, int y1, int x2, int y2)
    {
        /* List/icon preview: submit a special GUI element so the block draws off-screen during the GUI prepare
         * phase (two-phase GUI drops a direct immediate draw here). BbsFormGuiElementRenderer calls back into
         * renderUIPreview inside the FBO render pass — same path as ModelForm. */
        this.submitUIPreview(context, x1, y1, x2, y2);
    }

    @Override
    public void renderUIPreview(class_4587 stack, float angle, float transition, int x1, int y1, int x2, int y2)
    {
        CustomVertexConsumerProvider consumers = FormUtilsClient.getProvider();

        /* The base renderer pre-translated the stack to the cell (centre, 0.85*height down) + scale(f,f,-f);
         * apply the rest of the original getUIMatrix framing here, then the original block post-ops + draw
         * (renderBlockAsEntity + consumers.draw, the same path render3D uses, confirmed working in-world). */
        Matrix4f uiMatrix = getUIPreviewMatrix(angle, y1, y2);

        stack.method_22903();
        MatrixStackUtils.multiply(stack, uiMatrix);
        stack.method_22905(this.form.uiScale.get(), this.form.uiScale.get(), this.form.uiScale.get());
        stack.method_46416(-0.5F, 0F, -0.5F);

        stack.method_23760().method_23762().getScale(Vectors.EMPTY_3F);
        stack.method_23760().method_23762().scale(1F / Vectors.EMPTY_3F.x, -1F / Vectors.EMPTY_3F.y, 1F / Vectors.EMPTY_3F.z);

        Color set = Color.white();
        FormColorBlend.blend(set, this.form.color.get());

        Color overlay = this.form.overlayColor.get();
        boolean overlayActive = OverlayBlend.isActive(overlay);

        if (overlayActive)
        {
            FormOverlay.swatch(overlay);
        }

        consumers.setSubstitute(BBSRendering.getColorConsumer(set));
        consumers.setUI(true);
        consumers.setLayerMapper(overlayActive ? FormOverlay::withOverlay : null);
        this.renderBlock(stack, consumers, class_765.field_32769, class_4608.field_21444, false);
        consumers.setLayerMapper(null);
        consumers.method_22993();
        consumers.setUI(false);
        consumers.setSubstitute(null);

        stack.method_22909();
    }

    @Override
    protected void render3D(FormRenderingContext context)
    {
        CustomVertexConsumerProvider consumers = FormUtilsClient.getProvider();
        int light = context.light;

        context.stack.method_22903();
        if (context.world != null)
        {
            context.world.method_22903();
        }
        context.stack.method_46416(-0.5F, 0F, -0.5F);
        if (context.world != null)
        {
            context.world.method_46416(-0.5F, 0F, -0.5F);
        }

        Color overlay = this.form.overlayColor.get();
        boolean overlayActive = !context.isPicking() && OverlayBlend.isActive(overlay);

        if (overlayActive)
        {
            FormOverlay.swatch(overlay);
        }

        if (context.isPicking())
        {
            /* Picking: capture the block's vanilla-layer geometry and replay it through the
             * picker_models pipeline into the stencil (see PickingReplay — the 1.21.1 global-shader
             * swap has no equivalent, the capture+replay does the same job). */
            this.setupTarget(context);

            FormRenderCapture.begin();

            Map<class_1921, List<FormRenderCapture.Captured>> captured;

            try
            {
                this.renderBlock(context.stack, consumers, 0, context.overlay, true);
                consumers.method_22993();
            }
            finally
            {
                captured = FormRenderCapture.end();
            }

            PickingReplay.draw(captured);

            context.stack.method_22909();

            if (context.world != null)
            {
                context.world.method_22909();
            }

            return;
        }

        color.set(context.color);
        FormColorBlend.blend(color, this.form.color.get());

        /* Publishing the form's camera-space origin opts its translucent layers into the
         * deferred sorted pass (see CustomVertexConsumerProvider#draw(RenderLayer)); the
         * picking branch above never publishes, so the stencil keeps every pixel. */
        if (!context.isPicking())
        {
            Vector3f origin = context.stack.method_23760().method_23761().getTranslation(new Vector3f());

            FormTranslucentQueue.setSortOrigin(new Matrix4f(RenderSystem.getModelViewMatrix()).transformPosition(origin));
        }

        consumers.setSubstitute(BBSRendering.getColorConsumer(color));
        consumers.setLayerMapper(overlayActive ? FormOverlay::withOverlay : null);
        this.renderBlock(context.stack, consumers, light, context.overlay, context.isPicking());
        consumers.setLayerMapper(null);
        consumers.method_22993();
        consumers.setSubstitute(null);
        FormTranslucentQueue.setSortOrigin(null);

        context.stack.method_22909();
        if (context.world != null)
        {
            context.world.method_22909();
        }

        /* TODO(1.21.11 render): RenderSystem.enableDepthTest() was removed in 1.21.5; depth testing is
         * now encoded per RenderLayer via DepthTestFunction on its pipeline. No restore needed here. */
    }

    /**
     * Draw the block state the way the world would draw it.
     *
     * <p>Vanilla's renderBlockAsEntity() draws a baked block model and nothing else, so
     * everything the world puts on top of that model, or instead of it, was silently missing
     * here: water and lava, whose geometry the fluid renderer generates per chunk section;
     * signs, banners, skulls and the end portal, which render as
     * {@link class_2464#field_11455} and are drawn entirely by a block entity renderer;
     * the bell's body, the campfire's food, the lectern's book, which a block entity renderer
     * adds on top of the model; and marker blocks like the barrier, which only ever exist as
     * an item icon. Each of those gets its own path below.</p>
     */
    private void renderBlock(class_4587 matrices, CustomVertexConsumerProvider consumers, int light, int overlay, boolean picking)
    {
        class_310 mc = class_310.method_1551();
        class_2680 state = this.form.blockState.get();
        class_2464 type = state.method_26217();
        class_3610 fluidState = state.method_26227();

        /* Not only water and lava: this is also where a waterlogged block gets its water,
         * on top of its own model below. */
        if (!fluidState.method_15769())
        {
            class_1921 layer = class_4696.method_23683(fluidState.method_15759());
            FluidVertexConsumer consumer = new FluidVertexConsumer(consumers.method_73477(layer), matrices.method_23760(), overlay);

            mc.method_1541().method_3352(class_2338.field_10980, this.fluidView.set(state, light), consumer, state, fluidState);
        }

        if (type != class_2464.field_11455)
        {
            mc.method_1541().method_3353(state, matrices, consumers, light, overlay);
        }

        if (picking)
        {
            /* Picking stays out of the paths below on purpose: they draw through layers of
             * their own, and a sign's text or an end portal's sides are not even in the
             * entity vertex format the picking shader is compiled for. Such a form gets
             * selected from the outliner instead. */
            return;
        }

        /* 1.21.4+ dropped BlockRenderType.ENTITYBLOCK_ANIMATED: a chest, a bed or a shulker box
         * has a plain model like anything else, and everything animated about it comes from its
         * block entity renderer - so there is no longer a family to exclude here. */
        if (this.renderBlockEntity(mc, state, matrices, consumers, light, overlay))
        {
            return;
        }

        if (type == class_2464.field_11455 && fluidState.method_15769())
        {
            /* Barrier, light block, structure void: invisible in the world, but they do have
             * an icon, and a form of one should show something. The item model is centered on
             * the origin, while a block model spans 0..1, hence the half block nudge. */
            class_1799 stack = new class_1799(state.method_26204());

            if (!stack.method_7960())
            {
                matrices.method_22903();
                matrices.method_46416(0.5F, 0.5F, 0.5F);
                ItemFormRenderer.renderItem(stack, class_811.field_4315, matrices, consumers, mc.field_1687, light, overlay);
                matrices.method_22909();
            }
        }
    }

    /**
     * Run the block state's block entity renderer, keeping the block entity itself around
     * between frames: it is an argument the renderer needs, not state of the form.
     *
     * @return whether there was a renderer to run
     */
    private boolean renderBlockEntity(class_310 mc, class_2680 state, class_4587 matrices, CustomVertexConsumerProvider consumers, int light, int overlay)
    {
        if (mc.field_1687 == null || !(state.method_26204() instanceof class_2343 provider))
        {
            return false;
        }

        if (this.blockEntity == null || this.blockEntityState != state)
        {
            this.blockEntity = provider.method_10123(class_2338.field_10980, state);
            this.blockEntityState = state;
        }

        if (this.blockEntity == null)
        {
            return false;
        }

        if (this.blockEntity.method_10997() != mc.field_1687)
        {
            /* Renderers of blocks that tick or move (the bell, the beacon) read the world off
             * the block entity, and the client's is the only one a form can offer. */
            this.blockEntity.method_31662(mc.field_1687);
        }

        class_824 manager = mc.method_31975();
        class_827 renderer = manager.method_3550(this.blockEntity);

        if (renderer == null)
        {
            return false;
        }

        /* Not manager.getRenderState(): it refuses anything further than the renderer's render
         * distance from the camera, and a form's block entity always sits at the world origin -
         * a chest form would have stopped opening 64 blocks away from spawn. The state is built
         * by hand instead, and the form's own light replaces the light at that origin. */
        class_11954 renderState = renderer.method_74335();

        renderer.method_74331(this.blockEntity, renderState, class_310.method_1551().method_61966().method_60637(false), mc.field_1773.method_19418().method_71156(), null);

        renderState.field_62676 = light;

        /* Block entity renderers only submit commands since 1.21.2, so they go through the BBS
         * queue and are flushed right here - the same path the mob form's entity takes. */
        manager.method_3555(renderState, matrices, QueueDispatch.queue(), QueueDispatch.cameraState());
        QueueDispatch.flush();
        consumers.method_22993();

        return true;
    }
}
