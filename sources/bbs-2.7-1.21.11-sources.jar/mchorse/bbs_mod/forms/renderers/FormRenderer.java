package mchorse.bbs_mod.forms.renderers;

import com.mojang.blaze3d.systems.RenderSystem;
import mchorse.bbs_mod.api.client.events.FormPoseEvents;
import mchorse.bbs_mod.api.client.render.RenderAttachment;
import java.util.IdentityHashMap;
import java.util.Map;

import mchorse.bbs_mod.client.BBSRendering;
import mchorse.bbs_mod.client.render.picker.BBSPickerRenderer;
import mchorse.bbs_mod.client.render.special.BbsFormGuiElementRenderState;
import mchorse.bbs_mod.cubic.IBoneHierarchy;
import mchorse.bbs_mod.forms.FormUtilsClient;
import mchorse.bbs_mod.forms.entities.IEntity;
import mchorse.bbs_mod.forms.forms.BodyPart;
import mchorse.bbs_mod.forms.forms.Form;
import mchorse.bbs_mod.forms.renderers.utils.MatrixCache;
import mchorse.bbs_mod.BBSSettings;
import mchorse.bbs_mod.settings.values.core.ValueTransform;
import mchorse.bbs_mod.ui.framework.UIContext;
import mchorse.bbs_mod.ui.framework.elements.utils.FontRenderer;
import mchorse.bbs_mod.ui.utils.keys.KeyCodes;
import mchorse.bbs_mod.utils.MathUtils;
import mchorse.bbs_mod.utils.MatrixStackUtils;
import mchorse.bbs_mod.utils.StringUtils;
import mchorse.bbs_mod.utils.colors.Colors;
import mchorse.bbs_mod.utils.interps.Lerps;
import mchorse.bbs_mod.utils.profiler.BBSProfiler;
import net.minecraft.class_1268;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_765;
import net.minecraft.class_8030;
import mchorse.bbs_mod.utils.pose.Transform;
import org.joml.Matrix3x2f;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.Collections;
import java.util.List;

public abstract class FormRenderer <T extends Form>
{
    protected T form;
    private Map<RenderAttachment<?>, Object> attachments;

    @SuppressWarnings("unchecked")
    public <V> V getAttachment(RenderAttachment<V> key)
    {
        return this.attachments == null ? null : (V) this.attachments.get(key);
    }

    public <V> void setAttachment(RenderAttachment<V> key, V value)
    {
        if (value == null)
        {
            if (this.attachments != null) this.attachments.remove(key);
        }
        else
        {
            if (this.attachments == null) this.attachments = new IdentityHashMap<>();
            this.attachments.put(key, value);
        }
    }

    public FormRenderer(T form)
    {
        this.form = form;
    }

    public T getForm()
    {
        return this.form;
    }

    public List<String> getBones()
    {
        return Collections.emptyList();
    }

    /**
     * The shape of this form's skeleton, or null when it has none. The one question the bone
     * widgets ask a form - the tree list, the pose editor's bone column, the bone picker menus -
     * so they no longer have to know whether they are looking at a cubic model, a BOBJ armature or
     * a vanilla entity model.
     */
    public IBoneHierarchy getBoneHierarchy()
    {
        return null;
    }

    public final void renderUI(UIContext context, int x1, int y1, int x2, int y2)
    {
        this.renderLive(context, x1, y1, x2, y2);

        FontRenderer font = context.batcher.getFont();
        String name = this.form.name.get();

        if (!name.isEmpty())
        {
            name = font.limitToWidth(name, x2 - x1 - 3);

            int w = font.getWidth(name);

            context.batcher.textCard(name, (x2 + x1 - w) / 2, y1 + 6, Colors.WHITE, Colors.ACTIVE | Colors.A50);
        }

        int keybind = this.form.hotkey.get();

        if (keybind > 0)
        {
            name = KeyCodes.getName(keybind);
            name = font.limitToWidth(name, x2 - x1 - 3);

            int w = font.getWidth(name);

            context.batcher.textCard(name, (x2 + x1 - w) / 2, y2 - 6 - font.getHeight(), Colors.WHITE, Colors.A50);
        }
    }

    /**
     * The form alone, without the name and hotkey cards {@link #renderUI} lays over it — for a
     * host that draws its own captions around the picture.
     */
    public final void renderPreview(UIContext context, int x1, int y1, int x2, int y2)
    {
        this.renderLive(context, x1, y1, x2, y2);
    }

    /** The picture of the form itself, without the cards {@link #renderUI} lays over it. */
    public final void renderLive(UIContext context, int x1, int y1, int x2, int y2)
    {
        /* The diffuse-light directions the old setupLevelDiffuseLighting bound here (lightA=(0,1,-0.2),
         * lightB=(-0.85,0.85,1)) are now bound per model-form thumbnail in BbsFormGuiElementRenderer.lights():
         * the UI form preview renders off-screen during the GUI prepare phase (two-phase GUI), so the lights
         * must be set there at draw time, not here in the record phase. Other form types render flat 2D and
         * need no diffuse lighting. */

        this.renderInUI(context, x1, y1, x2, y2);
    }

    protected abstract void renderInUI(UIContext context, int x1, int y1, int x2, int y2);

    /**
     * Submit this form as a vanilla special GUI element so it renders off-screen during the GUI prepare phase
     * and the deferred GUI composites it into the list/icon cell. The list draws each cell in the GUI record
     * phase, where a direct immediate 3D draw can't composite (two-phase GUI, 1.21.6+), so 3D form types route
     * their {@code renderInUI} through here — the same mechanism vanilla uses for entity/item thumbnails.
     * {@link BbsFormGuiElementRenderer} then calls back into {@link #renderUIPreview} inside the FBO render pass.
     * Form-type-agnostic: every renderer passes {@code this}; the cursor-driven yaw, the live 2D GUI matrix
     * (carries the list's scroll translate) and the active scissor are captured here, exactly like the original
     * which rendered onto {@code context.batcher.getContext().getMatrices()} bracketed by the GL scissor.
     */
    protected final void submitUIPreview(UIContext context, int x1, int y1, int x2, int y2)
    {
        context.batcher.flush();

        float angle = MathUtils.toRad(context.mouseX - (x1 + x2) / 2) + MathUtils.PI;

        if (BBSSettings.freezeModels.get())
        {
            angle = -MathUtils.PI + MathUtils.PI / 8;
        }

        class_332 dc = context.batcher.getContext();
        Matrix3x2f pose = new Matrix3x2f(dc.method_51448());

        /* The live GUI scissor (set by the caller's batcher.clip — UIReplayList clips the preview to the
         * row's square) rides along as the composite quad's scissorArea; without it the model renders
         * full-size and overflows the cell instead of being cropped. It is correct under scroll because
         * Batcher2D.clip neutralises the GUI matrix pose around DrawContext.enableScissor (which on
         * 1.21.11 transforms the rect by that pose, double-shifting it by the scroll), so the stored
         * scissor is shifted by the scroll exactly once — in lock-step with the geometry placed by pose. */
        class_8030 scissor = dc.field_44659.method_70863();

        dc.field_59826.method_70922(new BbsFormGuiElementRenderState(
            this, angle, context.getTransition(), pose, x1, y1, x2, y2, 1.0F, scissor));
    }

    /**
     * Render this form into the special-element off-screen FBO bound by {@link BbsFormGuiElementRenderer} for a
     * form-list thumbnail. The base renderer has set an ORTHOGRAPHIC projection and pre-translated {@code stack}
     * to the cell (origin at the horizontal centre, {@code 0.85*height} down) then {@code scale(f, f, -f)}; an
     * override applies the rest of the {@link #getUIPreviewMatrix} framing and draws. Default is
     * a no-op: form types that still render their UI preview the old (2D/immediate) way don't submit a special
     * element, so this is never called for them. The caller manages {@code ModelPreviewRenderer.ACTIVE} +
     * diffuse lighting + restore.
     */
    public void renderUIPreview(class_4587 stack, float angle, float transition, int x1, int y1, int x2, int y2)
    {}

    /**
     * The cell-relative framing for the special-element FBO preview path, shared by every 3D form type's
     * {@link #renderUIPreview}. The base {@code BbsFormGuiElementRenderer} already pre-translated the stack to the
     * cell (centre, {@code 0.85*height} down) and applied {@code scale(f, f, -f)}, so only the cell scale + 22.5°
     * forward tilt + cursor-driven yaw remain. The original {@code ModelFormRenderer.getUIMatrix} used
     * {@code scale(s, -s, s)}; the base's extra {@code -Z} means we flip Z here to net the same handedness.
     */
    public static Matrix4f getUIPreviewMatrix(float angle, int y1, int y2)
    {
        float cellScale = (y2 - y1) / 2.5F;

        Matrix4f uiMatrix = new Matrix4f();

        uiMatrix.scale(cellScale, -cellScale, -cellScale);
        uiMatrix.rotateX(MathUtils.PI / 8F);
        uiMatrix.rotateY(angle);

        return uiMatrix;
    }

    public boolean renderArm(class_4587 matrices, int light, class_742 player, class_1268 hand)
    {
        return false;
    }

    public final void render(FormRenderingContext context)
    {
        if (!this.form.shaderShadow.get() && BBSRendering.isIrisShadowPass())
        {
            return;
        }

        BBSProfiler.count(BBSProfiler.Section.FORM_RENDER);

        int light = context.light;
        IEntity entity = context.entity;
        class_4587 stack = context.stack;
        class_4587 world = context.world;
        class_4587.class_4665 stackEntry = stack.method_23760();
        class_4587.class_4665 worldEntry = world == null ? null : world.method_23760();
        boolean isPicking = context.isPicking();

        try
        {
            this.form.applyStates(context.transition);

            /* A form the author marked unpickable stays out of the picking pass only -
             * it still renders normally. States are unapplied by the finally below. */
            if (!this.form.visible.get() || (isPicking && !this.form.pickable.get()))
            {
                return;
            }

            stack.method_22903();
            if (world != null)
            {
                world.method_22903();
            }
            this.applyTransforms(stack, false, context.getTransition());
            if (world != null)
            {
                this.applyTransforms(world, false, context.getTransition());
            }

            float lf = 1F - MathUtils.clamp(this.form.lighting.get(), 0F, 1F);
            int u = context.light & '\uffff';
            int v = context.light >> 16 & '\uffff';

            u = (int) Lerps.lerp(u, class_765.field_32769, lf);
            context.light = u | v << 16;

            this.render3D(context);

            if (isPicking)
            {
                this.updateStencilMap(context);
            }

            this.renderBodyParts(context);
        }
        finally
        {
            /* FormUtilsClient catches render failures and continues the world frame. A
             * single pop is insufficient when render3D/body parts left nested pushes. */
            try
            {
                MatrixStackUtils.restore(stack, stackEntry);
            }
            finally
            {
                try
                {
                    if (world != null && world != stack)
                    {
                        MatrixStackUtils.restore(world, worldEntry);
                    }
                }
                finally
                {
                    context.light = light;
                    context.entity = entity;
                    this.form.unapplyStates();
                }
            }
        }
    }

    protected void applyTransforms(class_4587 stack, boolean origin, float transition)
    {
        Transform transform = this.createEvaluatedTransform(transition);

        if (origin)
        {
            stack.method_46416(transform.translate.x, transform.translate.y, transform.translate.z);
        }
        else
        {
            MatrixStackUtils.applyTransform(stack, transform);
        }
    }

    protected void applyTransforms(Matrix4f matrix, float transition)
    {
        matrix.mul(this.createEvaluatedTransform(transition).createMatrix());
    }

    /**
     * The form's own transform as it is actually rendered: its transform, its overlay and
     * whatever else was hung on it. Public because the film's orbit camera attaches to this
     * frame - what the camera follows has to be what the eye sees, not just where the replay
     * stands.
     */
    /** Saved animation plus overlays and external pose contributions. */
    public Transform createEvaluatedTransform(float transition)
    {
        Transform transform = this.createTransform();
        FormPoseEvents.TRANSFORM.invoker().apply(this.form, transform, transition);
        return transform;
    }

    public Transform createTransform()
    {
        this.form.syncOverlayTracks();
        Transform transform = new Transform();

        transform.copy(this.form.transform.get());
        this.applyTransform(transform, this.form.transformOverlay.get());

        for (ValueTransform t : this.form.additionalTransforms)
        {
            this.applyTransform(transform, t.get());
        }

        return transform;
    }

    private void applyTransform(Transform transform, Transform overlay)
    {
        transform.translate.add(overlay.translate);
        transform.scale.add(overlay.scale).sub(1, 1, 1);
        transform.addRotation(overlay);
    }

    /**
     * Form-local displacement of the form's origin from its rest pose this frame, used to drag the
     * entity's shadow under the form's perceived position. The base form simply reports its own
     * transform's translation (so transform keyframes shift the shadow); subclasses can override to
     * add their own motion (e.g. {@link ModelFormRenderer} folds in anchor-bone root motion). The
     * caller maps the result to world axes with the render target.
     */
    public Vector3f getShadowDisplacement(IEntity entity, float transition)
    {
        class_4587 stack = new class_4587();

        stack.method_22903();
        this.applyTransforms(stack, false, transition);

        Vector3f displacement = stack.method_23760().method_23761().getTranslation(new Vector3f());

        stack.method_22909();

        return displacement;
    }

    /**
     * Record the active picking index for the picker draw that follows.
     *
     * <p>The loose {@code uniform int Target} the picker shaders used is the BBSPicker std140 UBO now,
     * uploaded per picker draw by {@link BBSPickerRenderer} — so this is the faithful equivalent of the
     * 1.21.1 {@code program.getUniform("Target").set(getPickingIndex())}, minus the program: picker
     * programs are RenderPipelines, chosen at the draw itself.
     */
    protected void setupTarget(FormRenderingContext context)
    {
        BBSPickerRenderer.setTarget(context.getPickingIndex());
    }

    protected void updateStencilMap(FormRenderingContext context)
    {
        context.stencilMap.addPicking(this.form);
    }

    protected void render3D(FormRenderingContext context)
    {}

    public void renderBodyParts(FormRenderingContext context)
    {
        for (BodyPart part : this.form.parts.getAllTyped())
        {
            this.renderBodyPart(part, context);
        }
    }

    protected void renderBodyPart(BodyPart part, FormRenderingContext context)
    {
        IEntity oldEntity = context.entity;

        context.entity = part.getRenderEntity(oldEntity);

        if (part.getForm() != null)
        {
            context.stack.method_22903();
            if (context.world != null)
            {
                context.world.method_22903();
            }
            MatrixStackUtils.applyTransform(context.stack, part.transform.get());
            if (context.world != null)
            {
                MatrixStackUtils.applyTransform(context.world, part.transform.get());
            }

            FormUtilsClient.render(part.getForm(), context);

            context.stack.method_22909();
            if (context.world != null)
            {
                context.world.method_22909();
            }
        }

        context.entity = oldEntity;
    }

    public MatrixCache collectMatrices(IEntity entity, float transition)
    {
        BBSProfiler.count(BBSProfiler.Section.COLLECT_MATRICES);

        MatrixCache map = new MatrixCache();
        class_4587 stack = new class_4587();

        this.collectMatrices(entity, stack, map, "", transition);

        return map;
    }

    public void collectMatrices(IEntity entity, class_4587 stack, MatrixCache matrices, String prefix, float transition)
    {
        FormPoseEvents.PARENT_FRAME.invoker().capture(this.form, entity, stack.method_23760().method_23761(), prefix, transition);

        Matrix4f mm = new Matrix4f();
        Matrix4f oo = new Matrix4f();

        stack.method_22903();
        this.applyTransforms(stack, true, transition);
        oo.set(stack.method_23760().method_23761());
        stack.method_22909();

        stack.method_22903();
        this.applyTransforms(stack, false, transition);
        mm.set(stack.method_23760().method_23761());

        matrices.put(prefix, mm, oo);

        for (BodyPart part : this.form.parts.getAllTyped())
        {
            Form form = part.getForm();

            if (form != null)
            {
                stack.method_22903();
                MatrixStackUtils.applyTransform(stack, part.transform.get());

                FormUtilsClient.getRenderer(form).collectMatrices(entity, stack, matrices, StringUtils.combinePaths(prefix, part.getId()), transition);

                stack.method_22909();
            }
        }

        stack.method_22909();
    }
}
