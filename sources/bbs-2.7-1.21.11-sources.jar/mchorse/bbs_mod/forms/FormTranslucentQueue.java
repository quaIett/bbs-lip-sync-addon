package mchorse.bbs_mod.forms;

import mchorse.bbs_mod.BBSSettings;
import mchorse.bbs_mod.client.BBSRendering;
import mchorse.bbs_mod.client.BBSShaders;
import mchorse.bbs_mod.client.BBSShaders.ModelVariant;
import mchorse.bbs_mod.forms.renderers.utils.FormOverlay;
import mchorse.bbs_mod.graphics.texture.Texture;
import mchorse.bbs_mod.utils.colors.Color;
import net.minecraft.class_1921;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_9801;
import mchorse.bbs_mod.ui.framework.elements.utils.StencilMap;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;

/**
 * Deferred translucency for forms.
 *
 * <p>Form renderers draw immediately, in entity iteration order, with depth writes on — so a
 * semi-transparent pixel drawn early would occlude anything drawn later behind it. Instead, draws
 * whose texture (or colour) has semi-transparency run twice: an immediate opaque pass (the shader
 * keeps only opaque texels, which write depth), and a command enqueued here. At the end of the
 * frame — after every form has drawn — {@link #flush()} replays the commands sorted far-to-near, so
 * translucent pixels blend over everything without ever hiding it. It is the sort, not the depth
 * mask, that keeps forms behind them visible: solid geometry keeps writing depth in the replay, so a
 * model's own semi-transparent texels still occlude the ones behind them. Only flat forms
 * (billboards, framebuffer screens, label parts) drop the depth write — they have no self-occlusion
 * to preserve.
 *
 * <p>Commands replay finished draw calls with the geometry captured at enqueue time — they never
 * re-run animation, IK or physics.
 *
 * <h2>What the 1.21.11 port changed</h2>
 * The mechanism is the 1.21.1 one; the three things it used to lean on are gone:
 * <ul>
 *   <li>{@code PassMode} was a mutable {@code GlUniform}. It is a compile-time shader define now, so
 *       each pass is a separate {@link ModelVariant} of the model pipeline.</li>
 *   <li>Depth-write and cull were global GL toggles flipped per command inside the flush loop. They
 *       are immutable pipeline state now, so they moved into the variant too and a command carries
 *       nothing but its layer — the flush loop touches no GL state at all.</li>
 *   <li>Retention was a {@code VertexBuffer} uploaded per command. The geometry is kept as a CPU
 *       copy ({@link FormRenderCapture.Captured}, the same one the item path already uses) and
 *       re-emitted into the layer's buffer at flush.</li>
 * </ul>
 */
public class FormTranslucentQueue
{
    public static final int PASS_SINGLE = 0;
    public static final int PASS_OPAQUE = 1;
    public static final int PASS_TRANSLUCENT = 2;

    /* The alpha == 1 split's partition, made on the TEXTURE's alpha instead of the final one — the
     * whole-defer pair for a uniformly faded model (see submit). At form alpha == 1 both partitions
     * are identical, which is what makes the 100% boundary seamless. */
    public static final int PASS_TEX_OPAQUE = 3;
    public static final int PASS_TEX_TRANSLUCENT = 4;

    private static final List<DrawCommand> commands = new ArrayList<>();
    private static boolean active;

    /**
     * Camera-space origin of the form currently being drawn through the buffered vertex consumer path
     * (blocks, items) — its translucent layers can't know their position from the camera-space
     * vertices alone. Non-null also acts as the opt-in for deferring those layers; picking and UI
     * paths never set it.
     */
    private static Vector3f sortOrigin;

    /** Non-null while a group is being recorded: added commands collect here instead of the queue. */
    private static GroupCommand group;

    public static void setSortOrigin(Vector3f origin)
    {
        sortOrigin = origin;
    }

    public static Vector3f getSortOrigin()
    {
        return sortOrigin;
    }

    public static boolean isGroupOpen()
    {
        return group != null;
    }

    /**
     * Start recording a group: until {@link #endGroup()}, added commands collect into one composite
     * command that replays them in insertion order at flush. For forms whose parts depend on each
     * other's depth (a label's text against its background) — the group sorts against other forms as
     * a whole, while its internals keep their original draw order.
     */
    public static void beginGroup(Vector3f cameraSpaceOrigin, boolean cull)
    {
        group = new GroupCommand(cameraSpaceOrigin);
        sortOrigin = new Vector3f(cameraSpaceOrigin);
    }

    public static void endGroup()
    {
        GroupCommand finished = group;

        group = null;
        sortOrigin = null;

        if (finished != null && !finished.children.isEmpty())
        {
            add(finished);
        }
    }

    public static boolean isActive()
    {
        /* The Iris shadow pass re-renders the scene into the shadow map mid-frame: forms there must
         * draw immediately (the shadow map needs their full geometry), and nothing may enqueue — the
         * queue belongs to the main pass. */
        return active && !BBSRendering.isIrisShadowPass();
    }

    /**
     * Whether a draw splits into an immediate opaque pass (writes depth) + a deferred translucent
     * pass. Only when translucency is <em>intrinsic to the texture</em> and the colour is not faded:
     * the solid texels draw now and write depth, the see-through ones defer. A uniform colour fade
     * (alpha &lt; 1) instead takes {@link #needsWholeDefer}, because it drops every texel below the
     * opaque threshold — the split's immediate pass would draw nothing at all, leaving a pointless
     * empty draw call. False outside an active queue scope (UI previews, first-person arm) and during
     * picking (the stencil needs every pixel).
     *
     * <p>Also false when the draws carry a shaderpack's programs ({@link BBSRendering#isIrisWorldForms()}):
     * the split rides the PASS_MODE shader define, which the pack's program knows nothing about — both
     * passes would draw the full texture and every translucent texel would blend twice. Under a pack
     * the draw goes out single-pass and the pack's own pipeline handles its transparency.
     */
    public static boolean needsSplit(StencilMap stencilMap, Texture texture, float alpha)
    {
        return alpha >= 1F && texture != null && texture.hasTranslucency()
            && isActive() && stencilMap == null && !BBSRendering.isIrisWorldForms();
    }

    /**
     * Whether the whole draw defers as one unit with depth writes kept on, sorted between models: a
     * uniform colour fade. The faded model keeps writing depth so it still self-occludes instead of
     * collapsing into an unordered translucent blob, and the transition out of alpha == 1 stays
     * continuous (no pop).
     *
     * <p>Never under a shaderpack — same rule (and reason) as {@link #needsSplit}, and the 1.21.1
     * original was gated the same way ("Never true under Iris"): the pack owns transparency, so the
     * draw goes out immediately with the pack's program. The port lost this gate, which made the
     * draw PATH switch at the alpha == 1 boundary under a pack — an immediate draw at 100% against a
     * deferred end-of-frame replay at 99.9%, a visible one-time shading jump for a change that
     * should be invisible.
     */
    public static boolean needsWholeDefer(StencilMap stencilMap, float alpha)
    {
        return alpha < 1F && isActive() && stencilMap == null && !BBSRendering.isIrisWorldForms();
    }

    /**
     * The entry point for every BBS-drawn mesh that goes through the model pipeline: decide between a
     * plain immediate draw, the opaque/translucent split, and a whole deferred draw, then issue it.
     *
     * <p>{@code variant} is the caller's own choice of depth-write and cull (see {@link ModelVariant});
     * this method only ever overrides the pass. The layer is resolved from the currently bound BBS
     * texture, exactly as the immediate path does.
     *
     * @param origin camera-space origin used as the far-to-near sort key
     */
    public static void submit(class_9801 built, ModelVariant variant, Texture texture, float alpha, StencilMap stencilMap, Vector3f origin)
    {
        submit(built, variant, texture, alpha, stencilMap, origin, false);
    }

    /**
     * {@link #submit(class_9801, ModelVariant, Texture, float, StencilMap, Vector3f)} with the
     * colour overlay on: the layers resolve to their overlay twins, and a deferred command takes a
     * copy of the swatch — by flush time it holds whatever was drawn last.
     */
    public static void submit(class_9801 built, ModelVariant variant, Texture texture, float alpha, StencilMap stencilMap, Vector3f origin, boolean tinted)
    {
        if (built == null)
        {
            return;
        }

        int[] overlay = tinted ? FormOverlay.snapshot() : null;

        if (needsSplit(stencilMap, texture, alpha))
        {
            /* Opaque texels now (they write depth and occlude properly), see-through ones at flush.
             * The layer must be resolved HERE, while this form's texture is still the bound one — at
             * flush time the binding belongs to whoever drew last. */
            FormRenderCapture.Captured captured = FormRenderCapture.copy(built);
            class_1921 deferred = layer(variant.withPass(PASS_TRANSLUCENT), tinted);

            /* The opaque half always writes depth, even for a flat form whose deferred half does not:
             * writing depth is the entire point of drawing it now — it is what lets the solid part of
             * the texture occlude properly instead of waiting for the sort. On 1.21.1 this fell out of
             * the global depth mask being on during the immediate draw; the flag only ever applied to
             * the replay. */
            class_1921 opaque = layer(variant.withPass(PASS_OPAQUE).withDepthWrite(true), tinted);

            opaque.method_60895(built);
            add(new BufferCommand(deferred, captured, origin).overlay(overlay));
        }
        else if (needsWholeDefer(stencilMap, alpha))
        {
            /* A uniformly faded model must still layer internally the way the alpha == 1 split does:
             * texture-opaque texels first (writing depth, so they are the blend base for the shading
             * texels painted over them — a skin's second layer), texture-translucent ones after. One
             * final-alpha pass in buffer order let an overlay's shading texels blend with whatever
             * stood BEHIND the model and then depth-kill the body they were painted over — the
             * model's shading visibly jumped (toward the backdrop's tone) the moment alpha left
             * 100%. The pair partitions on the TEXTURE alpha, which at alpha == 1 is exactly the
             * split's partition — crossing the boundary changes only when the halves draw, not what
             * they blend with. Both replay the same captured bytes; equal origins keep them adjacent
             * and ordered through the stable sort (and in insertion order inside a group). */
            FormRenderCapture.Captured captured = FormRenderCapture.copy(built);

            if (texture != null && !texture.hasTranslucency())
            {
                /* No shading texels to layer — the single blended pass is already exact,
                 * and the translucent half of the pair would rasterise nothing. */
                add(new BufferCommand(layer(variant, tinted), captured, origin).overlay(overlay));
            }
            else
            {
                add(new BufferCommand(layer(variant.withPass(PASS_TEX_OPAQUE), tinted), captured, origin).overlay(overlay));
                add(new BufferCommand(layer(variant.withPass(PASS_TEX_TRANSLUCENT), tinted), captured, new Vector3f(origin)).overlay(overlay));
            }

            built.close();
        }
        else
        {
            class_1921 layer = layer(variant, tinted);

            layer.method_60895(built);
        }
    }

    /**
     * The layer for this pass, drawing through the colour overlay when the form has one — its twin
     * with BBS's swatch as the overlay texture (see {@code FormOverlay}).
     */
    private static class_1921 layer(ModelVariant variant, boolean tinted)
    {
        class_1921 layer = BBSShaders.getBoundModelLayer(variant);

        return tinted ? FormOverlay.withOverlay(layer) : layer;
    }

    public static void add(DrawCommand command)
    {
        if (group != null && command != group)
        {
            group.children.add(command);
        }
        else if (active)
        {
            commands.add(command);
        }
        else
        {
            /* No scope to defer into — draw right away so no pixels are lost. */
            command.draw();
        }
    }

    public static void begin()
    {
        release();

        /* Switched off, the queue never opens a scope: isActive() stays false, so no draw splits or
         * defers and add() falls through to drawing right away. That is the same single-pass path
         * forms already take under a shaderpack — every pixel is drawn, just in entity order with
         * depth writes, the way it was before this mechanism existed. */
        active = BBSSettings.translucencyQueue.get();
    }

    /**
     * Temporarily deactivate the queue: nested offscreen renders (framebuffer forms) run under their
     * own projection mid-frame and must not enqueue into the world's flush. Returns the previous
     * state for {@link #restore(boolean)}.
     */
    public static boolean suspend()
    {
        boolean wasActive = active;

        active = false;

        return wasActive;
    }

    public static void restore(boolean wasActive)
    {
        active = wasActive;
    }

    /**
     * Draw all deferred commands, far to near. Deactivates the queue — later draws (the first-person
     * hand) fall back to single-pass rendering.
     *
     * <p>Unlike 1.21.1 this loop sets no GL state: depth-write and cull ride each command's layer, and
     * the lightmap/overlay samplers are bound by the layer too.
     */
    public static void flush()
    {
        active = false;

        if (commands.isEmpty())
        {
            return;
        }

        /* TODO(1.21.11 render): 1.21.1 rebinds the main framebuffer here under Fabulous! graphics —
         * vanilla's pre-translucent bookkeeping (clear() and copyDepthFrom() on its transparency
         * framebuffers) leaves FBO 0, the window itself, bound at our flush point, and the
         * end-of-frame blit of the main framebuffer then overwrites everything drawn there.
         * Framebuffer.beginWrite(boolean) is gone, so the rebind has no expression on this branch
         * yet (the same debt as UIFilmController / UIModelBlockPanel). */

        commands.sort((a, b) -> Float.compare(b.distanceSq, a.distanceSq));

        for (DrawCommand command : commands)
        {
            try
            {
                command.draw();
            }
            catch (Exception e)
            {
                /* One malformed command must not take the rest of the frame's translucency with it. */
            }
        }

        commands.clear();
    }

    /** Drop any leftover commands (e.g. a frame whose flush point never ran). */
    private static void release()
    {
        commands.clear();

        /* A group left open by an aborted render must not leak into the next frame. */
        group = null;
        sortOrigin = null;
    }

    /* TODO(1.21.11 render): 1.21.1 sorts a FLAT single-quad command (billboard, framebuffer screen,
     * label part) by the camera's distance to the quad's PLANE rather than to its centre — a large
     * backdrop's centre swings nearer and further than nearby forms as the camera orbits, flipping
     * the paint order mid-flight. It carried a second DrawCommand constructor taking the quad's
     * camera-space plane normal (cross product of the transformed basis vectors) and a sort key of
     * (n·o)²/|n|². Not ported: submit()/BufferCommand here take an origin only, so a flat form on
     * this branch still sorts by its centre. */

    public static abstract class DrawCommand
    {
        public final float distanceSq;

        /** The origin must be camera-space (a captured model-view translation) — it's the sort key. */
        protected DrawCommand(Vector3f cameraSpaceOrigin)
        {
            this.distanceSq = cameraSpaceOrigin.lengthSquared();
        }

        /** The colour overlay swatch as it stood at enqueue time; null = the draw is not tinted. */
        private int[] overlay;

        public <T extends DrawCommand> T overlay(int[] overlay)
        {
            this.overlay = overlay;

            return (T) this;
        }

        /**
         * Put the captured swatch back before the replayed draw: the layer was resolved to its
         * overlay twin at enqueue time, but the swatch itself holds whatever the last draw of the
         * frame put there.
         */
        protected void applyOverlay()
        {
            if (this.overlay != null)
            {
                FormOverlay.restore(this.overlay);
            }
        }

        public abstract void draw();
    }

    /**
     * Replays captured geometry through a render layer. The layer carries the pass, the depth-write,
     * the cull and the texture, so the replay is a plain re-emit — the vertices were already fully
     * transformed when they were captured.
     */
    public static class BufferCommand extends DrawCommand
    {
        private final class_1921 layer;
        private final FormRenderCapture.Captured captured;

        public BufferCommand(class_1921 layer, FormRenderCapture.Captured captured, Vector3f cameraSpaceOrigin)
        {
            super(cameraSpaceOrigin);

            this.layer = layer;
            this.captured = captured;
        }

        @Override
        public void draw()
        {
            this.applyOverlay();

            class_287 builder = class_289.method_1348().method_60827(this.captured.params().comp_752(), this.captured.params().comp_749());

            /* Same mode in and out, so emit() copies the vertices straight through; it is shared with
             * the item path, which does need the rewrite. */
            FormRenderCapture.emit(this.captured, this.captured.params().comp_752(), builder);

            class_9801 built = builder.method_60794();

            if (built != null)
            {
                this.layer.method_60895(built);
            }
        }
    }

    /** Replays its children in insertion order; sorts against other commands as one unit. */
    public static class GroupCommand extends DrawCommand
    {
        private final List<DrawCommand> children = new ArrayList<>();

        public GroupCommand(Vector3f cameraSpaceOrigin)
        {
            super(cameraSpaceOrigin);
        }

        @Override
        public void draw()
        {
            for (DrawCommand child : this.children)
            {
                child.draw();
            }
        }
    }
}
