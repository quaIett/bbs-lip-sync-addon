package mchorse.bbs_mod.actions;

import com.google.common.collect.MapMaker;
import com.mojang.authlib.GameProfile;
import org.jetbrains.annotations.Nullable;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.OptionalInt;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_12096;
import net.minecraft.class_1263;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1496;
import net.minecraft.class_2165;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2625;
import net.minecraft.class_268;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3445;
import net.minecraft.class_3908;
import net.minecraft.class_8791;

public class SuperFakePlayer extends class_3222
{
    private static final GameProfile PROFILE = new GameProfile(UUID.fromString("12345678-9ABC-DEF1-2345-6789ABCDEF69"), "[BBS Player]");
    private static final Map<SuperFakePlayer.FakePlayerKey, SuperFakePlayer> FAKE_PLAYER_MAP = new MapMaker().weakValues().makeMap();

    public static SuperFakePlayer get(class_3218 world)
    {
        Objects.requireNonNull(world, "World may not be null.");

        return FAKE_PLAYER_MAP.computeIfAbsent(new SuperFakePlayer.FakePlayerKey(world, PROFILE), key -> new SuperFakePlayer(key.world, key.profile));
    }

    /** The world's actor if it already has one - nothing is born just to be asked. */
    @Nullable
    public static SuperFakePlayer getIfPresent(class_3218 world)
    {
        return world == null ? null : FAKE_PLAYER_MAP.get(new SuperFakePlayer.FakePlayerKey(world, PROFILE));
    }

    /**
     * Container lids the film is holding open, and the ones the actions of the
     * tick being applied have asked for (LUCKYWAY). A real player holds a lid
     * up by holding its screen open; an actor has no screen, so what it holds
     * is kept here and asserted anew every tick by {@link #flushLids()} - a lid
     * nobody asks for any more comes down, whether the film ran past the clip,
     * was scrubbed backwards or stopped altogether.
     */
    private final Set<class_2338> openLids = new HashSet<>();
    private final Set<class_2338> wantedLids = new HashSet<>();

    public void wantLidOpen(class_2338 pos)
    {
        if (ContainerLid.isLidded(this.method_51469(), pos))
        {
            this.wantedLids.add(pos.method_10062());
        }
    }

    /** Raises the lids this tick asked for and lowers the ones it didn't. */
    public void flushLids()
    {
        for (class_2338 pos : this.wantedLids)
        {
            if (this.openLids.add(pos))
            {
                ContainerLid.setOpen(this.method_51469(), pos, true);
            }
        }

        Iterator<class_2338> it = this.openLids.iterator();

        while (it.hasNext())
        {
            class_2338 pos = it.next();

            if (!this.wantedLids.contains(pos))
            {
                ContainerLid.setOpen(this.method_51469(), pos, false);

                it.remove();
            }
        }

        this.wantedLids.clear();
    }

    protected SuperFakePlayer(class_3218 world, GameProfile profile)
    {
        super(world.method_8503(), world, profile, class_8791.method_53821());

        this.field_13987 = new SuperFakePlayerNetworkHandler(this);
    }

    @Override
    public class_12096 method_75004()
    {
        return class_12096.field_63208;
    }

    @Override
    public class_2165 method_64401()
    {
        return new class_2165()
        {
            @Override
            public void method_43496(class_2561 message)
            {}

            @Override
            public boolean method_9200()
            {
                return false;
            }

            @Override
            public boolean method_9202()
            {
                return false;
            }

            @Override
            public boolean method_9201()
            {
                return false;
            }
        };
    }

    @Override
    public void method_5773()
    {}

    @Override
    public void method_14213(class_8791 settings)
    {}

    @Override
    public void method_7342(class_3445<?> stat, int amount)
    {}

    @Override
    public void method_7266(class_3445<?> stat)
    {}

    @Override
    public boolean method_5679(class_3218 world, class_1282 damageSource)
    {
        return true;
    }

    @Nullable
    @Override
    public class_268 method_5781()
    {
        return null;
    }

    @Override
    public void method_18403(class_2338 pos)
    {}

    @Override
    public boolean method_5873(class_1297 entity, boolean force, boolean shouldCancelInteract)
    {
        return false;
    }

    @Override
    public void method_7311(class_2625 sign, boolean front)
    {}

    /**
     * No window ever opens for an actor - the film draws its own, and a real
     * one would drag a screen handler and an inventory into the shot. What the
     * world loses along with it, the lid of a chest, is put back by
     * {@link ContainerLid} instead.
     */
    @Override
    public OptionalInt method_17355(@Nullable class_3908 factory)
    {
        return OptionalInt.empty();
    }

    @Override
    public void method_7291(class_1496 horse, class_1263 inventory)
    {}

    private record FakePlayerKey(class_3218 world, GameProfile profile)
    {}
}