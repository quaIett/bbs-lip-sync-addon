package mchorse.bbs_mod.actions;

import net.minecraft.class_1937;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2611;
import net.minecraft.class_2680;
import net.minecraft.class_2745;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/**
 * Raises and lowers a container's lid for a film (LUCKYWAY).
 *
 * <p>An actor can't open a real container: {@link SuperFakePlayer} turns every
 * screen down, because the film draws its own. Vanilla's lid, though, hangs off
 * the viewer count behind that screen, so turning the screen down also cost the
 * chest its animation and its sound.</p>
 *
 * <p>So the lid is driven straight instead: this sends the very block event
 * vanilla's viewer count would have sent (ChestBlockEntity#onViewerCountUpdate),
 * which is what every client turns into a moving lid. The container's real
 * viewer count is left alone, and that's the point - opening it for real also
 * schedules a recount five ticks later that counts the players standing within
 * five blocks of the chest, finds no actor there (an actor is never in the
 * world's entity list) and slams the lid shut mid-swing.</p>
 */
public class ContainerLid
{
    /** Vanilla's block event type for "this many players are looking inside". */
    private static final int VIEWER_COUNT = 1;

    /** Whether the block at this position has a lid worth animating at all. */
    public static boolean isLidded(class_1937 world, class_2338 pos)
    {
        class_2586 entity = world.method_8321(pos);

        return entity instanceof class_2595 || entity instanceof class_2611;
    }

    public static void setOpen(class_1937 world, class_2338 pos, boolean open)
    {
        class_2586 entity = world.method_8321(pos);

        if (entity instanceof class_2595)
        {
            class_2680 state = world.method_8320(pos);

            setChestHalfOpen(world, pos, state, open);

            /* Both halves of a double chest keep their own lid, and vanilla
             * moves both of them - a half open chest reads as a broken one */
            if (chestType(state) != class_2745.field_12569)
            {
                class_2338 other = pos.method_10093(class_2281.method_9758(state));
                class_2680 otherState = world.method_8320(other);

                if (otherState.method_27852(state.method_26204()))
                {
                    setChestHalfOpen(world, other, otherState, open);
                }
            }
        }
        else if (entity instanceof class_2611)
        {
            class_2680 state = world.method_8320(pos);

            world.method_8427(pos, state.method_26204(), VIEWER_COUNT, open ? 1 : 0);
            playSound(world, pos.method_10263() + 0.5D, pos.method_10264() + 0.5D, pos.method_10260() + 0.5D, open ? class_3417.field_14952 : class_3417.field_15206);
        }
    }

    private static void setChestHalfOpen(class_1937 world, class_2338 pos, class_2680 state, boolean open)
    {
        world.method_8427(pos, state.method_26204(), VIEWER_COUNT, open ? 1 : 0);

        playChestSound(world, pos, state, open ? class_3417.field_14982 : class_3417.field_14823);
    }

    /**
     * ChestBlockEntity#playSound, which isn't ours to call: the left half stays
     * quiet so a double chest is heard once, from the middle of the two.
     */
    private static void playChestSound(class_1937 world, class_2338 pos, class_2680 state, class_3414 sound)
    {
        class_2745 type = chestType(state);

        if (type == class_2745.field_12574)
        {
            return;
        }

        double x = pos.method_10263() + 0.5D;
        double y = pos.method_10264() + 0.5D;
        double z = pos.method_10260() + 0.5D;

        if (type == class_2745.field_12571)
        {
            class_2350 direction = class_2281.method_9758(state);

            x += direction.method_10148() * 0.5D;
            z += direction.method_10165() * 0.5D;
        }

        playSound(world, x, y, z, sound);
    }

    private static void playSound(class_1937 world, double x, double y, double z, class_3414 sound)
    {
        world.method_43128(null, x, y, z, sound, class_3419.field_15245, 0.5F, world.method_8409().method_43057() * 0.1F + 0.9F);
    }

    /** A chest block entity doesn't have to sit in a vanilla chest block. */
    private static class_2745 chestType(class_2680 state)
    {
        return state.method_28498(class_2281.field_10770) ? state.method_11654(class_2281.field_10770) : class_2745.field_12569;
    }
}
