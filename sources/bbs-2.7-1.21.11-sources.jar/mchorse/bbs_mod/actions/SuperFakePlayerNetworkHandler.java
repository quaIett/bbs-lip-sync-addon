package mchorse.bbs_mod.actions;

import io.netty.channel.ChannelFutureListener;
import net.minecraft.class_2535;
import net.minecraft.class_2547;
import net.minecraft.class_2596;
import net.minecraft.class_2598;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_8792;
import org.jetbrains.annotations.Nullable;

public class SuperFakePlayerNetworkHandler extends class_3244
{
    private static final class_2535 FAKE_CONNECTION = new FakeClientConnection();

    public SuperFakePlayerNetworkHandler(class_3222 player)
    {
        super(player.method_51469().method_8503(), FAKE_CONNECTION, player, class_8792.method_53824(player.method_7334(), false));
    }

    @Override
    public void method_52391(class_2596<?> packet, @Nullable ChannelFutureListener callbacks)
    {}

    private static final class FakeClientConnection extends class_2535
    {
        private FakeClientConnection()
        {
            super(class_2598.field_11942);
        }

        public void setPacketListener(class_2547 packetListener)
        {}
    }
}