package mchorse.bbs_mod.actions.types.item;

import mchorse.bbs_mod.actions.SuperFakePlayer;
import mchorse.bbs_mod.film.Film;
import mchorse.bbs_mod.film.replays.Replay;
import mchorse.bbs_mod.items.GunItem;
import mchorse.bbs_mod.utils.clips.Clip;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1799;

public class UseItemActionClip extends ItemActionClip
{
    @Override
    public void applyAction(class_1309 actor, SuperFakePlayer player, Film film, Replay replay, int tick)
    {
        class_1268 hand = this.hand.get() ? class_1268.field_5808 : class_1268.field_5810;

        GunItem.actor = actor;

        this.applyPositionRotation(player, replay, tick);
        player.method_6122(hand, this.itemStack.get().method_7972());
        this.itemStack.get().method_7913(player.method_51469(), player, hand);
        player.method_6122(hand, class_1799.field_8037);

        GunItem.actor = null;
    }

    @Override
    protected Clip create()
    {
        return new UseItemActionClip();
    }
}