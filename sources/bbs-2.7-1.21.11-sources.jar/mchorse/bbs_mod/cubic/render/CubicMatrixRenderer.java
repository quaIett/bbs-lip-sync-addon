package mchorse.bbs_mod.cubic.render;

import mchorse.bbs_mod.cubic.data.model.Model;
import mchorse.bbs_mod.cubic.data.model.ModelGroup;
import net.minecraft.class_287;
import net.minecraft.class_4587;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

public class CubicMatrixRenderer implements ICubicRenderer
{
    public List<Matrix4f> matrices;
    public List<Matrix4f> origins;

    public CubicMatrixRenderer(Model model)
    {
        this.matrices = new ArrayList<>();
        this.origins = new ArrayList<>();

        for (int i = 0; i < model.getAllGroupKeys().size(); i++)
        {
            this.matrices.add(new Matrix4f());
            this.origins.add(new Matrix4f());
        }
    }

    /**
     * The default sequence, split open only to snapshot the origin frame between
     * the translate and the pivot move. It must stay in lockstep with {@link
     * ICubicRenderer#applyGroupTransformations} — the offset leads there too, so
     * anything riding these matrices (gizmos, body parts, anchors, trackers,
     * shadows) follows a stretched bone instead of its un-stretched pose.
     */
    @Override
    public void applyGroupTransformations(class_4587 stack, ModelGroup group)
    {
        ICubicRenderer.offsetGroup(stack, group);
        ICubicRenderer.translateGroup(stack, group);

        this.origins.get(group.index).set(stack.method_23760().method_23761());

        ICubicRenderer.moveToGroupPivot(stack, group);
        ICubicRenderer.rotateGroup(stack, group);
        ICubicRenderer.scaleGroup(stack, group);
        ICubicRenderer.moveBackFromGroupPivot(stack, group);
    }

    @Override
    public boolean renderGroup(class_287 builder, class_4587 stack, ModelGroup group, Model model)
    {
        this.matrices.get(group.index).set(stack.method_23760().method_23761());

        return false;
    }
}