package mchorse.bbs_mod.cubic.render.vao;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;
import mchorse.bbs_mod.BBSModClient;
import mchorse.bbs_mod.client.BBSShaders;
import mchorse.bbs_mod.client.render.picker.BBSPickerRenderer;
import mchorse.bbs_mod.forms.FormTranslucentQueue;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_4587;
import net.minecraft.class_9801;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public class ModelVAORenderer
{
    /** Sampler uniform names — setupUniforms runs per draw call, no string building there. */
    private static final String[] SAMPLERS =
    {
        "Sampler0", "Sampler1", "Sampler2", "Sampler3", "Sampler4", "Sampler5",
        "Sampler6", "Sampler7", "Sampler8", "Sampler9", "Sampler10", "Sampler11"
    };

    /**
    /**
     * The full model-view a draw issued right now would use. Kept from 1.21.1 because callers still
     * capture the frame's model-view for their own maths (the deferred translucent queue it was
     * written for is disabled on 1.21.11).
     */
    public static Matrix4f captureModelView(class_4587 stack)
    {
        return new Matrix4f(RenderSystem.getModelViewMatrix()).mul(stack.method_23760().method_23761());
    }

    /**
     * Draw a static {@link ModelVAO} through the immediate model RenderLayer. The 1.21.5+ rewrite
     * removed ShaderProgram.bind()/unbind() and the imperative uniform/sampler/fog/light setup; the
     * built-in uniforms now live in the std140 UBOs (DynamicTransforms / Projection / Fog / Lighting)
     * that {@link BBSShaders#getModelLayer()} uploads per draw. The geometry is baked CPU-side into a
     * BufferBuilder (matching the cubic immediate path) and submitted through that layer.
     *
     * <p>{@code cull} carries the model's own culling flag ({@code ModelInstance.isCulling()}); on
     * 1.21.1 it toggled the global GL cull around the draw, now it picks the layer variant.
     */
    public static void render(ModelVAO modelVAO, class_4587 stack, float r, float g, float b, float a, int light, int overlay, boolean cull)
    {
        class_287 builder = class_289.method_1348().method_60827(VertexFormat.class_5596.field_27379, class_290.field_1580);

        modelVAO.writeImmediate(builder, stack, r, g, b, a, light, overlay);

        class_9801 built = builder.method_60794();

        if (built != null)
        {
            /* Solid geometry: depth write stays on, so a deferred translucent pass still
             * self-occludes (see FormTranslucentQueue). */
            FormTranslucentQueue.submit(built,
                new BBSShaders.ModelVariant(FormTranslucentQueue.PASS_SINGLE, true, cull),
                BBSModClient.getTextures().getLastBound(), a, null,
                captureModelView(stack).getTranslation(new Vector3f()));
        }
    }

    /**
     * Draw the mesh through a picker {@link RenderPipeline} instead of a RenderLayer. The picker shaders
     * need the custom BBSPicker UBO (the Target index), which the immediate RenderLayer path cannot carry,
     * so the draw is driven by {@link BBSPickerRenderer}. The caller records the Target and Sampler0 first.
     */
    public static void renderPicking(ModelVAO modelVAO, class_4587 stack, float r, float g, float b, float a, int light, int overlay, RenderPipeline picker)
    {
        class_287 builder = class_289.method_1348().method_60827(VertexFormat.class_5596.field_27379, class_290.field_1580);

        modelVAO.writeImmediate(builder, stack, r, g, b, a, light, overlay);

        class_9801 built = builder.method_60794();

        if (built != null)
        {
            /* Identity-free: the camera is already baked into the vertices by writeImmediate, so the pass
             * gets the global model-view, the same argument the cubic/BOBJ picking draws pass. */
            BBSPickerRenderer.draw(picker, built, RenderSystem.getModelViewMatrix());
        }
    }
}
