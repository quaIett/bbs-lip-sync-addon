package mchorse.bbs_mod.cubic.render.vanilla;

import mchorse.bbs_mod.cubic.model.ArmorType;
import mchorse.bbs_mod.forms.entities.IEntity;
import mchorse.bbs_mod.forms.renderers.utils.RecolorVertexConsumer;
import mchorse.bbs_mod.utils.colors.Color;
import net.minecraft.class_10186;
import net.minecraft.class_10192;
import net.minecraft.class_10201;
import net.minecraft.class_10394;
import net.minecraft.class_1058;
import net.minecraft.class_1059;
import net.minecraft.class_11677;
import net.minecraft.class_12249;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_4722;
import net.minecraft.class_5321;
import net.minecraft.class_572;
import net.minecraft.class_630;
import net.minecraft.class_8053;
import net.minecraft.class_9282;
import net.minecraft.class_9334;
import java.util.List;

/**
 * Vanilla armor rendering onto BBS cubic-model bones.
 *
 * <p>Ported to 1.21.11. The 1.21.4+ equipment rewrite removed the entire API this class was built
 * on:
 * <ul>
 *   <li>{@code net.minecraft.item.ArmorItem} no longer exists — armor identity is now carried by the
 *       {@link net.minecraft.class_9334#field_54196} data component (an
 *       {@link class_10192} whose {@link class_10192#comp_3176()} points at an
 *       {@link class_10394}).</li>
 *   <li>{@code ArmorMaterial} moved to {@code net.minecraft.item.equipment} and no longer exposes a
 *       per-item material/key the way it used to; {@code ArmorTrim} moved to
 *       {@code net.minecraft.item.equipment.trim} and replaced
 *       {@code getGenericModelId}/{@code getLeggingsModelId} with
 *       {@link class_8053#method_67225(String, class_5321)}.</li>
 *   <li>{@code RenderLayer.getArmorCutoutNoCull(Identifier)}, {@code RenderLayer.getArmorEntityGlint()}
 *       and every other {@code RenderLayer.getXxx(...)} entity-layer factory were removed —
 *       {@code RenderLayer} now only exposes {@code of(String, RenderSetup)}. Entity/equipment drawing
 *       moved to {@code EquipmentRenderer} + the {@code OrderedRenderCommandQueue} command system, a
 *       different architecture from this per-{@link ArmorType}, per-{@link class_630} renderer.</li>
 *   <li>{@code BakedModelManager.getAtlas(Identifier)} was removed — the armor-trims sprite atlas
 *       comes from {@code AtlasManager} instead.</li>
 * </ul>
 *
 * <p>Vanilla's own {@code EquipmentRenderer} cannot be reused: it renders a whole {@code Model<S>}
 * through the command queue, while this one puts individual {@link class_630}s onto individual cubic
 * bones. So the draw is BBS's, but everything it draws is read out of vanilla's data - which shapes
 * an equipment asset has, and which texture each of them uses, come from the
 * {@link class_10201} index rather than from a path built out of the asset id.
 */
public class ArmorRenderer
{
    /** Per-slot armor models (1.21.4+: the inner/outer pair became head/chest/legs/feet layers). */
    private final class_11677<class_572> models;
    private final class_630 elytra;
    private final class_630 elytraLeftWing;
    private final class_630 elytraRightWing;

    /**
     * Vanilla's own {@code assets/<ns>/equipment/<asset>.json} index. It is what says WHICH shapes a
     * piece of equipment has (a humanoid body, wings, a horse's barding) and which texture each of
     * them draws with - guessing that from the asset id is what put a missing texture on the arms.
     */
    private final class_10201 equipment;

    public ArmorRenderer(class_11677<class_572> models, class_630 elytra, class_10201 equipment)
    {
        this.models = models;
        this.elytra = elytra;
        this.elytraLeftWing = elytra.method_32086("left_wing");
        this.elytraRightWing = elytra.method_32086("right_wing");
        this.equipment = equipment;
    }

    public void renderArmorSlot(class_4587 matrices, class_4597 vertexConsumers, IEntity entity, class_1304 armorSlot, ArmorType type, int light)
    {
        class_1799 itemStack = entity.getEquipmentStack(armorSlot);

        if (itemStack.method_7960())
        {
            return;
        }

        /* 1.21.4+: armor is identified by the EQUIPPABLE component + its asset id, not by an
         * ArmorItem subclass. We still gate on the slot matching so this only fires for the armour
         * the model actually wears in that slot. */
        class_10192 equippable = itemStack.method_58694(class_9334.field_54196);

        if (equippable == null || equippable.comp_3174() != armorSlot || equippable.comp_3176().isEmpty())
        {
            return;
        }

        class_5321<class_10394> assetId = equippable.comp_3176().get();
        class_10186 model = this.equipment.method_64087(assetId);

        if (!model.method_63996(class_10186.class_10190.field_54127).isEmpty())
        {
            /* Wings hang off the torso alone. Both arms share EquipmentSlot.CHEST with it (see
             * ArmorType), so without this an elytra was drawn three times - and the two arm draws
             * went down the humanoid path below, which has no texture for it: that missing texture
             * is what turned the body black. */
            if (type == ArmorType.CHEST)
            {
                this.renderElytra(matrices, vertexConsumers, entity, itemStack, model, light);
            }

            return;
        }

        boolean innerModel = this.usesInnerModel(armorSlot);
        class_10186.class_10190 layerType = innerModel ? class_10186.class_10190.field_54126 : class_10186.class_10190.field_54125;
        List<class_10186.class_10189> layers = model.method_63996(layerType);

        if (layers.isEmpty())
        {
            /* Worn, but not shaped like a body: a carved pumpkin, a mob head, a horse's barding on
             * something that is not a horse. Vanilla draws nothing for those either. */
            return;
        }

        class_572 bipedModel = this.getModel(armorSlot);
        class_630 part = this.getPart(bipedModel, type);

        bipedModel.method_2805(true);

        part.field_3657 = part.field_3656 = part.field_3655 = 0F;
        part.field_3654 = part.field_3675 = part.field_3674 = 0F;
        part.field_37938 = part.field_37939 = part.field_37940 = 1F;

        /* One draw per declared layer, in order: leather is a grey mask plus an undyed overlay, and
         * the dye (or the material's own default tint) belongs to the first of the two. */
        for (class_10186.class_10189 layer : layers)
        {
            this.renderArmorLayer(part, matrices, vertexConsumers, light, layer.method_64007(layerType), this.tint(itemStack, layer));
        }

        class_8053 trim = itemStack.method_58694(class_9334.field_49607);

        if (trim != null)
        {
            this.renderTrim(part, assetId, matrices, vertexConsumers, light, trim, innerModel);
        }

        if (itemStack.method_7958())
        {
            this.renderGlint(part, matrices, vertexConsumers, light);
        }
    }

    /* Vanilla elytra, verified against 1.20.4 bytecode: ElytraFeatureRenderer.render
     * (translate 0,0,0.125; armor cutout layer; glint) + ElytraEntityModel.setAngles
     * (non-player branch: standing / sneaking / fall flying wing angles). 1.21.11 keeps the
     * same numbers, it only moved them onto the entity's own ElytraFlightController - which an
     * actor driven by keyframes never ticks, so they are computed here as before. */
    private void renderElytra(class_4587 matrices, class_4597 vertexConsumers, IEntity entity, class_1799 itemStack, class_10186 model, int light)
    {
        float pitch = 0.2617994F;
        float roll = -0.2617994F;
        float originY = 0F;
        float yaw = 0F;

        if (entity.isFallFlying())
        {
            float spread = 1F;
            class_243 velocity = entity.getVelocity();

            if (velocity.field_1351 < 0D)
            {
                spread = 1F - (float) Math.pow(-velocity.method_1029().field_1351, 1.5D);
            }

            pitch = spread * 0.34906584F + (1F - spread) * pitch;
            roll = spread * -1.5707964F + (1F - spread) * roll;
        }
        else if (entity.isSneaking())
        {
            pitch = 0.6981317F;
            roll = -0.7853982F;
            originY = 3F;
            yaw = 0.08726646F;
        }

        this.elytraLeftWing.field_3656 = originY;
        this.elytraLeftWing.field_3654 = pitch;
        this.elytraLeftWing.field_3675 = yaw;
        this.elytraLeftWing.field_3674 = roll;
        this.elytraRightWing.field_3656 = originY;
        this.elytraRightWing.field_3654 = pitch;
        this.elytraRightWing.field_3675 = -yaw;
        this.elytraRightWing.field_3674 = -roll;

        matrices.method_22903();
        matrices.method_46416(0F, 0F, 0.125F);

        /* The texture comes off the wings layer, not a hardcoded path. (Vanilla swaps in the wearer's
         * own cape when the layer asks for it - an actor has none, so the default stands.) */
        class_10186.class_10189 wings = model.method_63996(class_10186.class_10190.field_54127).get(0);
        class_4588 vertexConsumer = vertexConsumers.method_73477(class_12249.method_75966(wings.method_64007(class_10186.class_10190.field_54127)));

        this.elytra.method_22698(matrices, vertexConsumer, light, class_4608.field_21444);

        if (itemStack.method_7958())
        {
            this.renderGlint(this.elytra, matrices, vertexConsumers, light);
        }

        matrices.method_22909();
    }

    private class_630 getPart(class_572 bipedModel, ArmorType type)
    {
        switch (type)
        {
            case HELMET -> {
                return bipedModel.field_3398;
            }
            case CHEST, LEGGINGS -> {
                return bipedModel.field_3391;
            }
            case LEFT_ARM -> {
                return bipedModel.field_27433;
            }
            case RIGHT_ARM -> {
                return bipedModel.field_3401;
            }
            case LEFT_LEG, LEFT_BOOT -> {
                return bipedModel.field_3397;
            }
            case RIGHT_LEG, RIGHT_BOOT -> {
                return bipedModel.field_3392;
            }
        }

        return bipedModel.field_3398;
    }

    private void renderArmorLayer(class_630 part, class_4587 matrices, class_4597 vertexConsumers, int light, class_2960 texture, Color color)
    {
        /* The armor layer factories came back as static RenderLayers.armorCutoutNoCull (the 1.21.4
         * rewrite moved them off RenderLayer, it didn't remove them). Same draw as 1.21.1: the layer
         * carries the texture, the recolor consumer carries the dye. */
        class_4588 base = vertexConsumers.method_73477(class_12249.method_75966(texture));
        class_4588 vertexConsumer = new RecolorVertexConsumer(base, color);

        part.method_22698(matrices, vertexConsumer, light, class_4608.field_21444);
    }

    /**
     * The colour one layer draws with. Only a layer that declares itself dyeable takes one: the dye
     * on the stack when there is one, and the material's own default otherwise - a leather texture
     * is a grey mask since 1.21.4, so an undyed piece drawn white would have come out grey.
     */
    private Color tint(class_1799 itemStack, class_10186.class_10189 layer)
    {
        if (layer.comp_3172().isEmpty())
        {
            return Color.white();
        }

        class_9282 dyed = itemStack.method_58694(class_9334.field_49644);
        int rgb = dyed != null ? dyed.comp_2384() : layer.comp_3172().get().comp_3170().orElse(0xFFFFFF);

        return new Color((rgb >> 16 & 255) / 255F, (rgb >> 8 & 255) / 255F, (rgb & 255) / 255F, 1F);
    }

    private void renderTrim(class_630 part, class_5321<class_10394> assetId, class_4587 matrices, class_4597 vertexConsumers, int light, class_8053 trim, boolean leggings)
    {
        /* 1.21.4+: the trim texture id comes off the trim itself and the atlas lives in
         * AtlasManager (BakedModelManager.getAtlas is gone). */
        class_1059 atlas = class_310.method_1551().method_72703().method_73025(class_4722.field_42071);
        class_1058 sprite = atlas.method_4608(trim.method_67225(leggings ? "leggings" : "armor", assetId));
        class_4588 vertexConsumer = sprite.method_24108(vertexConsumers.method_73477(class_4722.method_48480(trim.comp_3180().comp_349().comp_1905())));

        part.method_22698(matrices, vertexConsumer, light, class_4608.field_21444);
    }

    private void renderGlint(class_630 part, class_4587 matrices, class_4597 vertexConsumers, int light)
    {
        part.method_22698(matrices, vertexConsumers.method_73477(class_12249.method_75989()), light, class_4608.field_21444);
    }

    private class_572 getModel(class_1304 slot)
    {
        return this.models.method_72959(slot);
    }

    private boolean usesInnerModel(class_1304 slot)
    {
        return slot == class_1304.field_6172;
    }
}
