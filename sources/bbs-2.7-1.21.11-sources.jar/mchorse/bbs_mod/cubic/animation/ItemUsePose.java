package mchorse.bbs_mod.cubic.animation;

import mchorse.bbs_mod.forms.entities.IEntity;
import mchorse.bbs_mod.forms.entities.MCEntity;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1764;
import net.minecraft.class_1799;
import net.minecraft.class_1839;

/**
 * The item use state of a body, as everything that poses or dresses it needs it:
 * which vanilla use branch is running in a hand, for how long, and on which stack.
 *
 * <p>A film's actor never ticks an item use - the use is an action clip, and
 * {@link mchorse.bbs_mod.film.replays.ReplayItemUse} reads the state off it. Only
 * the client knows which replay drives which body, so the film controllers publish
 * the states through a {@link Source} they install, and everyone else asks here.</p>
 */
public class ItemUsePose
{
    /**
     * Which vanilla animation branch runs, how long it has been running
     * (fractional ticks), the stack driving it, how long the whole use lasts and
     * the body holding it - null when a replay's hand has none behind it (the
     * actor can be a bare form), which the vanilla timings below allow for.
     */
    public record Use(class_1839 action, float elapsed, class_1799 stack, float window, class_1309 user)
    {}

    /** The living body behind an entity, if there is one - the timings below ask it. */
    public static class_1309 livingOf(IEntity entity)
    {
        return entity instanceof MCEntity mc && mc.getMcEntity() instanceof class_1309 living ? living : null;
    }

    /**
     * How long the item is used for, and how long a crossbow takes to pull.
     *
     * <p>Both run through the stack's enchantments, which read the holder's own
     * Random, so vanilla asks for the body holding it. A film's hand can have no
     * body behind it, and then the plain vanilla base answers - the very number
     * an unenchanted item gives.</p>
     */
    public static int maxUseTime(class_1799 stack, class_1309 user)
    {
        if (user != null)
        {
            return stack.method_7935(user);
        }

        /* Only CrossbowItem reads the holder (its pull time plus three); every
         * other item answers from the stack alone. */
        return stack.method_7909() instanceof class_1764 ? pullTime(stack, null) + 3 : stack.method_7935(null);
    }

    public static int pullTime(class_1799 stack, class_1309 user)
    {
        /* CrossbowItem.getPullTime: floor(charge time * 20), and 1.25s is the base. */
        return user == null ? 25 : class_1764.method_7775(stack, user);
    }

    public interface Source
    {
        public Use get(IEntity entity, boolean mainHand);
    }

    private static Source source;
    private static boolean suppressed;

    public static void setSource(Source source)
    {
        ItemUsePose.source = source;
    }

    /**
     * The first person arm is drawn from the very same bones, and vanilla poses
     * it flat (its renderArm zeroes the arm's pitch) - so the use poses must not
     * leak into it.
     */
    public static void setSuppressed(boolean suppressed)
    {
        ItemUsePose.suppressed = suppressed;
    }

    public static Use get(IEntity entity, boolean mainHand)
    {
        if (suppressed || entity == null)
        {
            return null;
        }

        Use use = source == null ? null : source.get(entity, mainHand);

        return use == null ? live(entity, mainHand) : use;
    }

    /**
     * Whatever the entity is doing right now, for everyone the film doesn't
     * drive: a player morphed into a form outside of a film, and the player
     * being recorded (the clips that would answer for them are only written
     * when the take ends).
     */
    private static Use live(IEntity entity, boolean mainHand)
    {
        class_1309 living = livingOf(entity);

        if (living == null || !living.method_6115())
        {
            return null;
        }

        if ((living.method_6058() == class_1268.field_5808) != mainHand)
        {
            return null;
        }

        class_1799 stack = living.method_6030();
        class_1839 action = stack.method_7976();

        return action == class_1839.field_8952 ? null : new Use(action, living.method_6048(), stack, maxUseTime(stack, living), living);
    }
}
