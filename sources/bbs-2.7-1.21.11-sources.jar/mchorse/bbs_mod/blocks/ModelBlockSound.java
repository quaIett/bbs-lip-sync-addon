package mchorse.bbs_mod.blocks;

import net.minecraft.class_2498;
import net.minecraft.class_3542;

/**
 * Sound material of a model block. Lives in the block STATE (not the block
 * entity) because {@link net.minecraft.class_4970#method_9573}
 * receives only a state — there is no position to reach the block entity from.
 */
public enum ModelBlockSound implements class_3542
{
    STONE("stone", class_2498.field_11544),
    WOOD("wood", class_2498.field_11547),
    METAL("metal", class_2498.field_11533),
    GLASS("glass", class_2498.field_11537),
    WOOL("wool", class_2498.field_11543),
    GRASS("grass", class_2498.field_11535),
    NONE("none", class_2498.field_44608);

    public final String id;
    public final class_2498 group;

    ModelBlockSound(String id, class_2498 group)
    {
        this.id = id;
        this.group = group;
    }

    public static ModelBlockSound byId(String id)
    {
        for (ModelBlockSound sound : values())
        {
            if (sound.id.equals(id))
            {
                return sound;
            }
        }

        return STONE;
    }

    @Override
    public String method_15434()
    {
        return this.id;
    }
}
