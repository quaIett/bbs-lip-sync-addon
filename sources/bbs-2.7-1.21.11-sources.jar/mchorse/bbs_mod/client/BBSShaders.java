package mchorse.bbs_mod.client;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.logging.LogUtils;
import mchorse.bbs_mod.BBSMod;
import mchorse.bbs_mod.forms.FormTranslucentQueue;
import net.minecraft.class_10149;
import net.minecraft.class_10789;
import net.minecraft.class_10799;
import net.minecraft.class_12247;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_2960;

/**
 * Custom shader/render foundation for BBS, migrated from the 1.21.1 ShaderProgram + JSON
 * shader-program system to the 1.21.5+ GPU pipeline.
 *
 * In 1.21.1 each effect was a {@code net.minecraft.client.gl.ShaderProgram} constructed from a
 * {@code <name>.json} program definition that referenced {@code <name>.vsh}/{@code <name>.fsh}.
 * In 1.21.5+ {@code ShaderProgram}, {@code RenderSystem.setShader(...)} and
 * {@code GameRenderer.getXxxProgram()} were removed; the JSON program format is gone. Rendering
 * now goes through a {@link RenderPipeline} (declaring vertex/fragment shader, vertex format,
 * blend, depth, cull, samplers, uniforms) wrapped in a {@link class_1921} via
 * {@link class_1921#method_75940(String, class_12247)} / {@link class_12247#method_75927(RenderPipeline)}.
 *
 * The GLSL assets (assets/bbs/shaders/core/*.vsh|*.fsh) are kept as-is and referenced through the
 * shader Identifier {@code bbs:core/<name>} (no file extension; the loader appends it).
 *
 * TODO(1.21.11 render): the kept GLSL is still in the old 1.21.1 header/import style
 * (#version 150, loose `uniform` declarations, #moj_import &lt;light.glsl&gt;/&lt;fog.glsl&gt;).
 * 1.21.5 moved built-in uniforms into std140 UBO blocks (Projection / Fog / Lighting / DynamicTransforms)
 * and changed the import set. Each kept .vsh/.fsh almost certainly needs its header rewritten to the
 * new layout-block style before it will link. That is an asset migration, tracked separately.
 *
 * TODO(1.21.11 render): the per-draw custom uniforms each effect used to set imperatively via
 * {@code program.getUniform("...")} (ColorModulator, Target, HighlightColor, Size, Filters, Blur,
 * TextureSize, IViewRotMat, the two Light directions, NormalMat) no longer exist as mutable
 * GlUniforms. They must be supplied as UBO entries / DynamicUniforms and uploaded per render pass.
 * The custom uniform set for each pipeline is documented below so the caller-migration phase can
 * wire them up. Verify at runtime.
 */
public class BBSShaders
{
    /* All BBS shaders used "add / srcalpha / 1-srcalpha" in their JSON, i.e. standard alpha blending. */
    private static final BlendFunction BLEND = BlendFunction.TRANSLUCENT;

    /**
     * A model pipeline is registered per (variant, world) pair. The world axis exists for shaderpacks:
     * the world copy of a pipeline is assigned to one of the pack's programs
     * ({@link BBSRendering#assignIrisPipeline}), which is the only way its draws land in the pack's
     * G-buffers and survive the end-of-frame composite. Assignment is per pipeline and permanent, so
     * the shared copy — which also draws the form editor's and film panel's previews into BBS's own
     * framebuffers — must never be the assigned one: a run proved the pack's program follows it there
     * and clips the preview against the world's depth. {@link BBSRendering#isIrisWorldForms()} is the
     * switch between the two.
     */
    private record PipelineKey(ModelVariant variant, boolean world)
    {}

    /**
     * Registered model pipelines by variant; each is a separate GLSL compile (different PASS_MODE define).
     *
     * <p>MUST stay above the pipeline fields below: static fields initialise in declaration order, and
     * those fields call {@link #modelPipeline} — which reads this map. Declared after them it is still
     * null at that point, and the whole class fails to initialise.
     */
    private static final java.util.Map<PipelineKey, RenderPipeline> modelPipelines = new java.util.HashMap<>();

    /* ---- model ----
     * VertexFormat: POSITION_COLOR_TEXTURE_OVERLAY_LIGHT_NORMAL
     * Samplers: Sampler0 (albedo), Sampler1 (overlay), Sampler2 (lightmap)
     * Builtin std140 UBOs (1.21.5+): DynamicTransforms (ModelViewMat/ColorModulator),
     *                  Projection (ProjMat), Fog, Lighting (Light0/1_Direction).
     * The 1.21.1 per-instance NormalMat/IViewRotMat are gone: the pose normal matrix is now applied
     * CPU-side at buffer-build time (CubicCubeRenderer transforms each Normal before emitting it), so
     * the migrated bbs:core/model GLSL feeds the raw Normal straight into minecraft_mix_light.
     *
     * The field exists for its class-load side effect: it registers the variant every ordinary form
     * draw asks for, so it is compiled with the rest of the pipeline set rather than mid-frame.
     * Consumers reach it through {@link #getModelLayer}, which finds it memoized in modelPipelines.
     */
    @SuppressWarnings("unused")
    private static final RenderPipeline MODEL = modelPipeline(new ModelVariant(FormTranslucentQueue.PASS_SINGLE, true, false), false);

    /* ---- model (culled) ----
     * The MODEL pipeline with backface culling ON, for geometry built as explicit front/back face
     * pairs — the billboard quad emits both faces with opposite winding AND opposite normals, and
     * relies on the GPU to drop the one turned away from the viewer. Without culling both survive:
     * they are coplanar, the back one is emitted second, and LEQUAL lets equal depth through, so
     * the quad ends up showing its back face and is lit from behind (mix_light 0.40 instead of the
     * front face's ~1.0). On 1.21.1 these draws went through the global GL state, where vanilla
     * keeps culling enabled — only LabelFormRenderer and cubic models with !isCulling() switched it
     * off around their own draws, and the billboard's deferred command was flagged cull = true.
     *
     * Registered eagerly for the same reason as MODEL; reached via {@link #getBoundCulledModelLayer()}.
     */
    @SuppressWarnings("unused")
    private static final RenderPipeline MODEL_CULLED = modelPipeline(new ModelVariant(FormTranslucentQueue.PASS_SINGLE, true, true), false);

    /**
     * What distinguishes one model-pipeline variant from another. On 1.21.1 all three were mutable
     * state around a single program — {@code PassMode} a loose uniform, depth-write and cull global GL
     * toggles flipped per draw by {@link FormTranslucentQueue#flush()}. 1.21.5+ has none of that: a
     * pipeline is immutable, so each combination the form renderers actually ask for is its own
     * registered pipeline, built on demand from the same {@code bbs:core/model} GLSL with PASS_MODE
     * supplied as a shader define.
     *
     * @param pass       {@link FormTranslucentQueue#PASS_SINGLE}/{@code PASS_OPAQUE}/{@code PASS_TRANSLUCENT}
     * @param depthWrite solid geometry keeps writing depth so it self-occludes; flat single-quad forms don't
     * @param cull       the model's own culling flag (see MODEL_CULLED)
     */
    public record ModelVariant(int pass, boolean depthWrite, boolean cull)
    {
        public static final ModelVariant SINGLE = new ModelVariant(FormTranslucentQueue.PASS_SINGLE, true, false);

        public ModelVariant withPass(int pass)
        {
            return new ModelVariant(pass, this.depthWrite, this.cull);
        }

        public ModelVariant withDepthWrite(boolean depthWrite)
        {
            return new ModelVariant(this.pass, depthWrite, this.cull);
        }

        public ModelVariant withCull(boolean cull)
        {
            return new ModelVariant(this.pass, this.depthWrite, cull);
        }

        private String suffix()
        {
            return (this.pass == FormTranslucentQueue.PASS_OPAQUE ? "_opaque"
                : this.pass == FormTranslucentQueue.PASS_TRANSLUCENT ? "_translucent"
                : this.pass == FormTranslucentQueue.PASS_TEX_OPAQUE ? "_tex_opaque"
                : this.pass == FormTranslucentQueue.PASS_TEX_TRANSLUCENT ? "_tex_translucent" : "")
                + (this.depthWrite ? "" : "_nodepth")
                + (this.cull ? "_culled" : "");
        }
    }


    /* ---- multilink ----
     * VertexFormat: POSITION_TEXTURE_COLOR
     * Samplers: Sampler0, Sampler3
     * Builtin std140 UBOs (1.21.5+): DynamicTransforms (ModelViewMat/ColorModulator), Projection (ProjMat).
     * Custom std140 UBO MultilinkInfo: Filters(vec4), Size(vec2) — the BBS-specific pixelate/erase params
     * the 1.21.1 shader set imperatively as loose `uniform`s. No fog/lighting (2D UI shader).
     */
    private static final RenderPipeline MULTILINK = registerMultilink();

    /* ---- subtitles ----
     * VertexFormat: POSITION_TEXTURE_COLOR
     * Samplers: Sampler0
     * Builtin std140 UBOs (1.21.5+): DynamicTransforms (ModelViewMat), Projection (ProjMat).
     * Custom std140 UBO SubtitlesInfo: Blur(vec2), TextureSize(vec2) — the BBS-specific blur params
     * the 1.21.1 shader set imperatively as loose `uniform`s. No ColorModulator/fog/lighting (2D UI shader).
     */
    private static final RenderPipeline SUBTITLES = registerSubtitles();

    /* ---- selection ----
     * VertexFormat: POSITION_TEXTURE_COLOR
     * Samplers: Sampler0 (the selection mask, R = selected)
     * Builtin std140 UBOs: DynamicTransforms (ModelViewMat), Projection (ProjMat).
     * Custom std140 UBO SelectionInfo: Phase(float), Scale(float) — marching-ants animation phase +
     * screen pixels per document texel, formerly loose uniforms. Dispatched via ScreenQuadPass.
     */
    private static final RenderPipeline SELECTION = registerSelection();

    /**
     * The std140 UBO block name shared by every migrated picker shader. The block packs the two
     * BBS-custom uniforms the old loose {@code uniform int Target} / {@code uniform vec4 HighlightColor}
     * became (vec4 first for std140 16-byte alignment):
     * <pre>layout(std140) uniform BBSPicker { vec4 HighlightColor; int Target; };</pre>
     * It is uploaded per draw by {@link mchorse.bbs_mod.client.render.picker.BBSPickerRenderer}; the
     * RenderLayer immediate path cannot carry it (it binds only the engine builtins), so picker draws
     * go through that renderer's manual render pass instead of {@link class_1921#method_60895}.
     */
    public static final String PICKER_UNIFORM = "BBSPicker";

    /* ---- picker_preview ----
     * VertexFormat: POSITION_TEXTURE_COLOR
     * Samplers: Sampler0
     * Builtin std140 UBOs: DynamicTransforms (ModelViewMat/ColorModulator), Projection (ProjMat).
     * Custom std140 UBO: BBSPicker (HighlightColor vec4, Target int).
     */
    private static final RenderPipeline PICKER_PREVIEW = registerPicker(
        "picker_preview", class_290.field_1575
    );

    /* ---- picker_billboard ----
     * VertexFormat: POSITION_COLOR_TEXTURE_OVERLAY_LIGHT_NORMAL
     * Samplers: Sampler0
     * Custom std140 UBO: BBSPicker (Target int).
     */
    private static final RenderPipeline PICKER_BILLBOARD = registerPicker(
        "picker_billboard", class_290.field_1580
    );

    /* ---- picker_billboard_no_shading ----
     * VertexFormat: POSITION_TEXTURE_LIGHT_COLOR
     * Samplers: Sampler0
     * Custom std140 UBO: BBSPicker (Target int).
     */
    private static final RenderPipeline PICKER_BILLBOARD_NO_SHADING = registerPicker(
        "picker_billboard_no_shading", class_290.field_1586
    );

    /* ---- picker_particles ----
     * VertexFormat: POSITION_COLOR_TEXTURE_LIGHT
     * Samplers: Sampler0
     * Builtin std140 UBO: DynamicTransforms (ColorModulator), Projection.
     * Custom std140 UBO: BBSPicker (Target int).
     */
    private static final RenderPipeline PICKER_PARTICLES = registerPicker(
        "picker_particles", class_290.field_20888
    );

    /* ---- picker_models ----
     * VertexFormat: POSITION_COLOR_TEXTURE_OVERLAY_LIGHT_NORMAL
     * Samplers: Sampler0
     * Custom std140 UBO: BBSPicker (Target int); per-vertex sub-index added from UV2.x in the shader.
     */
    private static final RenderPipeline PICKER_MODELS = registerPicker(
        "picker_models", class_290.field_1580
    );

    /* ---- particles ----
     * The NORMAL (non-picking) particle pipeline, the faithful equivalent of the 1.21.1
     * GameRenderer::getParticleProgram the original ParticleFormRenderer used for non-shaders
     * rendering (the picker_particles pipeline is for picking only — it outputs a Target-index
     * colour, not the texture). Migrated std140 clone of vanilla's particle shader.
     * VertexFormat: POSITION_TEXTURE_COLOR_LIGHT (matches ParticleEmitter's non-shaders buffer)
     * Samplers: Sampler0 (albedo), Sampler2 (lightmap)
     * Builtin std140 UBOs: DynamicTransforms (ModelViewMat/ColorModulator), Projection, Fog.
     */
    private static final RenderPipeline PARTICLES = registerParticles(false);

    /**
     * The same particle pipeline with blending off, for Bedrock's particles_opaque and
     * particles_alpha materials: only particles_blend blends the texture's alpha, the other two
     * merely cut out transparent pixels, which core/particles does on its own (discard at a < 0.1).
     * 1.21.1 picked this with RenderSystem.enable/disableBlend before the draw; blending is pipeline
     * state here, so the choice is a second pipeline instead.
     */
    private static final RenderPipeline PARTICLES_OPAQUE = registerParticles(false, false);

    /**
     * The world copy of the particle pipeline, assigned to the pack's PARTICLES program (see
     * {@link PipelineKey} for why the shared one cannot be). Built lazily on the first world draw
     * under a pack rather than in {@code <clinit>} — the shared fields above initialise in
     * declaration order and nothing here may run before the pipeline cache exists.
     */
    private static RenderPipeline particlesWorld;

    /* ---- billboard (no shading) ----
     * The unlit billboard pipeline: full texture brightness, no directional light, no lightmap —
     * the faithful equivalent of the 1.21.1 no-shading path, which drew through the vanilla
     * GameRenderer::getPositionTexColorProgram. Reuses vanilla's own position_tex_color GLSL, so
     * there is no BBS shader asset to maintain.
     * VertexFormat: POSITION_TEXTURE_COLOR; Samplers: Sampler0 (albedo).
     * Builtin std140 UBOs: DynamicTransforms (ModelViewMat/ColorModulator), Projection.
     * TRIANGLES: BillboardFormRenderer builds two explicit triangles per side, and the item
     * capture path re-emits by the layer's draw mode — declaring TRIANGLES here keeps both the
     * immediate draw and the re-emit in the buffer's native mode. */
    private static final RenderPipeline BILLBOARD = registerBillboard();

    /* Pixel-art seam smoothing for BBS's own interface, see PixelArt. Each is vanilla's GUI pipeline
     * with only its FRAGMENT shader swapped, so blend, depth, vertex format and uniform blocks stay
     * exactly those of the draw it stands in for — the single difference is how the texture is
     * sampled. Text keeps vanilla's vertex shader too (its varyings are what our fragment reads). */
    private static final RenderPipeline PIXEL_ART = pixelArtPipeline(class_10799.field_56883, "pixelart");
    private static final RenderPipeline PIXEL_ART_TEXT = pixelArtPipeline(class_10799.field_61741, "pixelart_text");
    private static final RenderPipeline PIXEL_ART_TEXT_INTENSITY = pixelArtPipeline(class_10799.field_61742, "pixelart_text_intensity");

    /* Lazily-built render layers (one per pipeline). RenderLayer.of caches nothing itself, so we
     * memoize here to keep a single instance the immediate buffer source can key on.
     *
     * Only the layers something actually draws through live here. The picker_preview / picker_models /
     * picker_billboard_no_shading effects are dispatched by BBSPickerRenderer's manual render pass
     * instead — a RenderLayer binds only the engine builtins and so can never carry the BBSPicker UBO
     * those shaders read (see PICKER_UNIFORM). */
    private static class_1921 billboardLayer;
    private static class_1921 pickerBillboardLayer;
    private static class_1921 pickerParticlesLayer;
    private static class_1921 particlesLayer;
    private static class_1921 particlesOpaqueLayer;
    private static class_1921 particlesWorldLayer;

    /**
     * Kept for API compatibility with the old {@code BBSShaders.setup()} callsite
     * (UIUtilityOverlayPanel). Pipelines are now registered once statically with the vanilla
     * pipeline registry and are reloaded by the engine on resource reload, so there is nothing to
     * re-create here. Left as a no-op.
     *
     * TODO(1.21.11 render): verify at runtime that no explicit re-registration is needed after a
     * resource-pack reload; if it is, move the register(...) calls here behind a guard.
     */
    public static void setup()
    {
    }

    /* ----------------------------------------------------------------------------------------
     * Public API — pipeline accessors. Names kept stable with the 1.21.1 ShaderProgram getters;
     * return type changed ShaderProgram -> RenderPipeline (the faithful 1.21.5 equivalent).
     * ---------------------------------------------------------------------------------------- */

    public static RenderPipeline getMultilinkProgram()
    {
        return MULTILINK;
    }

    public static RenderPipeline getSubtitlesProgram()
    {
        return SUBTITLES;
    }

    public static RenderPipeline getSelectionProgram()
    {
        return SELECTION;
    }

    /**
     * The (non-world) particles pipeline itself — the vanilla-particle preview builds per-atlas
     * layers on it. Crucially it is {@code withCull(false)}: the preview's stand-in camera is
     * orbited freely, so a billboard's winding flips with the viewpoint, and the CULLED vanilla
     * particle pipelines drop every quad that happens to wind backwards — the particles were
     * perfectly present in the buffer and invisible on screen (probe-verified).
     */
    public static RenderPipeline getParticlesPipeline()
    {
        return PARTICLES;
    }

    public static RenderPipeline getPickerPreviewProgram()
    {
        return PICKER_PREVIEW;
    }

    public static RenderPipeline getPickerBillboardProgram()
    {
        return PICKER_BILLBOARD;
    }

    public static RenderPipeline getPickerBillboardNoShadingProgram()
    {
        return PICKER_BILLBOARD_NO_SHADING;
    }

    public static RenderPipeline getPickerParticlesProgram()
    {
        return PICKER_PARTICLES;
    }

    public static RenderPipeline getPickerModelsProgram()
    {
        return PICKER_MODELS;
    }

    /** Textured UI quads (icons, BBS textures, in-panel previews) with the seam smoothing. */
    public static RenderPipeline getPixelArtProgram()
    {
        return PIXEL_ART;
    }

    /** The smoothing counterpart of a vanilla GUI text pipeline, or null if that is not one. */
    public static RenderPipeline getPixelArtTextProgram(RenderPipeline vanilla)
    {
        if (vanilla == class_10799.field_61741)
        {
            return PIXEL_ART_TEXT;
        }

        if (vanilla == class_10799.field_61742)
        {
            return PIXEL_ART_TEXT_INTENSITY;
        }

        return null;
    }

    /* ----------------------------------------------------------------------------------------
     * Public API — render-layer accessors. These wrap the pipeline in a RenderLayer ready for a
     * VertexConsumerProvider. Use these from form/UI renderers instead of the old
     * RenderSystem.setShader(...) + manual buffer flow.
     * ---------------------------------------------------------------------------------------- */

    /**
     * Model layers keyed by variant + the texture they sample. Keyed by texture because a layer with no
     * texture leaves Sampler0 to whatever the driver had — which is how models drew blurred even though
     * their textures were NEAREST and GL agreed. (The form editor never showed it: its preview draws
     * through a vanilla entity layer keyed on the adopted texture, which carries that texture's own
     * sampler.) Keyed by variant because pass/depth-write/cull are pipeline state on 1.21.5+.
     */
    private record ModelLayerKey(ModelVariant variant, net.minecraft.class_2960 texture, boolean world)
    {}

    private static final java.util.Map<ModelLayerKey, class_1921> texturedModelLayers = new java.util.HashMap<>();

    /**
     * The model layer for {@code variant}, bound to {@code texture} (null = no texture bound). Inside
     * the world-forms span with a shaderpack on it resolves to the world copy of the pipeline — the
     * one assigned to the pack's entity program (see {@link PipelineKey}); everywhere else, and always
     * without a pack, the shared copy with BBS's own shader.
     */
    public static class_1921 getModelLayer(ModelVariant variant, net.minecraft.class_2960 texture)
    {
        return texturedModelLayers.computeIfAbsent(new ModelLayerKey(variant, texture, BBSRendering.isIrisWorldForms()), (key) ->
        {
            class_12247.class_12248 setup = class_12247.method_75927(modelPipeline(key.variant(), key.world()))
                .method_75929(class_1921.field_64008)
                .method_75937()
                .method_75928()
                .method_75935();

            if (key.texture() != null)
            {
                setup.method_75934("Sampler0", key.texture());
            }

            return class_1921.method_75940(BBSMod.MOD_ID + "_model" + key.variant().suffix() + (key.world() ? "_world" : "")
                + (key.texture() == null ? "" : "_" + key.texture().method_12832()), setup.method_75938());
        });
    }

    /**
     * The model layer for {@code variant}, bound to whatever texture the renderers last bound through BBS's
     * own texture manager — which is how the immediate model path has always chosen its texture. Resolving
     * it into a real TextureSetup is what keeps Sampler0 on that texture's own sampler.
     */
    public static class_1921 getBoundModelLayer(ModelVariant variant)
    {
        mchorse.bbs_mod.graphics.texture.Texture bound = mchorse.bbs_mod.BBSModClient.getTextures().getLastBound();

        return getModelLayer(variant, bound == null ? null : mchorse.bbs_mod.graphics.texture.AdoptedTexture.identifier(bound));
    }

    public static class_1921 getModelLayer(net.minecraft.class_2960 texture)
    {
        return getModelLayer(ModelVariant.SINGLE, texture);
    }

    public static class_1921 getBoundModelLayer()
    {
        return getBoundModelLayer(ModelVariant.SINGLE);
    }

    /**
     * The backface-culled single-pass model layer: for geometry that emits front AND back faces itself and
     * expects the GPU to keep only the one facing the viewer (see MODEL_CULLED).
     */
    public static class_1921 getBoundCulledModelLayer()
    {
        return getBoundModelLayer(ModelVariant.SINGLE.withCull(true));
    }

    /** Unlit billboard layers keyed by texture, mirroring {@link #getModelLayer(net.minecraft.class_2960)}. */
    private static final java.util.Map<net.minecraft.class_2960, class_1921> texturedBillboardLayers = new java.util.HashMap<>();

    /**
     * The unlit (no-shading) billboard layer bound to the last texture the BBS texture manager bound —
     * same resolution rule as {@link #getBoundModelLayer()}. Full texture brightness: vanilla
     * position_tex_color applies neither directional light nor the lightmap, which is exactly how the
     * 1.21.1 no-shading billboard drew.
     */
    public static class_1921 getBoundBillboardLayer()
    {
        mchorse.bbs_mod.graphics.texture.Texture bound = mchorse.bbs_mod.BBSModClient.getTextures().getLastBound();

        return getBillboardLayer(bound == null ? null : mchorse.bbs_mod.graphics.texture.AdoptedTexture.identifier(bound));
    }

    /**
     * The unlit billboard layer for a texture named outright, for a draw whose texture never goes through
     * the BBS texture manager's bind — the framebuffer form's picture, which lives in a device texture and
     * reaches the layers only by its adopted id.
     */
    public static class_1921 getBillboardLayer(net.minecraft.class_2960 id)
    {
        if (id == null)
        {
            if (billboardLayer == null)
            {
                billboardLayer = class_1921.method_75940(BBSMod.MOD_ID + "_billboard", class_12247.method_75927(BILLBOARD)
                    .method_75929(class_1921.field_64008)
                    .method_75937()
                    .method_75938());
            }

            return billboardLayer;
        }

        return texturedBillboardLayers.computeIfAbsent(id, (key) -> class_1921.method_75940(
            BBSMod.MOD_ID + "_billboard_" + key.method_12832(),
            class_12247.method_75927(BILLBOARD)
                .method_75929(class_1921.field_64008)
                .method_75937()
                .method_75934("Sampler0", key)
                .method_75938()));
    }

    /** The untextured single-pass model layer (Sampler0 left to the driver — see {@link #getModelLayer(ModelVariant, net.minecraft.class_2960)}). */
    public static class_1921 getModelLayer()
    {
        return getModelLayer(ModelVariant.SINGLE, null);
    }

    public static class_1921 getPickerBillboardLayer()
    {
        if (pickerBillboardLayer == null)
        {
            pickerBillboardLayer = layer("picker_billboard", PICKER_BILLBOARD, true);
        }

        return pickerBillboardLayer;
    }

    public static class_1921 getPickerParticlesLayer()
    {
        if (pickerParticlesLayer == null)
        {
            pickerParticlesLayer = layer("picker_particles", PICKER_PARTICLES, false);
        }

        return pickerParticlesLayer;
    }

    /**
     * The normal (non-picking) particle layer. Built with only useLightmap() (Sampler2) — the
     * POSITION_TEXTURE_COLOR_LIGHT format has no overlay (UV1), so unlike {@link #layer} it must NOT
     * call useOverlay(). Sampler0 (the per-emitter texture) is fed via the global texture binding
     * ParticleEmitter.render performs before the draw, same as BillboardFormRenderer.
     */
    public static class_1921 getParticlesLayer()
    {
        if (BBSRendering.isIrisWorldForms())
        {
            if (particlesWorldLayer == null)
            {
                if (particlesWorld == null)
                {
                    particlesWorld = registerParticles(true);
                }

                particlesWorldLayer = class_1921.method_75940(BBSMod.MOD_ID + "_particles_world", class_12247.method_75927(particlesWorld)
                    .method_75929(class_1921.field_64008)
                    .method_75937()
                    .method_75928()
                    .method_75938());
            }

            return particlesWorldLayer;
        }

        if (particlesLayer == null)
        {
            class_12247.class_12248 setup = class_12247.method_75927(PARTICLES)
                .method_75929(class_1921.field_64008)
                .method_75937()
                .method_75928();

            particlesLayer = class_1921.method_75940(BBSMod.MOD_ID + "_particles", setup.method_75938());
        }

        return particlesLayer;
    }

    /**
     * The normal particle layer for a given scheme material: blending only for
     * {@link mchorse.bbs_mod.particles.ParticleMaterial#BLEND}, as on 1.21.1.
     *
     * Under a shader pack the world copy is returned either way - its pipeline is the one handed to
     * Iris as the pack's PARTICLES program, and a second world pipeline would have nothing to be
     * assigned to. Picking never reaches here: the picker pipelines have blending off already.
     */
    public static class_1921 getParticlesLayer(boolean blend)
    {
        if (blend || BBSRendering.isIrisWorldForms())
        {
            return getParticlesLayer();
        }

        if (particlesOpaqueLayer == null)
        {
            class_12247.class_12248 setup = class_12247.method_75927(PARTICLES_OPAQUE)
                .method_75929(class_1921.field_64008)
                .method_75937()
                .method_75928();

            particlesOpaqueLayer = class_1921.method_75940(BBSMod.MOD_ID + "_particles_opaque", setup.method_75938());
        }

        return particlesOpaqueLayer;
    }

    /* ----------------------------------------------------------------------------------------
     * Builders
     * ---------------------------------------------------------------------------------------- */

    /**
     * Build and register the model pipeline. It declares
     * the four builtin std140 UBO blocks the migrated {@code bbs:core/model} GLSL imports
     * (light.glsl / fog.glsl / dynamictransforms.glsl / projection.glsl). Declared in the same order
     * the vanilla entity pipeline uses (DynamicTransforms, Projection, Fog, Lighting) so the engine
     * binds them; without these the model shader fails to link and every world draw is a no-op.
     *
     * <p>One pipeline per {@link ModelVariant}: PASS_MODE rides in as a shader define (the 1.21.1 loose
     * uniform is gone), and depth-write/cull are pipeline state now instead of GL toggles flipped around
     * the draw. Registered on first request and memoized — the engine compiles the GLSL lazily, so a
     * variant nothing asks for costs nothing.
     */
    private static RenderPipeline modelPipeline(ModelVariant variant, boolean world)
    {
        PipelineKey key = new PipelineKey(variant, world);
        RenderPipeline existing = modelPipelines.get(key);

        if (existing != null)
        {
            return existing;
        }

        class_2960 shader = class_2960.method_60655(BBSMod.MOD_ID, "core/model");

        RenderPipeline.Builder builder = RenderPipeline.builder()
            .withLocation(class_2960.method_60655(BBSMod.MOD_ID, "pipeline/model" + variant.suffix() + (world ? "_world" : "")))
            .withVertexShader(shader)
            .withFragmentShader(shader)
            .withVertexFormat(class_290.field_1580, VertexFormat.class_5596.field_27382)
            .withBlend(BLEND)
            .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
            .withDepthWrite(variant.depthWrite())
            .withCull(variant.cull())
            .withUniform("DynamicTransforms", class_10789.field_60031)
            .withUniform("Projection", class_10789.field_60031)
            .withUniform("Fog", class_10789.field_60031)
            .withUniform("Lighting", class_10789.field_60031)
            .withSampler("Sampler0")
            .withSampler("Sampler1")
            .withSampler("Sampler2");

        if (variant.pass() != FormTranslucentQueue.PASS_SINGLE)
        {
            builder.withShaderDefine("PASS_MODE", variant.pass());
        }

        RenderPipeline pipeline = class_10799.method_67887(builder.build());

        if (world)
        {
            /* The model pipeline IS a vanilla entity pipeline with BBS's shader in it — same vertex
             * format, same blend, same depth rules — so a shaderpack should treat it as one, and the
             * honest way to say that is to point at the vanilla pipeline it clones rather than to name a
             * program family. Naming one is what gave forms the ENTITIES_ALPHA program, whose alpha test
             * reads vertex alpha as a discard threshold and deleted every fully opaque form under a pack.
             * Mirroring also brings the shadow-pass assignment (forms cast shadows again) and Iris's own
             * per-phase choice (the hand renderer gets a hand program). See BBSRendering#mirrorIrisPipeline. */
            BBSRendering.mirrorIrisPipeline(pipeline, modelPrototype(variant));
        }

        modelPipelines.put(key, pipeline);

        return pipeline;
    }

    /**
     * The vanilla pipeline a model variant is the BBS-shaded twin of — what a shaderpack should mirror
     * (see {@link BBSRendering#mirrorIrisPipeline}).
     *
     * <p>Cutout, not solid, is the right twin for the ordinary passes: BBS models sample textures with
     * see-through texels and rely on them being dropped, which is exactly what vanilla's cutout entity
     * pipelines mean. Cull follows the variant, since vanilla keeps a culled and an unculled cutout
     * pipeline for the same reason BBS does.
     */
    private static RenderPipeline modelPrototype(ModelVariant variant)
    {
        if (variant.pass() == FormTranslucentQueue.PASS_TRANSLUCENT)
        {
            return class_10799.field_56906;
        }

        return variant.cull() ? class_10799.field_56903 : class_10799.field_56904;
    }

    /**
     * Build and register the unlit billboard pipeline on vanilla's own {@code position_tex_color}
     * shader (see the BILLBOARD field note). Cull ON, like the 1.21.1 draw: the billboard emits the
     * quad as an explicit front/back face pair with opposite winding, so culling keeps exactly one
     * of them — the one facing the viewer. Negative form scales flip both windings together, which
     * only swaps which of the two survives, never drops both. Without culling the two coplanar
     * faces stack, and a semi-transparent texture is blended over itself.
     */
    private static RenderPipeline registerBillboard()
    {
        class_2960 shader = class_2960.method_60655("minecraft", "core/position_tex_color");

        RenderPipeline.Builder builder = RenderPipeline.builder()
            .withLocation(class_2960.method_60655(BBSMod.MOD_ID, "pipeline/billboard"))
            .withVertexShader(shader)
            .withFragmentShader(shader)
            .withVertexFormat(class_290.field_1575, VertexFormat.class_5596.field_27379)
            .withBlend(BLEND)
            .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
            .withCull(true)
            .withUniform("DynamicTransforms", class_10789.field_60031)
            .withUniform("Projection", class_10789.field_60031)
            .withSampler("Sampler0");

        RenderPipeline pipeline = class_10799.method_67887(builder.build());


        return pipeline;
    }

    /**
     * Build and register the particles pipeline. Like {@link #modelPipeline} it declares the builtin
     * std140 UBOs the migrated {@code bbs:core/particles} GLSL imports (fog / dynamictransforms /
     * projection), but no Lighting block (particles are not directionally lit) and the
     * POSITION_TEXTURE_COLOR_LIGHT format the emitter builds. Sampler0 = albedo, Sampler2 = lightmap.
     */
    private static RenderPipeline registerParticles(boolean world)
    {
        return registerParticles(world, true);
    }

    private static RenderPipeline registerParticles(boolean world, boolean blend)
    {
        class_2960 shader = class_2960.method_60655(BBSMod.MOD_ID, "core/particles");

        RenderPipeline.Builder builder = RenderPipeline.builder()
            .withLocation(class_2960.method_60655(BBSMod.MOD_ID, "pipeline/particles" + (world ? "_world" : "") + (blend ? "" : "_opaque")))
            .withVertexShader(shader)
            .withFragmentShader(shader)
            .withVertexFormat(class_290.field_1584, VertexFormat.class_5596.field_27382)
            .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
            .withCull(false)
            .withUniform("DynamicTransforms", class_10789.field_60031)
            .withUniform("Projection", class_10789.field_60031)
            .withUniform("Fog", class_10789.field_60031)
            .withSampler("Sampler0")
            .withSampler("Sampler2");

        if (blend)
        {
            builder.withBlend(BLEND);
        }
        else
        {
            builder.withoutBlend();
        }

        RenderPipeline pipeline = class_10799.method_67887(builder.build());

        if (world)
        {
            BBSRendering.assignIrisPipeline(pipeline, BBSRendering.IrisProgramKind.PARTICLE);
        }

        return pipeline;
    }

    /**
     * Build and register the multilink pipeline (texture-picker pixelate/erase preview). Declares the
     * builtin std140 UBOs the migrated {@code bbs:core/multilink} GLSL imports (DynamicTransforms for
     * ModelViewMat + ColorModulator, Projection for ProjMat) plus the custom std140 {@code MultilinkInfo}
     * block carrying the BBS-specific Filters(vec4)/Size(vec2) that the 1.21.1 shader set as loose
     * uniforms. No Fog/Lighting — it is a 2D UI shader.
     *
     * TODO(1.21.11 render): the per-draw MultilinkInfo UBO (Filters/Size) still needs to be uploaded by
     * the caller when this pipeline is actually dispatched — the multilink editor currently routes
     * through the deprecated Batcher2D.texturedBox bridge which ignores the pipeline, so the values are
     * not yet supplied. Wire the UBO when the multilink preview is re-routed onto this layer.
     */
    private static RenderPipeline registerMultilink()
    {
        class_2960 shader = class_2960.method_60655(BBSMod.MOD_ID, "core/multilink");

        RenderPipeline.Builder builder = RenderPipeline.builder()
            .withLocation(class_2960.method_60655(BBSMod.MOD_ID, "pipeline/multilink"))
            .withVertexShader(shader)
            .withFragmentShader(shader)
            .withVertexFormat(class_290.field_1575, VertexFormat.class_5596.field_27382)
            .withBlend(BLEND)
            .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
            .withCull(false)
            .withUniform("DynamicTransforms", class_10789.field_60031)
            .withUniform("Projection", class_10789.field_60031)
            .withUniform("MultilinkInfo", class_10789.field_60031)
            .withSampler("Sampler0")
            .withSampler("Sampler3");

        return class_10799.method_67887(builder.build());
    }

    /**
     * Build and register the subtitles pipeline (blurred subtitle text). Declares the builtin std140
     * UBOs the migrated {@code bbs:core/subtitles} GLSL imports (DynamicTransforms for ModelViewMat,
     * Projection for ProjMat) plus the custom std140 {@code SubtitlesInfo} block carrying the
     * BBS-specific Blur(vec2)/TextureSize(vec2) that the 1.21.1 shader set as loose uniforms. No
     * ColorModulator/Fog/Lighting — it is a 2D UI shader that modulates by vertexColor only.
     *
     * TODO(1.21.11 render): the per-draw SubtitlesInfo UBO (Blur/TextureSize) still needs to be uploaded
     * by the caller when this pipeline is actually dispatched — the subtitle renderer currently routes
     * through the deprecated Batcher2D.texturedBox bridge which ignores the pipeline, so the values are
     * not yet supplied. Wire the UBO when the subtitle blur is re-routed onto this layer.
     */
    /**
     * Build and register the selection (marching ants) pipeline. Blend off — the shader either
     * discards or writes an opaque checker texel; no depth (a flat overlay into its own target).
     */
    private static RenderPipeline registerSelection()
    {
        class_2960 shader = class_2960.method_60655(BBSMod.MOD_ID, "core/selection");

        RenderPipeline.Builder builder = RenderPipeline.builder()
            .withLocation(class_2960.method_60655(BBSMod.MOD_ID, "pipeline/selection"))
            .withVertexShader(shader)
            .withFragmentShader(shader)
            .withVertexFormat(class_290.field_1575, VertexFormat.class_5596.field_27382)
            .withoutBlend()
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
            .withCull(false)
            .withUniform("DynamicTransforms", class_10789.field_60031)
            .withUniform("Projection", class_10789.field_60031)
            .withUniform("SelectionInfo", class_10789.field_60031)
            .withSampler("Sampler0");

        return class_10799.method_67887(builder.build());
    }

    /**
     * Vanilla's {@code prototype} with its fragment shader replaced by {@code bbs:core/<name>}.
     *
     * <p>Copied rather than rebuilt from scratch on purpose: these pipelines stand in for a vanilla
     * draw mid-frame, so every other piece of state — blend function, depth test, write masks, vertex
     * format, declared samplers and uniform blocks — has to be the one vanilla would have used. Naming
     * them by hand means re-deriving that list from vanilla's private snippets and re-deriving it again
     * every time they change; asking the prototype cannot drift.</p>
     */
    private static RenderPipeline pixelArtPipeline(RenderPipeline prototype, String name)
    {
        RenderPipeline.Builder builder = RenderPipeline.builder()
            .withLocation(class_2960.method_60655(BBSMod.MOD_ID, "pipeline/" + name))
            .withVertexShader(prototype.getVertexShader())
            .withFragmentShader(class_2960.method_60655(BBSMod.MOD_ID, "core/" + name))
            .withVertexFormat(prototype.getVertexFormat(), prototype.getVertexFormatMode())
            .withDepthTestFunction(prototype.getDepthTestFunction())
            .withPolygonMode(prototype.getPolygonMode())
            .withCull(prototype.isCull())
            .withColorLogic(prototype.getColorLogic())
            .withColorWrite(prototype.isWriteColor(), prototype.isWriteAlpha())
            .withDepthWrite(prototype.isWriteDepth())
            .withDepthBias(prototype.getDepthBiasScaleFactor(), prototype.getDepthBiasConstant());

        prototype.getBlendFunction().ifPresentOrElse(builder::withBlend, builder::withoutBlend);

        for (String sampler : prototype.getSamplers())
        {
            builder.withSampler(sampler);
        }

        for (RenderPipeline.UniformDescription uniform : prototype.getUniforms())
        {
            builder.withUniform(uniform.name(), uniform.type());
        }

        class_10149 defines = prototype.getShaderDefines();

        for (String flag : defines.comp_3104())
        {
            builder.withShaderDefine(flag);
        }

        if (!defines.comp_3103().isEmpty())
        {
            /* The builder only takes int/float defines, so a valued one cannot be copied. None of the
             * GUI prototypes has any; if vanilla ever adds one, the copy would compile a shader with a
             * different meaning than the draw it replaces, and that must not pass silently. */
            LogUtils.getLogger().warn("[BBS shaders] {} carries shader defines {} that {} cannot copy", prototype.getLocation(), defines.comp_3103(), name);
        }

        return class_10799.method_67887(builder.build());
    }

    private static RenderPipeline registerSubtitles()
    {
        class_2960 shader = class_2960.method_60655(BBSMod.MOD_ID, "core/subtitles");

        RenderPipeline.Builder builder = RenderPipeline.builder()
            .withLocation(class_2960.method_60655(BBSMod.MOD_ID, "pipeline/subtitles"))
            .withVertexShader(shader)
            .withFragmentShader(shader)
            .withVertexFormat(class_290.field_1575, VertexFormat.class_5596.field_27382)
            .withBlend(BLEND)
            .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
            .withCull(false)
            .withUniform("DynamicTransforms", class_10789.field_60031)
            .withUniform("Projection", class_10789.field_60031)
            .withUniform("SubtitlesInfo", class_10789.field_60031)
            .withSampler("Sampler0");

        return class_10799.method_67887(builder.build());
    }

    /**
     * Build and register a picker RenderPipeline. The migrated {@code bbs:core/picker_*} GLSL imports
     * the builtin DynamicTransforms (ModelViewMat/ColorModulator) and Projection (ProjMat) std140 UBOs
     * and declares one custom std140 block, {@link #PICKER_UNIFORM} (HighlightColor vec4, Target int),
     * uploaded per draw. Only Sampler0 is used (picking never samples the lightmap). The original
     * 1.21.1 picker programs declared a Sampler2 they never read; it is dropped here.
     */
    private static RenderPipeline registerPicker(String name, VertexFormat format)
    {
        class_2960 shader = class_2960.method_60655(BBSMod.MOD_ID, "core/" + name);

        RenderPipeline.Builder builder = RenderPipeline.builder()
            .withLocation(class_2960.method_60655(BBSMod.MOD_ID, "pipeline/" + name))
            .withVertexShader(shader)
            .withFragmentShader(shader)
            .withVertexFormat(format, VertexFormat.class_5596.field_27382)
            /* Blend MUST be off for every picker pipeline. The geometry pickers encode an object index in
             * the exact vertex colour, and a blended pixel is a corrupt id. picker_preview writes the
             * highlight colour into an off-screen target that is later composited by the caller's blit:
             * blending it against the transparent-black clear premultiplied it, so the blit multiplied by
             * alpha a SECOND time and any highlight below full opacity came out dark (it looked right only
             * at alpha 1, where the square is a no-op). */
            .withoutBlend()
            .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
            .withCull(false)
            .withUniform("DynamicTransforms", class_10789.field_60031)
            .withUniform("Projection", class_10789.field_60031)
            .withUniform(PICKER_UNIFORM, class_10789.field_60031)
            .withSampler("Sampler0");

        return class_10799.method_67887(builder.build());
    }

    /**
     * Wrap a pipeline in a RenderLayer. The expected buffer size mirrors the vanilla entity-layer
     * default; affectsOutline/translucent are passed through to RenderSetup.
     */
    private static class_1921 layer(String name, RenderPipeline pipeline, boolean useLightmapOverlay)
    {
        class_12247.class_12248 setup = class_12247.method_75927(pipeline)
            .method_75929(class_1921.field_64008)
            .method_75937();

        if (useLightmapOverlay)
        {
            setup.method_75928().method_75935();
        }

        return class_1921.method_75940(BBSMod.MOD_ID + "_" + name, setup.method_75938());
    }
}
