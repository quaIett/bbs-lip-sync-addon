package mchorse.bbs_mod.client;

import com.mojang.blaze3d.systems.RenderSystem;
import mchorse.bbs_mod.forms.FormUtilsClient;
import mchorse.bbs_mod.forms.QueueDispatch;
import net.minecraft.class_11228;
import net.minecraft.class_11246;
import net.minecraft.class_310;
import net.minecraft.class_332;
import java.util.List;

/**
 * A tiny standalone GUI pass for the two overlays that draw OUTSIDE the vanilla GUI phase:
 * the recording indicator (drawn after the export snapshot so it shows on screen but never
 * lands in the file) and the playback subtitles (drawn at world-render end so a world export
 * captures them).
 *
 * <p>On 1.21.1 both just drew immediately into whatever framebuffer was bound. The 1.21.6
 * two-phase GUI made {@code DrawContext} a recorder: whoever holds the {@link class_11246}
 * must also render it, and these call sites recorded into a throwaway state nobody rendered —
 * the indicator and export subtitles silently vanished. This helper owns a private state and a
 * private {@link class_11228} (over the BBS provider and {@link QueueDispatch}'s dispatcher)
 * and flushes the recording on {@link #end()} — into {@code MinecraftClient.getFramebuffer()},
 * which is exactly right for both callers: during an export snapshot-restore that is the
 * screen framebuffer (operator UI), and at world-render end it is the export framebuffer
 * (subtitles belong in the film).
 */
public class ImmediateGui
{
    private static class_11246 state;
    private static class_11228 renderer;

    /** Begin recording; draw into the returned context, then call {@link #end()}. */
    public static class_332 begin()
    {
        class_310 mc = class_310.method_1551();

        if (renderer == null)
        {
            state = new class_11246();
            renderer = new class_11228(state, FormUtilsClient.getProvider(), QueueDispatch.queue(), QueueDispatch.dispatcher(), List.of());
        }

        return new class_332(mc, state, mc.method_22683().method_4486(), mc.method_22683().method_4502());
    }

    /** Render everything recorded since {@link #begin()} right now. */
    public static void end()
    {
        renderer.method_70879();
        renderer.method_70890(RenderSystem.getShaderFog());
        state.method_70926();
    }
}
