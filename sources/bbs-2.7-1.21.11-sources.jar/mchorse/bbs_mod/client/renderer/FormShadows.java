package mchorse.bbs_mod.client.renderer;

import mchorse.bbs_mod.forms.CustomVertexConsumerProvider;
import mchorse.bbs_mod.forms.FormUtilsClient;
import net.minecraft.class_10017;
import net.minecraft.class_12249;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2464;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_638;
import net.minecraft.class_765;
import net.minecraft.class_9848;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

/**
 * Entity-style ground shadows for BBS-owned renderables (film replays, model blocks), ported
 * onto the 1.21.5+ render-state pipeline.
 *
 * <p>Vanilla 1.21.1 exposed {@code EntityRenderDispatcher#renderShadow}, which BBS used to call
 * with a fake actor entity. The render-state rewrite removed it: shadows are now recorded as
 * {@link class_10017.class_11680}s (built in {@code EntityRenderer#updateShadow} /
 * {@code addShadowPiece}) and drawn by {@code ShadowPiecesCommandRenderer} through the command
 * queue. This class mirrors both halves, byte-for-byte in math, so BBS callers can either submit
 * the pieces to a queue (model-block path) or draw them immediately (film's AFTER_ENTITIES
 * context, where BBS's whole form pipeline is immediate).
 */
public class FormShadows
{
    /**
     * Build the shadow pieces under ({@code x}, {@code y}, {@code z}) — the vanilla
     * {@code updateShadow}/{@code addShadowPiece} logic: scan the column region beneath the
     * position, keep full-cube lit blocks, fade the alpha with camera distance, depth below
     * the entity and sky brightness.
     */
    public static List<class_10017.class_11680> buildPieces(class_638 world, double x, double y, double z, float radius, float opacity, double squaredDistanceToCamera)
    {
        List<class_10017.class_11680> pieces = new ArrayList<>();

        if (!class_310.method_1551().field_1690.method_42435().method_41753())
        {
            return pieces;
        }

        radius = Math.min(radius, 32F);

        float alpha = (float) ((1D - squaredDistanceToCamera / 256D) * opacity);

        if (radius <= 0F || alpha <= 0F)
        {
            return pieces;
        }

        int minX = class_3532.method_15357(x - radius);
        int maxX = class_3532.method_15357(x + radius);
        int minZ = class_3532.method_15357(z - radius);
        int maxZ = class_3532.method_15357(z + radius);
        /* Column depth: 1.21.11 vanilla scans min(alpha / 0.5 - 1, radius) blocks down, which goes
         * NEGATIVE once the camera is past ~11 blocks (alpha < 0.5) — minY climbs above maxY, the
         * loop never runs and the shadow vanishes entirely. That is fine for vanilla's near-camera
         * mobs but kills film shadows: the editor's orbit camera routinely sits 12-20 blocks out.
         * Use the 1.21.1 depth, min(alpha / 0.5, radius) — no "- 1" — which stays positive for as
         * long as the distance fade itself does (alpha hits 0 at 16 blocks either way). */
        int minY = class_3532.method_15357(y - Math.min(alpha / 0.5F, radius));
        int maxY = class_3532.method_15357(y);

        class_2338.class_2339 mutable = new class_2338.class_2339();

        for (int bx = minX; bx <= maxX; bx++)
        {
            for (int bz = minZ; bz <= maxZ; bz++)
            {
                class_2818 chunk = world.method_8497(bx >> 4, bz >> 4);

                for (int by = maxY; by >= minY; by--)
                {
                    addPiece(pieces, world, chunk, mutable.method_10103(bx, by, bz), x, y, z, alpha);
                }
            }
        }

        return pieces;
    }

    /** One vanilla {@code addShadowPiece}: block-under checks + per-piece alpha. */
    private static void addPiece(List<class_10017.class_11680> pieces, class_638 world, class_2818 chunk, class_2338.class_2339 pos, double x, double y, double z, float alpha)
    {
        float pieceAlpha = alpha - (float) (y - pos.method_10264()) * 0.5F;

        class_2338 down = pos.method_10074();
        class_2680 state = chunk.method_8320(down);

        if (state.method_26217() == class_2464.field_11455)
        {
            return;
        }

        int light = world.method_22339(pos);

        if (light <= 3)
        {
            return;
        }

        if (!state.method_26234(chunk, down))
        {
            return;
        }

        class_265 shape = state.method_26218(chunk, down);

        if (shape.method_1110())
        {
            return;
        }

        float brightness = class_3532.method_15363(pieceAlpha * 0.5F * class_765.method_23284(world.method_8597(), light), 0F, 1F);

        pieces.add(new class_10017.class_11680((float) (pos.method_10263() - x), (float) (pos.method_10264() - y), (float) (pos.method_10260() - z), shape, brightness));
    }

    /**
     * Draw the pieces immediately through the entity-shadow layer — the same quads
     * {@code ShadowPiecesCommandRenderer} emits, for contexts with no command queue
     * (the film's immediate AFTER_ENTITIES rendering).
     */
    public static void drawImmediate(class_4587 matrices, List<class_10017.class_11680> pieces, float radius)
    {
        if (pieces.isEmpty())
        {
            return;
        }

        /* Route through BBS's immediate provider — the same path every other vanilla-layer draw in
         * the film's AFTER_ENTITIES context takes (name tags etc.) — instead of a bare Tessellator
         * whose BuiltBuffer lifecycle we would own. consumers.draw() ends the batch properly. */
        CustomVertexConsumerProvider consumers = FormUtilsClient.getProvider();
        class_4588 builder = consumers.method_73477(class_12249.method_76010(net.minecraft.class_2960.method_60656("textures/misc/shadow.png")));
        Matrix4f matrix = matrices.method_23760().method_23761();

        for (class_10017.class_11680 piece : pieces)
        {
            class_238 box = piece.comp_4549().method_1107();

            float x1 = piece.comp_4546() + (float) box.field_1323;
            float x2 = piece.comp_4546() + (float) box.field_1320;
            float y1 = piece.comp_4547() + (float) box.field_1322;
            float z1 = piece.comp_4548() + (float) box.field_1321;
            float z2 = piece.comp_4548() + (float) box.field_1324;
            float u1 = -x1 / 2F / radius + 0.5F;
            float u2 = -x2 / 2F / radius + 0.5F;
            float v1 = -z1 / 2F / radius + 0.5F;
            float v2 = -z2 / 2F / radius + 0.5F;
            int color = class_9848.method_61317(piece.comp_4550());

            vertex(builder, matrix, color, x1, y1, z1, u1, v1);
            vertex(builder, matrix, color, x1, y1, z2, u1, v2);
            vertex(builder, matrix, color, x2, y1, z2, u2, v2);
            vertex(builder, matrix, color, x2, y1, z1, u2, v1);
        }

        consumers.method_22993();
    }

    private static void vertex(class_4588 builder, Matrix4f matrix, int color, float x, float y, float z, float u, float v)
    {
        builder.method_22918(matrix, x, y, z).method_39415(color).method_22913(u, v).method_22922(class_4608.field_21444).method_60803(15728880).method_22914(0F, 1F, 0F);
    }
}
