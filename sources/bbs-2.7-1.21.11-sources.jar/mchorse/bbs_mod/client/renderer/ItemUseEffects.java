package mchorse.bbs_mod.client.renderer;

import mchorse.bbs_mod.cubic.animation.ItemUsePose;
import mchorse.bbs_mod.film.replays.Replay;
import mchorse.bbs_mod.film.replays.ReplayItemUse;
import mchorse.bbs_mod.forms.entities.IEntity;
import net.minecraft.class_10124;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2392;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_9334;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * Vanilla's eating and drinking effects for actors playing back a film: the
 * crumbs flying out of the mouth, the chewing and gulping, the burp at the end.
 *
 * <p>Live players get all of this from vanilla itself - it runs while the item
 * use ticks. A film's actor never ticks one: the use is a clip, so the schedule
 * ({@code LivingEntity.tickItemStackUsage} and its consumption effects, taken
 * off the 1.20.4 bytecode) is replayed from the clip's own phase instead. The
 * long window an author may give a clip is respected: crumbs keep flying for as
 * long as the eating lasts.</p>
 */
public class ItemUseEffects
{
    /** The last film tick each hand emitted on, per actor. */
    private static final Map<IEntity, int[]> LAST = new WeakHashMap<>();

    public static void tick(Replay replay, IEntity entity, int tick)
    {
        emit(replay, entity, tick, true);
        emit(replay, entity, tick, false);
    }

    public static void clear()
    {
        LAST.clear();
    }

    private static void emit(Replay replay, IEntity entity, int tick, boolean mainHand)
    {
        int[] last = LAST.computeIfAbsent(entity, (e) -> new int[] {Integer.MIN_VALUE, Integer.MIN_VALUE});
        int index = mainHand ? 0 : 1;
        int previous = last[index];

        last[index] = tick;

        /* Effects ride a running film only: a paused timeline would spit crumbs
         * forever and a scrubbed one would spit a whole meal at once. */
        if (tick != previous + 1)
        {
            return;
        }

        class_1309 user = ItemUsePose.livingOf(entity);
        ItemUsePose.Use use = ReplayItemUse.compute(replay, tick, mainHand, user);

        if (use == null)
        {
            /* The bite that just ended: vanilla's finishing burst and burp. */
            ItemUsePose.Use before = ReplayItemUse.compute(replay, tick - 1, mainHand, user);

            if (before != null && before.action() == class_1839.field_8950)
            {
                spawn(entity, before.stack(), class_1839.field_8950, 16);
                burp(entity, before.stack());
            }

            return;
        }

        if (use.action() != class_1839.field_8950 && use.action() != class_1839.field_8946)
        {
            return;
        }

        /* shouldSpawnConsumptionEffects: 1.21.1 dropped the snack exception the
         * older versions had - the crumbs start once 21.875% of the use is
         * behind, and then fly every 4th tick left. */
        int max = Math.round(use.window());
        int left = Math.round(use.window() - use.elapsed());
        boolean due = max - left > (int) (max * 0.21875F);

        if (due && left % 4 == 0)
        {
            spawn(entity, use.stack(), use.action(), 5);
        }
    }

    /** {@code LivingEntity.spawnConsumptionEffects} plus its {@code spawnItemParticles}. */
    private static void spawn(IEntity entity, class_1799 stack, class_1839 action, int count)
    {
        class_1937 world = entity.getWorld();

        if (world == null || stack.method_7960())
        {
            return;
        }

        class_5819 random = world.field_9229;
        double x = entity.getX();
        double y = entity.getY() + entity.getEyeHeight();
        double z = entity.getZ();

        class_10124 consumable = stack.method_58694(class_9334.field_53964);

        /* 1.21.4+ folded the eating and drinking sounds, and the "does it even make crumbs"
         * answer, into the consumable component - getEatSound/getDrinkSound are gone. */
        if (consumable != null && !consumable.comp_3088())
        {
            count = 0;
        }

        if (action == class_1839.field_8946)
        {
            playSound(world, x, y, z, consumeSound(entity, consumable, stack), 0.5F, class_3532.method_32750(random, 0.9F, 1F));

            return;
        }

        float pitch = -entity.getPitch() * 0.017453292F;
        float yaw = -entity.getYaw() * 0.017453292F;

        for (int i = 0; i < count; i++)
        {
            class_243 velocity = new class_243((random.method_43057() - 0.5D) * 0.1D, Math.random() * 0.1D + 0.1D, 0D)
                .method_1037(pitch)
                .method_1024(yaw);
            class_243 position = new class_243((random.method_43057() - 0.5D) * 0.3D, -random.method_43057() * 0.6D - 0.3D, 0.6D)
                .method_1037(pitch)
                .method_1024(yaw)
                .method_1031(x, y, z);

            world.method_8406(new class_2392(class_2398.field_11218, stack), position.field_1352, position.field_1351, position.field_1350, velocity.field_1352, velocity.field_1351 + 0.05D, velocity.field_1350);
        }

        playSound(world, x, y, z, consumeSound(entity, consumable, stack),
            random.method_43056() ? 0.5F : 1F,
            random.method_62816(1F, 0.2F));
    }

    /**
     * The sound eating or drinking this stack makes: the body gets to answer for itself
     * (ConsumableSoundProvider - vanilla asks the entity, not the item), and the component's
     * own sound otherwise.
     */
    private static class_3414 consumeSound(IEntity entity, class_10124 consumable, class_1799 stack)
    {
        class_1309 living = ItemUsePose.livingOf(entity);

        if (living instanceof class_10124.class_10126 provider)
        {
            return provider.method_18807(stack);
        }

        return consumable == null ? null : consumable.comp_3087().comp_349();
    }

    /**
     * ⚠ {@code World#playSound(PlayerEntity except, ...)} means the opposite of
     * what it reads like on the client: {@link class_638} plays the sound only
     * when {@code except} IS the local player (vanilla calls it from the local
     * player's own code, everyone else's sounds arrive as packets). Passing
     * {@code null} would be silence, so the client entry point is used directly.
     */
    private static void playSound(class_1937 world, double x, double y, double z, class_3414 sound, float volume, float pitch)
    {
        if (sound != null && world instanceof class_638 clientWorld)
        {
            clientWorld.method_8486(x, y, z, sound, class_3419.field_15248, volume, pitch, false);
        }
    }

    /** {@code PlayerEntity.eatFood}'s tail: only actual food burps. */
    private static void burp(IEntity entity, class_1799 stack)
    {
        class_1937 world = entity.getWorld();

        if (world == null || stack.method_58694(class_9334.field_50075) == null)
        {
            return;
        }

        playSound(world, entity.getX(), entity.getY(), entity.getZ(), class_3417.field_19149, 0.5F, world.field_9229.method_43057() * 0.1F + 0.9F);
    }
}
