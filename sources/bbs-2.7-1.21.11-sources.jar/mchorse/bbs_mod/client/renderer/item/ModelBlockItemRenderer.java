package mchorse.bbs_mod.client.renderer.item;

import mchorse.bbs_mod.BBSMod;
import mchorse.bbs_mod.blocks.entities.ModelBlockEntity;
import mchorse.bbs_mod.forms.entities.IEntity;
import mchorse.bbs_mod.forms.entities.StubEntity;
import net.minecraft.class_11580;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_9334;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Holder for the model-block item's per-stack render state (properties + form entity +
 * expiration). Rendering itself lives in {@link ModelBlockSpecialRenderer} (1.21.5+ item-model
 * system); this class keeps the data lifecycle (update ticking, stack lookup, block-entity
 * data hydration) that the renderer and the model-block editor share.
 */
public class ModelBlockItemRenderer
{
    private Map<class_1799, Item> map = new HashMap<>();

    public void update()
    {
        Iterator<Item> it = this.map.values().iterator();

        while (it.hasNext())
        {
            Item item = it.next();

            if (item.expiration <= 0)
            {
                it.remove();
            }

            item.expiration -= 1;
            item.entity.getProperties().update(item.formEntity);
            item.formEntity.update();
        }
    }

    public Item get(class_1799 stack)
    {
        if (stack == null || stack.method_7909() != BBSMod.MODEL_BLOCK_ITEM)
        {
            return null;
        }

        if (this.map.containsKey(stack))
        {
            return this.map.get(stack);
        }

        ModelBlockEntity entity = new ModelBlockEntity(class_2338.field_10980, BBSMod.MODEL_BLOCK.method_9564());
        Item item = new Item(entity);

        this.map.put(stack, item);

        class_11580<?> beComponent = stack.method_58694(class_9334.field_49611);

        if (beComponent == null)
        {
            return item;
        }

        entity.readProperties(beComponent.method_72540());

        return item;
    }

    public static class Item
    {
        public ModelBlockEntity entity;
        public IEntity formEntity;
        public int expiration = 20;

        public Item(ModelBlockEntity entity)
        {
            this.entity = entity;
            this.formEntity = new StubEntity(class_310.method_1551().field_1687);
        }
    }
}