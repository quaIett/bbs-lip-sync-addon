package mchorse.bbs_mod.client.renderer.entity;

import mchorse.bbs_mod.BBSModClient;
import mchorse.bbs_mod.client.BBSRendering;
import mchorse.bbs_mod.client.renderer.DeathPose;
import mchorse.bbs_mod.cubic.render.vanilla.ArmorRenderer;
import mchorse.bbs_mod.entity.ActorEntity;
import mchorse.bbs_mod.forms.FormUtilsClient;
import mchorse.bbs_mod.forms.forms.Form;
import mchorse.bbs_mod.forms.renderers.FormRenderType;
import mchorse.bbs_mod.forms.renderers.FormRenderingContext;
import net.minecraft.class_10042;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4050;
import net.minecraft.class_4587;
import net.minecraft.class_5602;
import net.minecraft.class_5617;
import net.minecraft.class_572;
import net.minecraft.class_7833;
import net.minecraft.class_897;
import net.minecraft.class_922;

public class ActorEntityRenderer extends class_897<ActorEntity, ActorEntityRenderer.ActorRenderState>
{
    public static ArmorRenderer armorRenderer;

    /**
     * The form + vanilla-entity context cannot be carried on a vanilla render state, so the actual
     * BBS form rendering still reads off the live {@link ActorEntity}. It rides on the state the
     * frame is drawn from and never on the renderer: 1.21.11 fills the render states of every entity
     * first (WorldRenderer#fillEntityRenderStates) and draws them only afterwards
     * (WorldRenderer#pushEntityRenders), so a field on the renderer holds whichever actor was
     * extracted last - and every actor of the film gets drawn with that one's form and pose.
     */
    public static class ActorRenderState extends class_10042
    {
        public ActorEntity entity;
        public float tickDelta;
    }

    public ActorEntityRenderer(class_5617.class_5618 ctx)
    {
        super(ctx);

        /* 1.21.4+ equipment rewrite: the inner/outer armor layers became per-slot equipment model
         * layers (EntityModelLayers.PLAYER_EQUIPMENT: head/chest/legs/feet). The armor geometry
         * MUST come from these — building the models off the PLAYER layer put the 64x32 armor
         * texture onto player-model UVs, which is exactly the garbled full-body leather look. */
        armorRenderer = new ArmorRenderer(
            class_5602.field_61701.method_72962((layer) -> new class_572(ctx.method_32167(layer))),
            ctx.method_32167(class_5602.field_27559),
            ctx.method_64071()
        );

        /* The film draws an actor's shadow itself, sized and offset by the replay. A vanilla shadow
         * underneath would be a second one, at a fixed size nobody asked for. */
        this.field_4673 = 0F;
    }

    @Override
    public ActorRenderState method_55269()
    {
        return new ActorRenderState();
    }

    @Override
    public void updateRenderState(ActorEntity entity, ActorRenderState state, float tickDelta)
    {
        super.method_62354(entity, state, tickDelta);

        state.entity = entity;
        state.tickDelta = tickDelta;

        state.field_53446 = class_3532.method_17821(tickDelta, entity.field_6220, entity.field_6283);
        state.field_53449 = entity.field_6213 > 0 ? entity.field_6213 + tickDelta : 0F;

        /* The red damage flash, exactly as LivingEntityRenderer derives it: a blow OR a death. The
         * death half is what keeps the body red for the whole fall - this renderer extends
         * EntityRenderer and fills the living state itself, so nothing else was setting it. */
        state.field_53460 = entity.field_6235 > 0 || entity.field_6213 > 0;
        state.field_53465 = entity.method_18376();
        state.field_53333 = entity.method_5767();
    }

    @Override
    public void render(ActorRenderState state, class_4587 matrices, class_11659 queue, class_12075 cameraState)
    {
        ActorEntity entity = state.entity;

        /* A film running on this client draws its own actors, from their keyframes — drawing them
         * here as well would be a second body, a frame behind the first. This is for everyone else:
         * a player who happens to be standing in someone else's scene still sees the cast. */
        if (entity != null && BBSModClient.getFilms().isActorDrawn(entity.method_5628()))
        {
            return;
        }

        super.method_3936(state, matrices, queue, cameraState);

        if (entity == null || !this.isVisible(state))
        {
            return;
        }

        matrices.method_22903();

        int overlay = class_922.method_23622(state, 0F);

        this.setupTransforms(state, matrices);

        /* TODO(1.21.11 render): blend/depth state is now pipeline-encoded; the explicit
         * RenderSystem.enableBlend/enableDepthTest toggles were removed. */
        Form form = entity.getForm();

        /* An actor standing in the world is a world draw, so it goes inside the world-forms span —
         * the same rule the morph's first-person arm and a held model item already follow. Outside it
         * the draw takes the shared {@code bbs:pipeline/model}, which carries no shaderpack program
         * assignment ("Missing program bbs:pipeline/model in override list" in the log), so under a
         * pack the actor came out ghosted while every replay the film editor draws itself — those go
         * through the span — stayed solid. That asymmetry was the whole bug report: the actor turns
         * see-through the moment shaders are on. */
        boolean prevWorldForms = BBSRendering.beginWorldForms();

        try
        {
            FormUtilsClient.render(form, new FormRenderingContext()
                .set(FormRenderType.ENTITY, entity.getFormEntity(), matrices, state.field_61820, overlay, state.tickDelta)
                .camera(class_310.method_1551().field_1773.method_19418()));
        }
        finally
        {
            BBSRendering.endWorldForms(prevWorldForms);

            matrices.method_22909();
        }
    }

    protected boolean isVisible(class_10042 state)
    {
        return !state.field_53333;
    }

    protected void setupTransforms(class_10042 state, class_4587 matrices)
    {
        if (!state.method_62613(class_4050.field_18078))
        {
            matrices.method_22907(class_7833.field_40716.rotationDegrees(-state.field_53446));
        }

        DeathPose.apply(matrices, state.field_53449);
    }
}
