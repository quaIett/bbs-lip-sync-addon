package mchorse.bbs_mod.client.renderer.entity;

import mchorse.bbs_mod.client.BBSRendering;
import mchorse.bbs_mod.entity.GunProjectileEntity;
import mchorse.bbs_mod.forms.FormUtilsClient;
import mchorse.bbs_mod.forms.renderers.FormRenderType;
import mchorse.bbs_mod.forms.renderers.FormRenderingContext;
import mchorse.bbs_mod.items.GunProperties;
import mchorse.bbs_mod.utils.MatrixStackUtils;
import mchorse.bbs_mod.utils.interps.Lerps;
import net.minecraft.class_10017;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_5617;
import net.minecraft.class_7833;
import net.minecraft.class_897;

public class GunProjectileEntityRenderer extends class_897<GunProjectileEntity, GunProjectileEntityRenderer.GunProjectileRenderState>
{
    public GunProjectileEntityRenderer(class_5617.class_5618 ctx)
    {
        super(ctx);
    }

    @Override
    public GunProjectileRenderState method_55269()
    {
        return new GunProjectileRenderState();
    }

    @Override
    public void updateRenderState(GunProjectileEntity entity, GunProjectileRenderState state, float tickDelta)
    {
        super.method_62354(entity, state, tickDelta);

        GunProperties properties = entity.getProperties();
        int out = properties.lifeSpan - 2;

        state.entity = entity;
        state.tickDelta = tickDelta;
        state.bodyYaw = class_3532.method_17821(tickDelta, entity.field_5982, entity.method_36454());
        state.entityPitch = class_3532.method_17821(tickDelta, entity.field_6004, entity.method_36455());
        state.fadeScale = Lerps.envelope(entity.field_6012 + tickDelta, 0, properties.fadeIn, out - properties.fadeOut, out);
    }

    @Override
    public void render(GunProjectileRenderState state, class_4587 matrices, class_11659 queue, class_12075 cameraState)
    {
        super.method_3936(state, matrices, queue, cameraState);

        GunProjectileEntity projectile = state.entity;

        if (projectile == null)
        {
            return;
        }

        GunProperties properties = projectile.getProperties();

        matrices.method_22903();

        if (properties.yaw) matrices.method_22907(class_7833.field_40716.rotationDegrees(state.bodyYaw));
        if (properties.pitch) matrices.method_22907(class_7833.field_40714.rotationDegrees(-state.entityPitch));
        matrices.method_22905(state.fadeScale, state.fadeScale, state.fadeScale);
        MatrixStackUtils.applyTransform(matrices, properties.projectileTransform);

        /* TODO(1.21.11 render): depth state is now pipeline-encoded; RenderSystem.enableDepthTest was removed. */

        /* World draw, so it needs the world-forms span — same rule (and same ghosting under a
         * shaderpack without it) as the actor next door. */
        boolean prevWorldForms = BBSRendering.beginWorldForms();

        try
        {
            FormUtilsClient.render(projectile.getForm(), new FormRenderingContext()
                .set(FormRenderType.ENTITY, projectile.getFormEntity(), matrices, state.field_61820, class_4608.field_21444, state.tickDelta)
                .camera(class_310.method_1551().field_1773.method_19418()));
        }
        finally
        {
            BBSRendering.endWorldForms(prevWorldForms);

            matrices.method_22909();
        }
    }

    /**
     * Carries the projectile-specific per-frame data + the live entity through the render-state model.
     *
     * TODO(1.21.11 render): carrying the live entity is a build-only bridge until the BBS form
     * pipeline is adapted to read off the render state.
     */
    public static class GunProjectileRenderState extends class_10017
    {
        public GunProjectileEntity entity;
        public float tickDelta;
        public float bodyYaw;
        public float entityPitch;
        public float fadeScale;
    }
}
