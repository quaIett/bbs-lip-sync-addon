package mchorse.bbs_mod.client.renderer;

import net.minecraft.class_1297;

/**
 * Duck interface implemented on {@link net.minecraft.class_10017}
 * (via EntityRenderStateMixin) so the morph render path can recover the live entity + tickDelta that
 * produced a render state.
 *
 * <p>The 1.21.2 render-state split froze entity data into the state object and stopped threading the
 * live {@link class_1297} through the {@code render()} call. BBS morphs must still look the entity up
 * ({@code Morph} for players, {@code SelectorOwner} for selector mobs) to find its form, so we stash
 * the entity here during {@code EntityRenderer.getAndUpdateRenderState}.
 */
public interface IRenderStateEntityHolder
{
    class_1297 bbs$getRenderedEntity();

    float bbs$getRenderedTickDelta();

    void bbs$setRenderedEntity(class_1297 entity, float tickDelta);
}
