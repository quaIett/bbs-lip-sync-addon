package mchorse.bbs_mod.client.render;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.buffers.Std140Builder;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.AddressMode;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;

import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.function.Consumer;
import net.minecraft.class_11285;
import net.minecraft.class_12137;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_9801;

/**
 * A textured screen-space quad drawn with a CUSTOM pipeline and (optionally) a custom std140 UBO,
 * into an {@link OffscreenTarget}.
 *
 * <p>This is the per-draw-uniform dispatch 1.21.5 removed: loose {@code program.getUniform(...)}
 * setters became std140 blocks, and the immediate {@code RenderLayer.draw} path binds only the
 * engine builtins — a custom block simply cannot ride it. So every effect that needs one (the
 * marching-ants selection outline, the multilink pixelate/erase preview, the subtitle blur) drives
 * this manual pass instead: engine builtins + its own UBO + its own samplers, quad at an ortho over
 * the target, result composited back through the recorded GUI blit. Generalized from
 * {@code BBSPickerRenderer.drawHighlight}, the first live instance of the pattern.
 */
public class ScreenQuadPass
{
    /** Shared ring for the small custom UBO blocks (largest current block is 32 bytes; 48 headroom). */
    private static final int UBO_SIZE = 48;

    private static class_11285 uboRing;
    private static class_11285 projectionRing;
    private static class_12137 nearestSampler;
    private static class_12137 linearSampler;

    /**
     * Write a custom std140 block into the shared ring and return the slice to hand to {@link Quad}.
     * Call BEFORE the pass runs (ring rotation fences; an open pass rejects it) — in practice, just
     * before {@link #draw}.
     */
    public static GpuBufferSlice writeUbo(Consumer<Std140Builder> writer)
    {
        CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();

        if (uboRing == null)
        {
            uboRing = new class_11285(() -> "bbs:screen_quad_ubo", GpuBuffer.USAGE_UNIFORM | GpuBuffer.USAGE_MAP_WRITE, UBO_SIZE);
        }

        uboRing.method_71121();

        GpuBuffer ubo = uboRing.method_71119();

        try (GpuBuffer.MappedView view = encoder.mapBuffer(ubo, false, true))
        {
            writer.accept(Std140Builder.intoBuffer(view.data()));
        }

        return ubo.slice(0L, UBO_SIZE);
    }

    public static class_12137 nearest()
    {
        if (nearestSampler == null)
        {
            nearestSampler = RenderSystem.getSamplerCache().method_75293(
                AddressMode.CLAMP_TO_EDGE, AddressMode.CLAMP_TO_EDGE, FilterMode.NEAREST, FilterMode.NEAREST, false);
        }

        return nearestSampler;
    }

    public static class_12137 linear()
    {
        if (linearSampler == null)
        {
            linearSampler = RenderSystem.getSamplerCache().method_75293(
                AddressMode.CLAMP_TO_EDGE, AddressMode.CLAMP_TO_EDGE, FilterMode.LINEAR, FilterMode.LINEAR, false);
        }

        return linearSampler;
    }

    /** One quad draw. Coordinates are target-local pixels (ortho over the whole target, y-down). */
    public static class Quad
    {
        public RenderPipeline pipeline;
        public GpuTextureView target;
        public int targetWidth;
        public int targetHeight;

        public float x, y, w, h;
        public float u1, v1, u2, v2;
        public int color = 0xFFFFFFFF;

        public GpuTextureView sampler0;
        public class_12137 sampler0Sampler;
        public String sampler3Name;
        public GpuTextureView sampler3;
        public class_12137 sampler3Sampler;

        public String uboName;
        public GpuBufferSlice ubo;

        /** Clear the target to transparent before drawing (first draw of the frame into it). */
        public boolean clear;

        public Quad(RenderPipeline pipeline, GpuTextureView target, int targetWidth, int targetHeight)
        {
            this.pipeline = pipeline;
            this.target = target;
            this.targetWidth = targetWidth;
            this.targetHeight = targetHeight;
        }

        public Quad rect(float x, float y, float w, float h)
        {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;

            return this;
        }

        public Quad uv(float u1, float v1, float u2, float v2)
        {
            this.u1 = u1;
            this.v1 = v1;
            this.u2 = u2;
            this.v2 = v2;

            return this;
        }

        public Quad texture(GpuTextureView view, class_12137 sampler)
        {
            this.sampler0 = view;
            this.sampler0Sampler = sampler;

            return this;
        }

        public Quad texture3(String name, GpuTextureView view, class_12137 sampler)
        {
            this.sampler3Name = name;
            this.sampler3 = view;
            this.sampler3Sampler = sampler;

            return this;
        }

        public Quad ubo(String name, GpuBufferSlice slice)
        {
            this.uboName = name;
            this.ubo = slice;

            return this;
        }

        public Quad clear()
        {
            this.clear = true;

            return this;
        }
    }

    public static boolean draw(String name, Quad quad)
    {
        if (quad.target == null || quad.targetWidth <= 0 || quad.targetHeight <= 0)
        {
            return false;
        }

        GpuDevice device = RenderSystem.getDevice();
        CommandEncoder encoder = device.createCommandEncoder();

        /* Identity model-view, neutral ColorModulator; the vertex colour carries any tint. */
        GpuBufferSlice dynamicTransforms = RenderSystem.getDynamicUniforms()
            .method_71106(new Matrix4f(), new Vector4f(1F, 1F, 1F, 1F), new Vector3f(), new Matrix4f());

        if (projectionRing == null)
        {
            projectionRing = new class_11285(() -> "bbs:screen_quad_projection", GpuBuffer.USAGE_UNIFORM | GpuBuffer.USAGE_MAP_WRITE, 64);
        }

        projectionRing.method_71121();

        GpuBuffer projection = projectionRing.method_71119();

        try (GpuBuffer.MappedView view = encoder.mapBuffer(projection, false, true))
        {
            Std140Builder.intoBuffer(view.data())
                .putMat4f(new Matrix4f().ortho(0F, quad.targetWidth, quad.targetHeight, 0F, -1000F, 1000F));
        }

        class_287 builder = class_289.method_1348().method_60827(VertexFormat.class_5596.field_27382, class_290.field_1575);

        builder.method_22912(quad.x, quad.y + quad.h, 0F).method_22913(quad.u1, quad.v2).method_39415(quad.color);
        builder.method_22912(quad.x + quad.w, quad.y + quad.h, 0F).method_22913(quad.u2, quad.v2).method_39415(quad.color);
        builder.method_22912(quad.x + quad.w, quad.y, 0F).method_22913(quad.u2, quad.v1).method_39415(quad.color);
        builder.method_22912(quad.x, quad.y, 0F).method_22913(quad.u1, quad.v1).method_39415(quad.color);

        class_9801 buffer = builder.method_60794();

        if (buffer == null)
        {
            return false;
        }

        VertexFormat format = quad.pipeline.getVertexFormat();
        GpuBuffer vertexBuffer = format.uploadImmediateVertexBuffer(buffer.method_60818());
        RenderSystem.class_5590 sequential = RenderSystem.getSequentialBuffer(buffer.method_60822().comp_752());
        GpuBuffer indexBuffer = sequential.method_68274(buffer.method_60822().comp_751());
        VertexFormat.class_5595 indexType = sequential.method_31924();

        try (RenderPass pass = encoder.createRenderPass(() -> name, quad.target,
            quad.clear ? OptionalInt.of(0x00000000) : OptionalInt.empty()))
        {
            pass.setPipeline(quad.pipeline);
            RenderSystem.bindDefaultUniforms(pass);
            pass.setUniform("Projection", projection.slice(0L, 64));
            pass.setUniform("DynamicTransforms", dynamicTransforms);

            if (quad.ubo != null)
            {
                pass.setUniform(quad.uboName, quad.ubo);
            }

            if (quad.sampler0 != null)
            {
                pass.bindTexture("Sampler0", quad.sampler0, quad.sampler0Sampler == null ? nearest() : quad.sampler0Sampler);
            }

            if (quad.sampler3 != null)
            {
                pass.bindTexture(quad.sampler3Name, quad.sampler3, quad.sampler3Sampler == null ? nearest() : quad.sampler3Sampler);
            }

            pass.setVertexBuffer(0, vertexBuffer);
            pass.setIndexBuffer(indexBuffer, indexType);
            pass.drawIndexed(0, 0, buffer.method_60822().comp_751(), 1);
        }
        finally
        {
            buffer.close();
        }

        return true;
    }
}
