package mchorse.bbs_mod.client.render.picker;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormatElement;
import mchorse.bbs_mod.client.BBSShaders;
import mchorse.bbs_mod.forms.FormRenderCapture;
import net.minecraft.class_1044;
import net.minecraft.class_1059;
import net.minecraft.class_12247;
import net.minecraft.class_1921;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_310;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_9801;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.List;
import java.util.Map;

/**
 * Picking for the vanilla-rendered forms (item, block, mob).
 *
 * <p>1.21.1 picked them by swapping the GLOBAL shader for the picker program while the vanilla
 * renderer drew — the 1.21.5 pipeline system has no global program to swap, which is why these
 * forms went unpickable in the port. What it does have is {@link FormRenderCapture}: the form's
 * vanilla-layer geometry is captured (fully transformed CPU copies), and this class replays every
 * captured buffer through the {@code picker_models} pipeline into the picking stencil via
 * {@link BBSPickerRenderer} — the same manual pass the cubic/BOBJ models already pick with.
 *
 * <p>The captured layers come in whatever vertex formats the vanilla renderers used (full entity
 * format for item quads, POSITION_TEXTURE for glint, ...), while the picker pipeline wants the
 * entity format. Each vertex is decoded by element usage with defaults for anything the source
 * lacks, so every layer replays: position is what matters, colour is overwritten by the picker
 * anyway, UV0 feeds the alpha cutout and UV2 carries the bone id a mob form wrote there.
 *
 * <p>Replayed one layer at a time, each with the texture that layer draws with: the cutout has to
 * be judged against the same picture the visible pass used, or a mob's UVs read against the block
 * atlas punch holes through its silhouette. A layer without a Sampler0 of its own falls back to
 * the block atlas, where item and block geometry points anyway.
 */
public class PickingReplay
{
    /**
     * Replay captured geometry into the picking target. The picking index must already be
     * recorded (the renderer's {@code setupTarget}); the model-view is the global one — the
     * capture bakes the form's stack into the vertices, same as the cubic picking draw.
     */
    public static void draw(Map<class_1921, List<FormRenderCapture.Captured>> captured)
    {
        if (captured == null || captured.isEmpty())
        {
            return;
        }

        for (Map.Entry<class_1921, List<FormRenderCapture.Captured>> entry : captured.entrySet())
        {
            class_12247.class_12337 texture = sampler0(entry.getKey());

            BBSPickerRenderer.setSampler0(texture.comp_5226(), texture.comp_5227());

            class_287 builder = class_289.method_1348().method_60827(VertexFormat.class_5596.field_27382, class_290.field_1580);

            for (FormRenderCapture.Captured single : entry.getValue())
            {
                emit(single, builder);
            }

            class_9801 built = builder.method_60794();

            if (built != null)
            {
                BBSPickerRenderer.draw(BBSShaders.getPickerModelsProgram(), built, RenderSystem.getModelViewMatrix());
            }
        }
    }

    /**
     * What the layer's own Sampler0 is, or the block atlas when it has none — item and block
     * geometry points there, and a layer that samples nothing of its own (glint) only duplicates
     * geometry the base layer has already written.
     */
    private static class_12247.class_12337 sampler0(class_1921 layer)
    {
        class_12247.class_12337 texture = layer.field_64013.method_75926().get("Sampler0");

        if (texture != null)
        {
            return texture;
        }

        class_1044 atlas = class_310.method_1551().method_1531().method_4619(class_1059.field_5275);

        return new class_12247.class_12337(atlas.method_71659(), atlas.method_75484());
    }

    /** Re-emit one captured buffer as QUADS, doubling the last vertex of each triangle. */
    private static void emit(FormRenderCapture.Captured captured, class_4588 consumer)
    {
        VertexFormat.class_5596 mode = captured.params().comp_752();
        int count = captured.params().comp_750();

        if (mode == VertexFormat.class_5596.field_27382)
        {
            for (int v = 0; v < count; v++)
            {
                emitVertex(captured, v, consumer);
            }
        }
        else if (mode == VertexFormat.class_5596.field_27379)
        {
            for (int v = 0; v + 2 < count; v += 3)
            {
                emitVertex(captured, v, consumer);
                emitVertex(captured, v + 1, consumer);
                emitVertex(captured, v + 2, consumer);
                emitVertex(captured, v + 2, consumer);
            }
        }
    }

    /**
     * Decode one vertex by element usage and write the FULL entity-format vertex, defaulting
     * whatever the source format lacks (unlike {@code FormRenderCapture.emitVertex}, which writes
     * only the source's elements and would underfill the picker's format).
     */
    private static void emitVertex(FormRenderCapture.Captured captured, int index, class_4588 consumer)
    {
        VertexFormat format = captured.params().comp_749();
        int base = index * format.getVertexSize();
        ByteBuffer data = captured.data().duplicate().order(ByteOrder.nativeOrder());

        float x = 0F, y = 0F, z = 0F;
        float u = 0F, v = 0F;
        int overlay = class_4608.field_21444;
        int light = 0;

        for (VertexFormatElement element : format.getElements())
        {
            int offset = base + format.getOffset(element);

            switch (element.usage())
            {
                case POSITION ->
                {
                    x = data.getFloat(offset);
                    y = data.getFloat(offset + 4);
                    z = data.getFloat(offset + 8);
                }
                case UV ->
                {
                    if (element.index() == 0)
                    {
                        u = data.getFloat(offset);
                        v = data.getFloat(offset + 4);
                    }
                    else if (element.index() == 2)
                    {
                        /* The light channel, where a mob form's parts wrote their bone ids (see
                         * MobRenderContext.partLight) — dropping it would flatten every bone back
                         * onto the form's own id. */
                        light = Short.toUnsignedInt(data.getShort(offset)) | Short.toUnsignedInt(data.getShort(offset + 2)) << 16;
                    }
                }
                default ->
                {}
            }
        }

        /* Colour is replaced by the picker's Target index in the shader; light.x carries the
         * per-vertex bone sub-index, which stays 0 for everything without a rig. */
        consumer.method_22912(x, y, z)
            .method_1336(255, 255, 255, 255)
            .method_22913(u, v)
            .method_22922(overlay)
            .method_60803(light)
            .method_22914(0F, 1F, 0F);
    }
}
