package mchorse.bbs_mod.film.replays;

import mchorse.bbs_mod.data.types.ListType;
import mchorse.bbs_mod.forms.entities.EntityState;
import mchorse.bbs_mod.forms.entities.IEntity;
import mchorse.bbs_mod.settings.values.base.BaseValue;
import mchorse.bbs_mod.settings.values.core.ValueGroup;
import mchorse.bbs_mod.utils.MathUtils;
import mchorse.bbs_mod.utils.interps.IInterp;
import mchorse.bbs_mod.utils.interps.Interpolations;
import mchorse.bbs_mod.utils.keyframes.Keyframe;
import mchorse.bbs_mod.utils.keyframes.KeyframeChannel;
import mchorse.bbs_mod.utils.keyframes.KeyframeSegment;
import mchorse.bbs_mod.utils.keyframes.factories.KeyframeFactories;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import org.joml.Vector2d;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public class ReplayKeyframes extends ValueGroup
{
    public static final String GROUP_POSITION = "position";
    public static final String GROUP_ROTATION = "rotation";
    public static final String GROUP_LEFT_STICK = "lstick";
    public static final String GROUP_RIGHT_STICK = "rstick";
    public static final String GROUP_TRIGGERS = "triggers";
    public static final String GROUP_EXTRA1 = "extra1";
    public static final String GROUP_EXTRA2 = "extra2";

    /**
     * Vanilla's per-tick gravity step (0.08 damped by 0.98). A grounded entity in
     * vanilla spends every tick trying to fall by this much and colliding with the
     * floor, which is what makes {@link net.minecraft.class_1297#method_5784} flag it as
     * on the ground. Keyframe playback teleports instead of walking, so the vertical
     * delta is zero and vanilla concludes the entity is sliding through the air -
     * killing step sounds, step game events and landing effects. Applying a frame
     * with a grounded flag subtracts this from the movement delta as a probe; the
     * exact frame position is snapped back right after, so it costs nothing
     * positionally and doesn't inflate the step cadence (move zeroes the vertical
     * component before accumulating the stride distance, unless the block is
     * climbable).
     */
    public static final double GRAVITY_PROBE = 0.0784D;

    /**
     * Hotbar slots the replay records, one channel each. The item in the entity's main hand
     * isn't stored anywhere: it's the slot {@link #selectedSlot} points at, which is what
     * keeps a hotbar cell from having two owners.
     */
    public static final int HOTBAR_SIZE = 9;

    /** Channel id of the hotbar slot at given index. */
    public static String hotbarChannelId(int slot)
    {
        return "item_slot_" + slot;
    }

    public static final List<String> CURATED_CHANNELS = buildCuratedChannels();

    /**
     * The states sit together in one run rather than scattered through the list, so the timeline
     * groups them the way {@link EntityState} does - and so adding a state doesn't mean
     * remembering to name it here as well.
     */
    private static List<String> buildCuratedChannels()
    {
        List<String> channels = new ArrayList<>(Arrays.asList("x", "y", "z", "pitch", "yaw", "headYaw", "bodyYaw"));

        for (EntityState state : EntityState.values())
        {
            channels.add(state.id);
        }

        channels.addAll(Arrays.asList("item_slot_0", "item_slot_1", "item_slot_2", "item_slot_3", "item_slot_4", "item_slot_5", "item_slot_6", "item_slot_7", "item_slot_8", "item_off_hand", "item_head", "item_chest", "item_legs", "item_feet", "selected_slot", "stick_lx", "stick_ly", "stick_rx", "stick_ry", "trigger_l", "trigger_r", "extra1_x", "extra1_y", "extra2_x", "extra2_y", "damage", "vX", "vY", "vZ"));

        return channels;
    }

    public final KeyframeChannel<Double> x = new KeyframeChannel<>("x", KeyframeFactories.DOUBLE);
    public final KeyframeChannel<Double> y = new KeyframeChannel<>("y", KeyframeFactories.DOUBLE);
    public final KeyframeChannel<Double> z = new KeyframeChannel<>("z", KeyframeFactories.DOUBLE);

    public final KeyframeChannel<Double> vX = new KeyframeChannel<>("vX", KeyframeFactories.DOUBLE);
    public final KeyframeChannel<Double> vY = new KeyframeChannel<>("vY", KeyframeFactories.DOUBLE);
    public final KeyframeChannel<Double> vZ = new KeyframeChannel<>("vZ", KeyframeFactories.DOUBLE);

    public final KeyframeChannel<Double> yaw = new KeyframeChannel<>("yaw", KeyframeFactories.DOUBLE);
    public final KeyframeChannel<Double> pitch = new KeyframeChannel<>("pitch", KeyframeFactories.DOUBLE);
    public final KeyframeChannel<Double> headYaw = new KeyframeChannel<>("headYaw", KeyframeFactories.DOUBLE);
    public final KeyframeChannel<Double> bodyYaw = new KeyframeChannel<>("bodyYaw", KeyframeFactories.DOUBLE);

    /**
     * One channel per {@link EntityState}, keyed by the state and named after it. The fields
     * below are the same channels under the names the rest of the mod already asks for.
     */
    public final Map<EntityState, KeyframeChannel<Double>> states = new EnumMap<>(EntityState.class);

    public final KeyframeChannel<Double> sneaking = this.state(EntityState.SNEAKING);
    public final KeyframeChannel<Double> sprinting = this.state(EntityState.SPRINTING);
    public final KeyframeChannel<Double> grounded = this.state(EntityState.GROUNDED);
    public final KeyframeChannel<Double> fall = new KeyframeChannel<>("fall", KeyframeFactories.DOUBLE);
    public final KeyframeChannel<Double> damage = new KeyframeChannel<>("damage", KeyframeFactories.DOUBLE);

    /**
     * Two states vanilla counts up a tick at a time rather than switching: how far the body has
     * leant into a swim, and how long a glide or a riptide has been going (which ramps the
     * elytra's dive). A timeline is random access - scrub into the middle of a swim and there
     * were no ticks to count - so they are written down like everything else instead of derived.
     */
    public final KeyframeChannel<Double> leaning = new KeyframeChannel<>("leaning", KeyframeFactories.DOUBLE);
    public final KeyframeChannel<Double> roll = new KeyframeChannel<>("roll", KeyframeFactories.DOUBLE);

    public final KeyframeChannel<Double> stickLeftX = new KeyframeChannel<>("stick_lx", KeyframeFactories.DOUBLE);
    public final KeyframeChannel<Double> stickLeftY = new KeyframeChannel<>("stick_ly", KeyframeFactories.DOUBLE);
    public final KeyframeChannel<Double> stickRightX = new KeyframeChannel<>("stick_rx", KeyframeFactories.DOUBLE);
    public final KeyframeChannel<Double> stickRightY = new KeyframeChannel<>("stick_ry", KeyframeFactories.DOUBLE);
    public final KeyframeChannel<Double> triggerLeft = new KeyframeChannel<>("trigger_l", KeyframeFactories.DOUBLE);
    public final KeyframeChannel<Double> triggerRight = new KeyframeChannel<>("trigger_r", KeyframeFactories.DOUBLE);

    /* Miscellaneous animatable keyframe channels */
    public final KeyframeChannel<Double> extra1X = new KeyframeChannel<>("extra1_x", KeyframeFactories.DOUBLE);
    public final KeyframeChannel<Double> extra1Y = new KeyframeChannel<>("extra1_y", KeyframeFactories.DOUBLE);
    public final KeyframeChannel<Double> extra2X = new KeyframeChannel<>("extra2_x", KeyframeFactories.DOUBLE);
    public final KeyframeChannel<Double> extra2Y = new KeyframeChannel<>("extra2_y", KeyframeFactories.DOUBLE);

    public final List<KeyframeChannel<class_1799>> hotbar = new ArrayList<>();

    public final KeyframeChannel<class_1799> offHand = new KeyframeChannel<>("item_off_hand", KeyframeFactories.ITEM_STACK);
    public final KeyframeChannel<class_1799> armorHead = new KeyframeChannel<>("item_head", KeyframeFactories.ITEM_STACK);
    public final KeyframeChannel<class_1799> armorChest = new KeyframeChannel<>("item_chest", KeyframeFactories.ITEM_STACK);
    public final KeyframeChannel<class_1799> armorLegs = new KeyframeChannel<>("item_legs", KeyframeFactories.ITEM_STACK);
    public final KeyframeChannel<class_1799> armorFeet = new KeyframeChannel<>("item_feet", KeyframeFactories.ITEM_STACK);
    public final KeyframeChannel<Integer> selectedSlot = new KeyframeChannel<>("selected_slot", KeyframeFactories.INTEGER);

    public ReplayKeyframes(String id)
    {
        super(id);

        this.add(this.x);
        this.add(this.y);
        this.add(this.z);
        this.add(this.vX);
        this.add(this.vY);
        this.add(this.vZ);
        this.add(this.yaw);
        this.add(this.pitch);
        this.add(this.headYaw);
        this.add(this.bodyYaw);

        for (EntityState state : EntityState.values())
        {
            this.add(this.state(state));
        }

        this.add(this.fall);
        this.add(this.damage);
        this.add(this.leaning);
        this.add(this.roll);
        this.add(this.stickLeftX);
        this.add(this.stickLeftY);
        this.add(this.stickRightX);
        this.add(this.stickRightY);
        this.add(this.triggerLeft);
        this.add(this.triggerRight);
        this.add(this.extra1X);
        this.add(this.extra1Y);
        this.add(this.extra2X);
        this.add(this.extra2Y);

        for (int i = 0; i < HOTBAR_SIZE; i++)
        {
            KeyframeChannel<class_1799> slot = new KeyframeChannel<>(hotbarChannelId(i), KeyframeFactories.ITEM_STACK);

            this.hotbar.add(slot);
            this.add(slot);
        }

        this.add(this.offHand);
        this.add(this.armorHead);
        this.add(this.armorChest);
        this.add(this.armorLegs);
        this.add(this.armorFeet);
        this.add(this.selectedSlot);
    }

    /** The channel a state is recorded into, created on first ask. */
    public KeyframeChannel<Double> state(EntityState state)
    {
        return this.states.computeIfAbsent(state, (s) -> new KeyframeChannel<>(s.id, KeyframeFactories.DOUBLE));
    }

    public List<KeyframeChannel<?>> getChannels()
    {
        ArrayList<KeyframeChannel<?>> channels = new ArrayList<>();

        for (BaseValue baseValue : this.getAll())
        {
            if (baseValue instanceof KeyframeChannel<?> channel)
            {
                channels.add(channel);
            }
        }

        return channels;
    }

    /** Equipment the replay dresses an entity in, beside the hotbar. */
    public static final class_1304[] DRESS_SLOTS = {class_1304.field_6171, class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166};

    public KeyframeChannel<class_1799> getEquipmentChannel(class_1304 slot)
    {
        switch (slot)
        {
            case field_6171: return this.offHand;
            case field_6169: return this.armorHead;
            case field_6174: return this.armorChest;
            case field_6172: return this.armorLegs;
            case field_6166: return this.armorFeet;
        }

        return null;
    }

    /**
     * Dress the entity for given tick: nine hotbar cells, the armour and the off hand.
     *
     * A channel with no keys says nothing, so its cell is left alone rather than emptied. That
     * matters for films migrated from the old format, where only the cells the hand passed
     * through were ever written down: the rest stay open, and whatever the world puts there
     * during playback - an item picked up off the ground, say - stays visible, the way those
     * films used to show it.
     *
     * The main hand is only handed over to those who keep it in a slot of its own - an actor,
     * a mob, a preview stub. Where it's a view of the hotbar it has already been laid out, and
     * writing it again would put the frame's item into whatever cell is selected at that
     * instant - which, mid-switch, is still the previous one.
     */
    public void applyEquipment(float tick, IEntity entity)
    {
        for (int i = 0; i < HOTBAR_SIZE; i++)
        {
            KeyframeChannel<class_1799> slot = this.hotbar.get(i);

            if (!slot.isEmpty())
            {
                entity.setHotbarStack(i, slot.interpolate(tick, class_1799.field_8037));
            }
        }

        if (!entity.isMainHandInHotbar())
        {
            entity.setEquipmentStack(class_1304.field_6173, this.getMainHandStack(tick));
        }

        for (class_1304 slot : DRESS_SLOTS)
        {
            KeyframeChannel<class_1799> channel = this.getEquipmentChannel(slot);

            if (!channel.isEmpty())
            {
                entity.setEquipmentStack(slot, channel.interpolate(tick, class_1799.field_8037));
            }
        }
    }

    /** Whether the replay has anything to say about given hotbar cell. */
    public boolean drivesHotbarSlot(int slot)
    {
        return !this.hotbar.get(slot).isEmpty();
    }

    /**
     * The frame's dress packed for the wire: nine hotbar cells, then {@link #DRESS_SLOTS}.
     * Used to hand a film's outfit to a player who isn't playing the film.
     */
    public ListType packEquipment(float tick)
    {
        ListType list = new ListType();

        for (int i = 0; i < HOTBAR_SIZE; i++)
        {
            list.add(KeyframeFactories.ITEM_STACK.toData(this.hotbar.get(i).interpolate(tick, class_1799.field_8037)));
        }

        for (class_1304 slot : DRESS_SLOTS)
        {
            list.add(KeyframeFactories.ITEM_STACK.toData(this.getEquipmentChannel(slot).interpolate(tick, class_1799.field_8037)));
        }

        return list;
    }

    public static void applyPackedEquipment(IEntity entity, ListType list)
    {
        for (int i = 0; i < HOTBAR_SIZE && i < list.size(); i++)
        {
            entity.setHotbarStack(i, KeyframeFactories.ITEM_STACK.fromData(list.get(i)));
        }

        for (int i = 0; i < DRESS_SLOTS.length; i++)
        {
            int index = HOTBAR_SIZE + i;

            if (index < list.size())
            {
                entity.setEquipmentStack(DRESS_SLOTS[i], KeyframeFactories.ITEM_STACK.fromData(list.get(index)));
            }
        }
    }

    /**
     * Hotbar slot the entity holds at given tick, clamped into the hotbar - the channel is
     * free-form once a user edits it.
     */
    public int getSelectedSlot(float tick)
    {
        return MathUtils.clamp(this.selectedSlot.interpolate(tick), 0, HOTBAR_SIZE - 1);
    }

    /**
     * What's in the main hand at given tick. Derived, not stored: the hand is whichever hotbar
     * slot is selected.
     */
    public class_1799 getMainHandStack(float tick)
    {
        return this.hotbar.get(this.getSelectedSlot(tick)).interpolate(tick, class_1799.field_8037);
    }

    /**
     * Recording writes an item key every tick, but a hotbar barely ever changes - so nearly
     * all of those keys repeat the one before them, and item interpolation is stepped, which
     * makes them free to drop. Called once a recording is done, this leaves one key per actual
     * change and nothing else.
     */
    public void compressItemChannels()
    {
        for (KeyframeChannel<class_1799> slot : this.hotbar)
        {
            slot.dropRepeats();
        }

        for (class_1304 slot : DRESS_SLOTS)
        {
            this.getEquipmentChannel(slot).dropRepeats();
        }
    }

    public void shift(float tick)
    {
        for (KeyframeChannel<?> channel : this.getChannels())
        {
            for (Keyframe<?> keyframe : channel.getKeyframes())
            {
                keyframe.setTick(keyframe.getTick() + tick);
            }
        }
    }

    public void copyOver(ReplayKeyframes keyframes, int tick)
    {
        for (KeyframeChannel<?> channel : this.getChannels())
        {
            BaseValue keyframe = keyframes.get(channel.getId());

            if (keyframe instanceof KeyframeChannel<?> keyframeChannel)
            {
                channel.copyOver(keyframeChannel, tick);
            }
        }
    }

    public void record(int tick, IEntity entity, List<String> groups)
    {
        boolean empty = groups == null || groups.isEmpty();
        boolean position = empty || groups.contains(GROUP_POSITION);
        boolean rotation = empty || groups.contains(GROUP_ROTATION);
        boolean leftStick = empty || groups.contains(GROUP_LEFT_STICK);
        boolean rightStick = empty || groups.contains(GROUP_RIGHT_STICK);
        boolean triggers = empty || groups.contains(GROUP_TRIGGERS);
        boolean extra1 = empty || groups.contains(GROUP_EXTRA1);
        boolean extra2 = empty || groups.contains(GROUP_EXTRA2);

        /* Position and rotation */
        if (position)
        {
            this.x.insert(tick, entity.getX());
            this.y.insert(tick, entity.getY());
            this.z.insert(tick, entity.getZ());

            this.vX.insert(tick, entity.getVelocity().field_1352);
            this.vY.insert(tick, entity.getVelocity().field_1351);
            this.vZ.insert(tick, entity.getVelocity().field_1350);

            this.fall.insert(tick, (double) entity.getFallDistance());
        }

        for (EntityState state : EntityState.values())
        {
            this.state(state).insert(tick, state.get(entity) ? 1D : 0D);
        }

        this.damage.insert(tick, (double) entity.getHurtTimer());
        this.leaning.insert(tick, (double) entity.getLeaningPitch(1F));
        this.roll.insert(tick, (double) entity.getRoll());

        if (rotation)
        {
            this.yaw.insert(tick, (double) entity.getYaw());
            this.pitch.insert(tick, (double) entity.getPitch());
            this.headYaw.insert(tick, (double) entity.getHeadYaw());
            this.bodyYaw.insert(tick, (double) entity.getBodyYaw());
        }

        float[] sticks = entity.getExtraVariables();

        if (leftStick)
        {
            this.stickLeftX.insert(tick, (double) sticks[0]);
            this.stickLeftY.insert(tick, (double) sticks[1]);
        }

        if (rightStick)
        {
            this.stickRightX.insert(tick, (double) sticks[2]);
            this.stickRightY.insert(tick, (double) sticks[3]);
        }

        if (triggers)
        {
            this.triggerLeft.insert(tick, (double) sticks[4]);
            this.triggerRight.insert(tick, (double) sticks[5]);
        }

        if (extra1)
        {
            this.extra1X.insert(tick, (double) sticks[6]);
            this.extra1Y.insert(tick, (double) sticks[7]);
        }

        if (extra2)
        {
            this.extra2X.insert(tick, (double) sticks[8]);
            this.extra2Y.insert(tick, (double) sticks[9]);
        }

        if (empty)
        {
            for (int i = 0; i < HOTBAR_SIZE; i++)
            {
                this.hotbar.get(i).insert(tick, entity.getHotbarStack(i).method_7972());
            }

            this.offHand.insert(tick, entity.getEquipmentStack(class_1304.field_6171).method_7972());
            this.armorHead.insert(tick, entity.getEquipmentStack(class_1304.field_6169).method_7972());
            this.armorChest.insert(tick, entity.getEquipmentStack(class_1304.field_6174).method_7972());
            this.armorLegs.insert(tick, entity.getEquipmentStack(class_1304.field_6172).method_7972());
            this.armorFeet.insert(tick, entity.getEquipmentStack(class_1304.field_6166).method_7972());
            this.selectedSlot.insert(tick, entity.getSelectedSlot());
        }
    }

    public void apply(int tick, IEntity entity)
    {
        this.apply(tick, entity, null);
    }

    public void apply(float tick, IEntity entity)
    {
        this.apply(tick, entity, null);
    }

    /**
     * Apply a frame at given tick on the given entity.
     */
    public void apply(int tick, IEntity entity, List<String> groups)
    {
        this.apply((float) tick, entity, groups);
    }

    public void apply(float tick, IEntity entity, List<String> groups)
    {
        boolean empty = groups == null || groups.isEmpty();
        boolean position = empty || !groups.contains(GROUP_POSITION);
        boolean rotation = empty || !groups.contains(GROUP_ROTATION);
        boolean leftStick = empty || !groups.contains(GROUP_LEFT_STICK);
        boolean rightStick = empty || !groups.contains(GROUP_RIGHT_STICK);
        boolean triggers = empty || !groups.contains(GROUP_TRIGGERS);
        boolean extra1 = empty || !groups.contains(GROUP_EXTRA1);
        boolean extra2 = empty || !groups.contains(GROUP_EXTRA2);

        if (position)
        {
            entity.setVelocity(this.vX.interpolate(tick).floatValue(), this.vY.interpolate(tick).floatValue(), this.vZ.interpolate(tick).floatValue());
            entity.setFallDistance(this.fall.interpolate(tick).floatValue());

            KeyframeSegment<Double> x = this.x.findSegment(tick);
            Vector2d xx = this.getPrev(x, this.x.interpolate(tick - 1), tick);
            KeyframeSegment<Double> y = this.y.findSegment(tick);
            Vector2d yy = this.getPrev(y, this.y.interpolate(tick - 1), tick);
            KeyframeSegment<Double> z = this.z.findSegment(tick);
            Vector2d zz = this.getPrev(z, this.z.interpolate(tick - 1), tick);

            entity.setPosition(xx.x, yy.x, zz.x);
            entity.setPrevX(xx.y);
            entity.setPrevY(yy.y);
            entity.setPrevZ(zz.y);
        }

        if (rotation)
        {
            KeyframeSegment<Double> yaw = this.yaw.findSegment(tick);
            Vector2d yyaw = this.getPrev(yaw, this.yaw.interpolate(tick - 1), tick);
            KeyframeSegment<Double> pitch = this.pitch.findSegment(tick);
            Vector2d ppitch = this.getPrev(pitch, this.pitch.interpolate(tick - 1), tick);
            KeyframeSegment<Double> headYaw = this.headYaw.findSegment(tick);
            Vector2d hheadYaw = this.getPrev(headYaw, this.headYaw.interpolate(tick - 1), tick);
            KeyframeSegment<Double> bodyYaw = this.bodyYaw.findSegment(tick);
            Vector2d bbodyYaw = this.getPrev(bodyYaw, this.bodyYaw.interpolate(tick - 1), tick);

            entity.setYaw((float) yyaw.x);
            entity.setPitch((float) ppitch.x);
            entity.setHeadYaw((float) hheadYaw.x);
            entity.setBodyYaw((float) bbodyYaw.x);

            entity.setPrevYaw((float) yyaw.y);
            entity.setPrevPitch((float) ppitch.y);
            entity.setPrevHeadYaw((float) hheadYaw.y);
            entity.setPrevBodyYaw((float) bbodyYaw.y);
        }

        /* Motion and fall distance */
        for (EntityState state : EntityState.values())
        {
            state.set(entity, EntityState.isOn(this.state(state).interpolate(tick)));
        }

        entity.setHurtTimer(this.damage.interpolate(tick).intValue());
        entity.setLeaningPitch(this.leaning.interpolate(tick).floatValue());
        entity.setRoll(this.roll.interpolate(tick).intValue());

        float[] sticks = entity.getExtraVariables();

        if (leftStick)
        {
            sticks[0] = this.stickLeftX.interpolate(tick).floatValue();
            sticks[1] = this.stickLeftY.interpolate(tick).floatValue();
        }

        if (rightStick)
        {
            sticks[2] = this.stickRightX.interpolate(tick).floatValue();
            sticks[3] = this.stickRightY.interpolate(tick).floatValue();
        }

        if (triggers)
        {
            sticks[4] = this.triggerLeft.interpolate(tick).floatValue();
            sticks[5] = this.triggerRight.interpolate(tick).floatValue();
        }

        if (extra1)
        {
            sticks[6] = this.extra1X.interpolate(tick).floatValue();
            sticks[7] = this.extra1Y.interpolate(tick).floatValue();
        }

        if (extra2)
        {
            sticks[8] = this.extra2X.interpolate(tick).floatValue();
            sticks[9] = this.extra2Y.interpolate(tick).floatValue();
        }

        this.applyEquipment(tick, entity);
    }

    /**
     * Force teleportation for the previous keyframe being constant
     */
    private Vector2d getPrev(KeyframeSegment<Double> frame, double prev, float tick)
    {
        if (frame == null)
        {
            return new Vector2d(prev, prev);
        }

        IInterp interp = frame.a.getInterpolation().getInterp();
        Double interpolated = frame.createInterpolated();

        /*  */
        if (interp == Interpolations.CONST || interp == Interpolations.STEP)
        {
            if (interpolated != null)
            {
                prev = interpolated;
            }

            return new Vector2d(prev, prev);
        }

        if (frame.preA != frame.a && frame.a.getTick() == tick - frame.timeOffset && (frame.preA.getInterpolation().getInterp() == Interpolations.CONST || frame.preA.getInterpolation().getInterp() == Interpolations.STEP))
        {
            if (interpolated != null)
            {
                prev = interpolated;
            }

            return new Vector2d(prev, prev);
        }

        return new Vector2d(interpolated == null ? prev : interpolated, prev);
    }
}
