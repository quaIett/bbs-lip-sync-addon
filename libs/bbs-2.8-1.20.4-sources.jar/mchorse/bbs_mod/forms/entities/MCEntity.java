package mchorse.bbs_mod.forms.entities;

import mchorse.bbs_mod.cubic.jem.CemVariables;
import mchorse.bbs_mod.forms.forms.Form;
import mchorse.bbs_mod.mixin.EntityInvoker;
import mchorse.bbs_mod.mixin.LivingEntityRollAccessor;
import mchorse.bbs_mod.morphing.Morph;
import mchorse.bbs_mod.utils.AABB;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1306;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1321;
import net.minecraft.class_1420;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_4019;
import net.minecraft.class_4050;
import net.minecraft.class_8080;

public class MCEntity implements IEntity
{
    private class_1297 mcEntity;

    private float prevPrevBodyYaw;
    private class_243 lastVelocity = class_243.field_1353;

    private float[] extraVariables = new float[10];
    private float[] prevExtraVariables = new float[10];

    public MCEntity(class_1297 mcEntity)
    {
        this.mcEntity = mcEntity;
    }

    public class_1297 getMcEntity()
    {
        return this.mcEntity;
    }

    @Override
    public void setWorld(class_1937 world)
    {}

    @Override
    public class_1937 getWorld()
    {
        return this.mcEntity.method_37908();
    }

    @Override
    public Form getForm()
    {
        Morph morph = Morph.getMorph(this.mcEntity);

        return morph == null ? null : morph.getForm();
    }

    @Override
    public void setForm(Form form)
    {
        Morph morph = Morph.getMorph(this.mcEntity);

        if (morph != null)
        {
            morph.setForm(form);
        }
    }

    @Override
    public class_1799 getEquipmentStack(class_1304 slot)
    {
        if (this.mcEntity instanceof class_1309 living)
        {
            return living.method_6118(slot);
        }

        return class_1799.field_8037;
    }

    /**
     * The stack lands on a live entity, which vanilla is free to mutate, and it usually comes
     * out of a keyframe - so it's copied, and left alone when the cell already holds it. That
     * second part matters on players: the film writes every tick, and an unchanged write would
     * still count as an inventory change for the client sync.
     */
    @Override
    public void setEquipmentStack(class_1304 slot, class_1799 stack)
    {
        if (this.mcEntity instanceof class_1309 living && !class_1799.method_7973(living.method_6118(slot), stack))
        {
            living.method_5673(slot, stack == null ? class_1799.field_8037 : stack.method_7972());
        }
    }

    @Override
    public class_1799 getHotbarStack(int slot)
    {
        if (this.mcEntity instanceof class_1657 player)
        {
            return player.method_31548().method_5438(slot);
        }

        /* Mobs and actors have no hotbar, and their selected slot is 0 - so their main hand
         * is what slot 0 holds. */
        return slot == 0 ? this.getEquipmentStack(class_1304.field_6173) : class_1799.field_8037;
    }

    @Override
    public void setHotbarStack(int slot, class_1799 stack)
    {
        if (stack == null)
        {
            stack = class_1799.field_8037;
        }

        if (this.mcEntity instanceof class_1657 player)
        {
            if (!class_1799.method_7973(player.method_31548().method_5438(slot), stack))
            {
                player.method_31548().method_5447(slot, stack.method_7972());
            }
        }
        else if (slot == 0)
        {
            this.setEquipmentStack(class_1304.field_6173, stack);
        }
    }

    @Override
    public boolean isMainHandInHotbar()
    {
        return this.mcEntity instanceof class_1657;
    }

    @Override
    public int getSelectedSlot()
    {
        if (this.mcEntity instanceof class_1657 player)
        {
            return player.method_31548().field_7545;
        }

        return 0;
    }

    @Override
    public boolean isSneaking()
    {
        return this.mcEntity.method_5715();
    }

    @Override
    public void setSneaking(boolean sneaking)
    {
        this.mcEntity.method_5660(sneaking);
    }

    @Override
    public boolean isSprinting()
    {
        return this.mcEntity.method_5624();
    }

    @Override
    public void setSprinting(boolean sprinting)
    {
        this.mcEntity.method_5728(sprinting);
    }

    @Override
    public boolean isOnGround()
    {
        return this.mcEntity.method_24828();
    }

    @Override
    public void setOnGround(boolean ground)
    {
        this.mcEntity.method_24830(ground);
    }

    @Override
    public boolean isSwimming()
    {
        return this.mcEntity.method_5681();
    }

    @Override
    public void setSwimming(boolean swimming)
    {
        this.mcEntity.method_5796(swimming);
    }

    @Override
    public boolean isRiding()
    {
        return this.mcEntity.method_5765();
    }

    /**
     * Riding isn't a flag one can set - it's whether something is being ridden - and a replay
     * doesn't mount anyone, so there is nothing to write onto a live entity here.
     */
    @Override
    public void setRiding(boolean riding)
    {}

    @Override
    public boolean isFlying()
    {
        return this.mcEntity instanceof class_1657 player && player.method_31549().field_7479;
    }

    /**
     * Deliberately nothing: creative flight is a permission on a real player, and a film has no
     * business granting or taking it. The recorded state only picks an animation.
     */
    @Override
    public void setFlying(boolean flying)
    {}

    @Override
    public void swingArm()
    {
        if (this.mcEntity instanceof class_1309 living)
        {
            living.method_6104(class_1268.field_5808);
        }
    }

    @Override
    public float getHandSwingProgress(float tickDelta)
    {
        if (this.mcEntity instanceof class_1309 living)
        {
            return living.method_6055(tickDelta);
        }

        return 0F;
    }

    /** Lazily made: an entity that never renders a CEM model never allocates one. */
    private CemVariables cemVariables;

    /**
     * The CEM variables of this entity, made on first use — every CEM model rendered on it shares them,
     * which is how a pack's cape follows its body. See {@link CemVariables}.
     */
    @Override
    public CemVariables getCemVariables()
    {
        if (this.cemVariables == null)
        {
            this.cemVariables = new CemVariables();
        }

        return this.cemVariables;
    }

    @Override
    public int getAge()
    {
        return this.mcEntity.field_6012;
    }

    @Override
    public void setAge(int ticks)
    {
        this.mcEntity.field_6012 = ticks;
    }

    @Override
    public float getFallDistance()
    {
        return this.mcEntity.field_6017;
    }

    @Override
    public void setFallDistance(float fallDistance)
    {
        this.mcEntity.field_6017 = fallDistance;
    }

    @Override
    public int getHurtTimer()
    {
        if (this.mcEntity instanceof class_1309 living)
        {
            return living.field_6235;
        }

        return 0;
    }

    @Override
    public void setHurtTimer(int hurtTimer)
    {
        if (this.mcEntity instanceof class_1309 living)
        {
            living.field_6235 = hurtTimer;
        }
    }

    @Override
    public int getId()
    {
        return this.mcEntity.method_5628();
    }

    @Override
    public int getDeathTime()
    {
        return this.mcEntity instanceof class_1309 living ? living.field_6213 : 0;
    }

    @Override
    public boolean isRidden()
    {
        return this.mcEntity.method_5782();
    }

    @Override
    public boolean isChild()
    {
        return this.mcEntity instanceof class_1309 living && living.method_6109();
    }

    @Override
    public float getHealth()
    {
        return this.mcEntity instanceof class_1309 living ? living.method_6032() : IEntity.FULL_HEALTH;
    }

    @Override
    public float getMaxHealth()
    {
        /* An attribute can read zero on an entity whose attributes have not arrived from the server yet,
         * and a pack divides by this one. */
        float max = this.mcEntity instanceof class_1309 living ? living.method_6063() : 0F;

        return max > 0F ? max : IEntity.FULL_HEALTH;
    }

    @Override
    public boolean isBurning()
    {
        return this.mcEntity.method_5809();
    }

    @Override
    public boolean isInLava()
    {
        return this.mcEntity.method_5771();
    }

    @Override
    public boolean isClimbing()
    {
        return this.mcEntity instanceof class_1309 living && living.method_6101();
    }

    @Override
    public boolean isCrawling()
    {
        return this.mcEntity.method_20448();
    }

    /**
     * Vanilla has no one word for it: a pet holds the pose through {@link class_1321}, while a fox
     * and a bat each keep their own flag, and those three are the whole of it in 1.20.4.
     */
    @Override
    public boolean isSitting()
    {
        if (this.mcEntity instanceof class_1321 tameable)
        {
            return tameable.method_6172();
        }
        else if (this.mcEntity instanceof class_4019 fox)
        {
            return fox.method_18272();
        }

        return this.mcEntity instanceof class_1420 bat && bat.method_6450();
    }

    @Override
    public boolean isTamed()
    {
        return this.mcEntity instanceof class_1321 tameable && tameable.method_6181();
    }

    @Override
    public boolean isAggressive()
    {
        return this.mcEntity instanceof class_1308 mob && mob.method_6510();
    }

    @Override
    public boolean isRightHanded()
    {
        return !(this.mcEntity instanceof class_1309 living) || living.method_6068() == class_1306.field_6183;
    }

    @Override
    public boolean isUsingItem()
    {
        return this.mcEntity instanceof class_1309 living && living.method_6115();
    }

    @Override
    public boolean isBlocking()
    {
        return this.mcEntity instanceof class_1309 living && living.method_6039();
    }

    @Override
    public boolean isSwinging()
    {
        return this.mcEntity instanceof class_1309 living && living.field_6252;
    }

    @Override
    public boolean isSwingingOffHand()
    {
        return this.mcEntity instanceof class_1309 living && living.field_6266 == class_1268.field_5810;
    }

    @Override
    public float getForwardSpeed()
    {
        return this.mcEntity instanceof class_1309 living ? living.field_6250 : 0F;
    }

    @Override
    public float getSidewaysSpeed()
    {
        return this.mcEntity instanceof class_1309 living ? living.field_6212 : 0F;
    }

    @Override
    public double getX()
    {
        return this.mcEntity.method_23317();
    }

    @Override
    public double getPrevX()
    {
        return this.mcEntity.field_6014;
    }

    @Override
    public void setPrevX(double x)
    {
        this.mcEntity.field_6014 = x;
    }

    @Override
    public double getY()
    {
        return this.mcEntity.method_23318();
    }

    @Override
    public double getPrevY()
    {
        return this.mcEntity.field_6036;
    }

    @Override
    public void setPrevY(double y)
    {
        this.mcEntity.field_6036 = y;
    }

    @Override
    public double getZ()
    {
        return this.mcEntity.method_23321();
    }

    @Override
    public double getPrevZ()
    {
        return this.mcEntity.field_5969;
    }

    @Override
    public void setPrevZ(double z)
    {
        this.mcEntity.field_5969 = z;
    }

    @Override
    public void setPosition(double x, double y, double z)
    {
        this.mcEntity.method_5814(x, y, z);
    }

    @Override
    public double getEyeHeight()
    {
        return this.mcEntity.method_18381(this.mcEntity.method_18376());
    }

    @Override
    public class_243 getVelocity()
    {
        return this.mcEntity.method_18798();
    }

    @Override
    public void setVelocity(float x, float y, float z)
    {
        this.mcEntity.method_18800(x, y, z);
    }

    @Override
    public float getYaw()
    {
        return this.mcEntity.method_36454();
    }

    @Override
    public float getPrevYaw()
    {
        return this.mcEntity.field_5982;
    }

    @Override
    public void setYaw(float yaw)
    {
        this.mcEntity.method_36456(yaw);
    }

    @Override
    public void setPrevYaw(float prevYaw)
    {
        this.mcEntity.field_5982 = prevYaw;
    }

    @Override
    public float getHeadYaw()
    {
        if (this.mcEntity instanceof class_1309 living)
        {
            return living.method_5791();
        }

        return this.mcEntity.method_36454();
    }

    @Override
    public float getPrevHeadYaw()
    {
        if (this.mcEntity instanceof class_1309 living)
        {
            return living.field_6259;
        }

        return this.mcEntity.field_5982;
    }

    @Override
    public void setHeadYaw(float headYaw)
    {
        this.mcEntity.method_5847(headYaw);
    }

    @Override
    public void setPrevHeadYaw(float prevHeadYaw)
    {
        if (this.mcEntity instanceof class_1309 living)
        {
            living.field_6259 = prevHeadYaw;
        }
    }

    @Override
    public float getPitch()
    {
        return this.mcEntity.method_36455();
    }

    @Override
    public float getPrevPitch()
    {
        return this.mcEntity.field_6004;
    }

    @Override
    public void setPitch(float pitch)
    {
        this.mcEntity.method_36457(pitch);
    }

    @Override
    public void setPrevPitch(float prevPitch)
    {
        this.mcEntity.field_6004 = prevPitch;
    }

    @Override
    public float getBodyYaw()
    {
        if (this.mcEntity instanceof class_1309 living)
        {
            return living.field_6283;
        }

        return this.getHeadYaw();
    }

    @Override
    public float getPrevBodyYaw()
    {
        if (this.mcEntity instanceof class_1309 living)
        {
            return living.field_6220;
        }

        return this.getPrevHeadYaw();
    }

    @Override
    public float getPrevPrevBodyYaw()
    {
        return this.prevPrevBodyYaw;
    }

    @Override
    public void setBodyYaw(float bodyYaw)
    {
        this.mcEntity.method_5636(bodyYaw);
    }

    @Override
    public void setPrevBodyYaw(float prevBodyYaw)
    {
        if (this.mcEntity instanceof class_1309 living)
        {
            living.field_6220 = prevBodyYaw;
        }
    }

    @Override
    public void setPrevPrevBodyYaw(float prevPrevBodyYaw)
    {
        this.prevPrevBodyYaw = prevPrevBodyYaw;
    }

    @Override
    public float[] getExtraVariables()
    {
        return this.extraVariables;
    }

    @Override
    public float[] getPrevExtraVariables()
    {
        return this.prevExtraVariables;
    }

    @Override
    public AABB getPickingHitbox()
    {
        float w = this.mcEntity.method_17681();
        float h = this.mcEntity.method_17682();

        return new AABB(
            this.getX() - w / 2, this.getY(), this.getZ() - w / 2,
            w, h, w
        );
    }

    @Override
    public void update()
    {
        this.lastVelocity = this.mcEntity.method_18798();
        this.prevPrevBodyYaw = this.getPrevBodyYaw();

        for (int i = 0; i < this.extraVariables.length; i++)
        {
            this.prevExtraVariables[i] = this.extraVariables[i];
        }
    }

    @Override
    public class_8080 getLimbAnimator()
    {
        if (this.mcEntity instanceof class_1309 living)
        {
            return living.field_42108;
        }

        return null;
    }

    @Override
    public float getLimbPos(float tickDelta)
    {
        if (this.mcEntity instanceof class_1309 living)
        {
            return living.field_42108.method_48572(tickDelta);
        }

        return 0F;
    }

    @Override
    public float getLimbSpeed(float tickDelta)
    {
        if (this.mcEntity instanceof class_1309 living)
        {
            return living.field_42108.method_48570(tickDelta);
        }

        return 0F;
    }

    @Override
    public float getLeaningPitch(float tickDelta)
    {
        if (this.mcEntity instanceof class_1309 living)
        {
            return living.method_6024(tickDelta);
        }

        return 0F;
    }

    /**
     * The lean is vanilla's own on a live entity - it grows it every tick - so there is nothing
     * to hand it. Only the preview stub, which has no ticks of its own, needs to be told.
     */
    @Override
    public void setLeaningPitch(float leaningPitch)
    {}

    @Override
    public boolean isTouchingWater()
    {
        return this.mcEntity.method_5799();
    }

    @Override
    public class_4050 getEntityPose()
    {
        return this.mcEntity.method_18376();
    }

    @Override
    public int getRoll()
    {
        if (this.mcEntity instanceof class_1309 living)
        {
            return living.method_6003();
        }

        return 0;
    }

    @Override
    public void setRoll(int roll)
    {
        if (this.mcEntity instanceof class_1309 living)
        {
            ((LivingEntityRollAccessor) living).bbs$setRoll(roll);
        }
    }

    @Override
    public boolean isFallFlying()
    {
        if (this.mcEntity instanceof class_1309 living)
        {
            return living.method_6128();
        }

        return false;
    }

    /**
     * Gliding is a tracked flag, and writing it on the server is what tells every client to
     * spread the wings - the same reason a played back actor's sprinting flag is written rather
     * than merely moved fast.
     */
    @Override
    public void setFallFlying(boolean fallFlying)
    {
        ((EntityInvoker) this.mcEntity).bbs$setFlag(EntityState.FALL_FLYING_FLAG, fallFlying);
    }

    @Override
    public class_243 getRotationVec(float transition)
    {
        return this.mcEntity.method_5828(transition);
    }

    @Override
    public class_243 lerpVelocity(float transition)
    {
        return this.lastVelocity.method_35590(this.mcEntity.method_18798(), transition);
    }

    @Override
    public boolean isUsingRiptide()
    {
        if (this.mcEntity instanceof class_1309 living)
        {
            return living.method_6123();
        }

        return false;
    }
}