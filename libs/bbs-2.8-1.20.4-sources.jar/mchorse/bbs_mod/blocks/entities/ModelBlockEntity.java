package mchorse.bbs_mod.blocks.entities;

import mchorse.bbs_mod.BBSMod;
import mchorse.bbs_mod.blocks.ModelBlock;
import mchorse.bbs_mod.data.DataStorageUtils;
import mchorse.bbs_mod.data.types.BaseType;
import mchorse.bbs_mod.data.types.MapType;
import mchorse.bbs_mod.api.events.ModelBlockEntityUpdateCallback;
import mchorse.bbs_mod.forms.entities.IEntity;
import mchorse.bbs_mod.forms.entities.StubEntity;
import mchorse.bbs_mod.forms.forms.Form;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;

public class ModelBlockEntity extends class_2586
{
    private ModelProperties properties = new ModelProperties();
    private IEntity entity = new StubEntity();

    private float lastYaw = Float.NaN;
    private float currentYaw = Float.NaN;

    public ModelBlockEntity(class_2338 pos, class_2680 state)
    {
        super(BBSMod.MODEL_BLOCK_ENTITY, pos, state);
    }

    public String getName()
    {
        class_2338 pos = this.method_11016();
        Form form = this.getProperties().getForm();
        String s = "(" + pos.method_10263() + ", " + pos.method_10264() + ", " + pos.method_10260() + ")";

        if (form != null)
        {
            s += " " + form.getDisplayName();
        }

        return s;
    }

    public ModelProperties getProperties()
    {
        return this.properties;
    }

    public IEntity getEntity()
    {
        return this.entity;
    }

    public void setLookYaw(float yaw)
    {
        this.lastYaw = yaw;
        this.currentYaw = yaw;
    }

    public float updateLookYawContinuous(float yaw)
    {
        if (Float.isNaN(this.currentYaw))
        {
            this.setLookYaw(yaw);

            return this.currentYaw;
        }

        float diff = yaw - this.lastYaw;

        while (diff > Math.PI) diff -= (float) (Math.PI * 2);
        while (diff < -Math.PI) diff += (float) (Math.PI * 2);

        this.currentYaw += diff;
        this.lastYaw = yaw;

        return this.currentYaw;
    }

    public void resetLookYaw()
    {
        this.lastYaw = this.currentYaw = Float.NaN;
    }

    public void snapLookYawToBase(float lastYaw, float currentYaw)
    {
        this.lastYaw = lastYaw;
        this.currentYaw = currentYaw;
    }

    public void tick(class_1937 world, class_2338 pos, class_2680 state)
    {
        ModelBlockEntityUpdateCallback.EVENT.invoker().update(this);

        this.properties.getEquipment().apply(this.entity);

        this.entity.update();
        this.entity.setWorld(world);
        this.properties.update(this.entity);
    }

    /**
     * The block's physical shape, built from the body settings against the
     * current form and transform.
     */
    public class_265 getShape()
    {
        return this.properties.getBody().buildShape(this.properties.getForm(), this.properties.getTransform());
    }

    @Nullable
    @Override
    public class_2596<class_2602> method_38235()
    {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887()
    {
        return method_38244();
    }

    @Override
    protected void method_11007(class_2487 nbt)
    {
        super.method_11007(nbt);

        MapType data = this.properties.toData();

        DataStorageUtils.writeToNbtCompound(nbt, "Properties", data);
    }

    @Override
    public void method_11014(class_2487 nbt)
    {
        super.method_11014(nbt);

        BaseType baseType = DataStorageUtils.readFromNbtCompound(nbt, "Properties");

        if (baseType instanceof MapType mapType)
        {
            this.properties.fromData(mapType);
        }
    }

    public void updateForm(MapType data, class_1937 world)
    {
        this.properties.fromData(data);

        class_2338 pos = this.method_11016();

        /* Light and sound live in the block STATE (the engine reads them from
         * there), but their source of truth is the body data — mirror it. */
        if (!world.method_8608())
        {
            ModelBlock.mirrorBlockState(world, pos);
        }

        class_2680 blockState = world.method_8320(pos);

        world.method_8413(pos, blockState, blockState, class_2248.field_31028);
        world.method_8524(pos);
    }
}