package mchorse.bbs_mod.actions;

import mchorse.bbs_mod.BBSSettings;
import mchorse.bbs_mod.entity.ActorEntity;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * A snapshot of everything a film changed in one world, so it can be put back when the film
 * stops.
 *
 * <p>The snapshot is shared by everyone filming in that world: whoever needs the world kept
 * intact {@link #acquire(Object)}s it and {@link #release(Object)}s it when they're done, and
 * the world is restored once the last holder lets go. Holding by identity rather than by a
 * counter is what makes every exit path correct on its own - a holder that disappears without
 * saying so (a player who disconnected mid-take) can still be dropped by name.
 */
public class DamageControl
{
    /** Smallest size worth walking the spawn list for - see {@link #addEntity(class_1297)}. */
    private static final int PRUNE_FLOOR = 256;

    /* Insertion ordered, so blocks are put back in the order they were first changed, and keyed
     * by position, so re-touching a block during a long take is a lookup rather than a scan of
     * everything captured so far - an explosion or a /fill used to cost time quadratic in the
     * size of the snapshot. */
    private Map<class_2338, BlockCapture> blocks = new LinkedHashMap<>();
    private List<class_1297> entities = new ArrayList<>();
    private int pruneAt = PRUNE_FLOOR;

    /* Identity, not equality: two ActionPlayers of the same film are two holders. */
    private Set<Object> owners = Collections.newSetFromMap(new IdentityHashMap<>());
    private int manualHolds;

    private class_3218 world;

    public boolean enable;

    public DamageControl(class_3218 world)
    {
        this.world = world;
        this.enable = BBSSettings.damageControl.get();
    }

    /**
     * Take a hold on this snapshot. A null owner is a hold taken by hand (the /bbs dc start
     * command), which has no object to be identified by and is counted instead.
     */
    public void acquire(Object owner)
    {
        if (owner == null)
        {
            this.manualHolds += 1;
        }
        else
        {
            this.owners.add(owner);
        }
    }

    /**
     * Let go of a hold, and say whether that was the last one. Releasing a hold that isn't
     * held is not an error: playback can be stopped more than once, and the second stop should
     * find nothing left to do rather than restore the world twice.
     */
    public boolean release(Object owner)
    {
        if (owner == null)
        {
            if (this.manualHolds > 0)
            {
                this.manualHolds -= 1;
            }
        }
        else
        {
            this.owners.remove(owner);
        }

        return this.owners.isEmpty() && this.manualHolds <= 0;
    }

    public void addBlock(class_2338 pos, class_2680 state, class_2586 entity)
    {
        if (!this.enable || this.blocks.containsKey(pos))
        {
            return;
        }

        /* The position handed over by the world is reused between calls, so both the key and
         * the capture get a copy of their own. */
        class_2338 key = new class_2338(pos);

        this.blocks.put(key, new BlockCapture(key, state, entity == null ? null : entity.method_38243()));
    }

    /**
     * Drop a region from the snapshot: whatever the film did in there stops mattering, because the
     * region itself is being taken out of the world on purpose.
     *
     * <p>This exists for the structure cut. Every {@code setBlockState} on the server is captured
     * while a film holds a snapshot, so a cut made with the editor open would be undone on the way
     * out — the build would come back and stand inside the form made from it.</p>
     */
    public void forget(class_2338 min, class_2338 max)
    {
        this.blocks.keySet().removeIf((pos) ->
            pos.method_10263() >= min.method_10263() && pos.method_10263() <= max.method_10263() &&
            pos.method_10264() >= min.method_10264() && pos.method_10264() <= max.method_10264() &&
            pos.method_10260() >= min.method_10260() && pos.method_10260() <= max.method_10260());
    }

    public void addEntity(class_1297 entity)
    {
        if (!this.enable)
        {
            return;
        }

        /* Actors are not damage done to the world: their lifetime belongs to the playback that
         * put them there. Releasing a snapshot held by something else - another film, or
         * /bbs dc start by hand - took them down with it, in the middle of a take that had
         * nothing to do with it. */
        if (entity instanceof ActorEntity)
        {
            return;
        }

        /* Entities already gone are dead weight: this list is only ever walked once, at the end,
         * so a long session held a strong reference per spawn for as long as the hold lasted.
         * Pruned on doubling rather than on every spawn, which would be quadratic. */
        if (this.entities.size() >= this.pruneAt)
        {
            this.entities.removeIf(class_1297::method_31481);
            this.pruneAt = Math.max(PRUNE_FLOOR, this.entities.size() * 2);
        }

        this.entities.add(entity);
    }

    /**
     * Put the world back the way it was found.
     *
     * <p>The caller is expected to have dropped this snapshot before calling: restoring a block
     * is itself a block change, and a snapshot still reachable from the manager would be
     * written to while it's being walked.
     *
     * <p>One entry that cannot be restored - a block entity whose type no longer exists, a
     * position outside the world - must not cost the rest of them, so every entry is put back
     * on its own and the snapshot is emptied whatever happens.
     */
    public void restore()
    {
        try
        {
            for (BlockCapture block : new ArrayList<>(this.blocks.values()))
            {
                this.restoreBlock(block);
            }

            for (class_1297 entity : new ArrayList<>(this.entities))
            {
                try
                {
                    if (!entity.method_31481())
                    {
                        entity.method_5650(class_1297.class_5529.field_26999);
                    }
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
        }
        finally
        {
            this.blocks.clear();
            this.entities.clear();
        }
    }

    private void restoreBlock(BlockCapture block)
    {
        try
        {
            this.world.method_8652(block.pos, block.lastState, 2);

            if (block.blockEntity != null)
            {
                class_2586 blockEntity = class_2586.method_11005(block.pos, block.lastState, block.blockEntity);

                /* Null when the block entity's type is gone - a mod removed since the take was
                 * captured. The block itself is already back, which is the most that can be
                 * done for it. */
                if (blockEntity != null)
                {
                    this.world.method_8438(blockEntity);
                }
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    private static class BlockCapture
    {
        public class_2338 pos;
        public class_2680 lastState;
        public class_2487 blockEntity;

        public BlockCapture(class_2338 pos, class_2680 lastState, class_2487 blockEntity)
        {
            this.pos = pos;
            this.lastState = lastState;
            this.blockEntity = blockEntity;
        }
    }
}
