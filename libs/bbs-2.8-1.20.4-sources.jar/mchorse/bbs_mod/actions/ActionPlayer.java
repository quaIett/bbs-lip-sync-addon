package mchorse.bbs_mod.actions;

import mchorse.bbs_mod.BBSMod;
import mchorse.bbs_mod.data.types.BaseType;
import mchorse.bbs_mod.entity.ActorEntity;
import mchorse.bbs_mod.film.Film;
import mchorse.bbs_mod.film.replays.Replay;
import mchorse.bbs_mod.film.replays.ReplayKeyframes;
import mchorse.bbs_mod.forms.FormUtils;
import mchorse.bbs_mod.forms.entities.EntityState;
import mchorse.bbs_mod.forms.entities.IEntity;
import mchorse.bbs_mod.forms.entities.MCEntity;
import mchorse.bbs_mod.forms.forms.Form;
import mchorse.bbs_mod.mixin.EntityInvoker;
import mchorse.bbs_mod.mixin.LivingEntityRollAccessor;
import mchorse.bbs_mod.morphing.Morph;
import mchorse.bbs_mod.network.ServerNetwork;
import mchorse.bbs_mod.settings.values.base.BaseValue;
import mchorse.bbs_mod.utils.DataPath;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1313;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ActionPlayer
{
    public Film film;
    public int tick;
    public boolean playing = true;
    public int countdown;
    public int exception;
    public PlayerType type;

    public boolean syncing;
    private boolean pendingResync;

    private class_3222 serverPlayer;
    private class_3218 world;
    private int duration;

    private Map<String, class_1309> actors = new HashMap<>();

    private Form cachedForm;

    /**
     * The film dresses the first person player for the duration of the playback, so what it
     * takes over has to be given back. It borrows exactly what it drives - the hotbar, the
     * armour and the off hand - and never the rest of the inventory, which no camera can see.
     */
    private boolean borrowedEquipment;
    private List<class_1799> cachedHotbar = new ArrayList<>();
    private Map<class_1304, class_1799> cachedEquipment = new EnumMap<>(class_1304.class);
    private int cacheSelectedSlot;
    private IEntity fpEntity;

    private float cacheHp;
    private int cacheHunger;
    private int cacheXpLevel;
    private float cacheXpProgress;

    public ActionPlayer(class_3222 serverPlayer, class_3218 world, Film film, int tick, int countdown, int exception, PlayerType type)
    {
        this.world = world;
        this.film = film;
        this.tick = tick;
        this.countdown = countdown;
        this.exception = exception;
        this.type = type;

        this.serverPlayer = serverPlayer;
        this.duration = film.calculateDuration();

        this.updateReplayEntities();

        Replay fpReplay = film.getFirstPersonReplay();

        if (this.type == PlayerType.NORMAL && this.serverPlayer != null && fpReplay != null)
        {
            this.borrowEquipment(fpReplay.keyframes);

            Morph morph = Morph.getMorph(this.serverPlayer);

            if (morph != null)
            {
                this.cachedForm = FormUtils.copy(morph.getForm());
            }

            ServerNetwork.sendMorphToTracked(this.serverPlayer, fpReplay.form.get());

            this.cacheHp = this.serverPlayer.method_6032();
            this.cacheHunger = this.serverPlayer.method_7344().method_7586();
            this.cacheXpLevel = this.serverPlayer.field_7520;
            this.cacheXpProgress = this.serverPlayer.field_7510;

            applyFilmPlayerSettingsTo(this.serverPlayer, this.film.hp.get(), this.film.hunger.get(), this.film.xpLevel.get(), this.film.xpProgress.get());
        }
    }

    /** Equipment slots the film drives directly; the hotbar is driven by slot index instead. */
    private static final class_1304[] BORROWED_SLOTS = {class_1304.field_6171, class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166};

    private void borrowEquipment(ReplayKeyframes keyframes)
    {
        class_1661 inventory = this.serverPlayer.method_31548();

        this.borrowedEquipment = true;
        this.cacheSelectedSlot = inventory.field_7545;
        this.fpEntity = new MCEntity(this.serverPlayer);

        for (int i = 0; i < ReplayKeyframes.HOTBAR_SIZE; i++)
        {
            this.cachedHotbar.add(inventory.method_5438(i).method_7972());

            /* Cells the replay says nothing about are left to the world during playback (see
             * ReplayKeyframes#applyEquipment), but they're still emptied once - otherwise the
             * player's own things would wander into frame. */
            if (!keyframes.drivesHotbarSlot(i))
            {
                inventory.method_5447(i, class_1799.field_8037);
            }
        }

        for (class_1304 slot : BORROWED_SLOTS)
        {
            this.cachedEquipment.put(slot, this.serverPlayer.method_6118(slot).method_7972());

            if (keyframes.getEquipmentChannel(slot).isEmpty())
            {
                this.serverPlayer.method_5673(slot, class_1799.field_8037);
            }
        }
    }

    private void returnEquipment()
    {
        class_1661 inventory = this.serverPlayer.method_31548();

        /* Playback can be stopped more than once (the film ends, then the manager stops it) */
        this.borrowedEquipment = false;

        for (int i = 0; i < this.cachedHotbar.size(); i++)
        {
            inventory.method_5447(i, this.cachedHotbar.get(i));
        }

        for (Map.Entry<class_1304, class_1799> entry : this.cachedEquipment.entrySet())
        {
            this.serverPlayer.method_5673(entry.getKey(), entry.getValue());
        }

        ServerNetwork.sendSelectedSlot(this.serverPlayer, this.cacheSelectedSlot);
    }

    public static void applyFilmPlayerSettingsTo(class_3222 player, float hp, float hunger, int xpLevel, float xpProgress)
    {
        player.method_6033(hp);
        player.method_7344().method_7580((int) hunger);
        player.method_14252(xpLevel);
        player.field_7510 = xpProgress;
    }

    /**
     * Reconcile the bodies in the world with the replays that ask for one. Whoever is still wanted
     * and still alive is left standing: this runs on every structural edit of the film, and razing
     * the whole cast each time handed every actor a new entity id - clients kept pointing at ids
     * that had just been discarded, and the bodies blinked out of the scene for a tick or two.
     */
    public void updateReplayEntities()
    {
        Map<String, class_1309> previous = new HashMap<>(this.actors);

        this.actors.clear();

        List<Replay> list = this.film.replays.getList();

        for (int i = 0; i < list.size(); i++)
        {
            Replay replay = list.get(i);
            boolean isActor = replay.actor.get() || replay.fp.get();

            if (i == this.exception || !isActor || !replay.enabled.get())
            {
                continue;
            }

            if (replay.fp.get() && this.serverPlayer != null)
            {
                if (this.type == PlayerType.NORMAL)
                {
                    this.actors.put(replay.getId(), this.serverPlayer);
                }
            }
            else
            {
                class_1309 kept = previous.remove(replay.getId());

                /* Kept only when it is still an actor's body: a replay that just stopped being
                 * first person leaves the player behind under the same key, and the player is
                 * nobody's to keep driving as a puppet. */
                if (kept instanceof ActorEntity actor && !actor.method_31481())
                {
                    this.actors.put(replay.getId(), actor);
                }
                else
                {
                    this.actors.put(replay.getId(), this.spawnActor(replay));
                }
            }
        }

        for (class_1309 entity : previous.values())
        {
            if (!entity.method_31747())
            {
                if (entity instanceof ActorEntity actor)
                {
                    actor.dropPickedUp();
                }

                entity.method_31472();
            }
        }

        this.broadcastActors();
    }

    /** Restore the cast for an editor restart without replacing healthy actors or the player. */
    public void resetActorsForRestart()
    {
        this.tick = 0;

        for (class_1309 entity : this.actors.values())
        {
            if (!(entity instanceof ActorEntity actor))
            {
                continue;
            }

            if (actor.method_29504() && !actor.method_31481())
            {
                actor.method_31472();
            }

            if (!actor.method_31481())
            {
                actor.method_6033(actor.method_6063());
                actor.field_6235 = 0;
                actor.field_6213 = 0;
                actor.field_6008 = 0;
            }
        }

        /* Missing/killed shells are recreated; healthy ones keep their network IDs. */
        this.updateReplayEntities();
    }

    private ActorEntity spawnActor(Replay replay)
    {
        ActorEntity actor = new ActorEntity(BBSMod.ACTOR_ENTITY, this.world);

        actor.setReplay(this.film.getId(), replay.getId());
        actor.setPickUpItems(replay.actorPickup.get());
        actor.setForm(FormUtils.copy(replay.form.get()));

        this.apply(actor, replay, this.tick, false);
        this.world.method_8649(actor);

        return actor;
    }

    private void broadcastActors()
    {
        for (class_3222 player : this.world.method_18456())
        {
            ServerNetwork.sendActors(player, this.film.getId(), this.actors);
        }
    }

    /**
     * Actors are props the film puts out, not creatures the world keeps, and the world may take one
     * away at any moment: a chunk that unloaded and came back drops its actor on the despawn flag.
     * The film would then keep driving a corpse - the take simply loses a body and never gets it
     * back. Anything missing is put back where its keyframes say it stands, and the map goes out
     * again so clients stop pointing at a dead id.
     *
     * <p>A body someone KILLED is the exception, and the reason the removal is asked for by name:
     * being hit is what the flag is for, and a death is a thing being filmed, not an accident to
     * undo. Putting it straight back made an actor unkillable by any means - a blow, a mob, even
     * {@code /kill} - because the next tick spawned a replacement. It stays down until the film is
     * restarted, which is what builds the cast again.</p>
     */
    private void reviveLostActors()
    {
        List<String> lost = null;

        for (Map.Entry<String, class_1309> entry : this.actors.entrySet())
        {
            class_1309 actor = entry.getValue();

            if (!actor.method_31747() && actor.method_31481())
            {
                if (lost == null)
                {
                    lost = new ArrayList<>();
                }

                lost.add(entry.getKey());
            }
        }

        if (lost == null)
        {
            return;
        }

        for (String id : lost)
        {
            Replay replay = (Replay) this.film.replays.get(id);
            class_1309 previous = this.actors.get(id);
            boolean killed = previous != null && previous.method_35049() == class_1297.class_5529.field_26998;

            if (killed || replay == null || !replay.enabled.get())
            {
                this.actors.remove(id);
            }
            else
            {
                this.actors.put(id, this.spawnActor(replay));
            }
        }

        this.broadcastActors();
    }

    public class_3218 getWorld()
    {
        return this.world;
    }

    /**
     * By uuid rather than by identity: dying and respawning hands the same person a brand new
     * {@link class_3222}, and a playback compared by reference then belonged to nobody.
     * It outlived the disconnect that should have ended it, still holding the equipment it had
     * borrowed - which the player never got back.
     */
    public boolean isPlayedBy(class_3222 player)
    {
        return this.serverPlayer != null && player != null && this.serverPlayer.method_5667().equals(player.method_5667());
    }

    /** The same person, but the entity they are now - a respawn replaces the object entirely. */
    private void refreshPlayer()
    {
        if (this.serverPlayer == null)
        {
            return;
        }

        class_3222 live = this.world.method_8503().method_3760().method_14602(this.serverPlayer.method_5667());

        if (live != null)
        {
            this.serverPlayer = live;
        }
    }

    public void apply(class_1309 actor, Replay replay, float tick, boolean ticking)
    {
        /* Replay-local, the way the client already reads it when it draws: a looping replay wraps
         * the film's tick into its own window. The server never wrapped, so a looping replay's body
         * stood at the unwrapped tick - off in a part of the take the loop never reaches - while
         * the drawn one played its loop. */
        tick = replay.getTick((int) tick);

        double x = replay.keyframes.x.interpolate(tick);
        double y = replay.keyframes.y.interpolate(tick);
        double z = replay.keyframes.z.interpolate(tick);
        float yawHead = replay.keyframes.headYaw.interpolate(tick).floatValue();
        float yawBody = replay.keyframes.bodyYaw.interpolate(tick).floatValue();
        float pitch = replay.keyframes.pitch.interpolate(tick).floatValue();

        class_243 pos = actor.method_19538();
        boolean grounded = replay.keyframes.grounded.interpolate(tick) > 0;

        if (ticking)
        {
            /* Probe downwards so vanilla's collision registers the floor - see
             * ReplayKeyframes#GRAVITY_PROBE. */
            double dY = y - pos.field_1351 - (grounded ? ReplayKeyframes.GRAVITY_PROBE : 0D);

            actor.method_5784(class_1313.field_6308, new class_243(x - pos.field_1352, dY, z - pos.field_1350));
        }

        actor.method_5814(x, y, z);
        actor.method_36456(yawHead);
        actor.method_5847(yawHead);
        actor.method_36457(pitch);
        actor.method_5636(yawBody);
        boolean sneaking = EntityState.isOn(replay.keyframes.state(EntityState.SNEAKING).interpolate(tick));
        boolean swimming = EntityState.isOn(replay.keyframes.state(EntityState.SWIMMING).interpolate(tick));
        boolean gliding = EntityState.isOn(replay.keyframes.state(EntityState.GLIDING).interpolate(tick));

        actor.method_5660(sneaking);
        actor.method_24830(grounded);

        /* The sprinting flag is tracked data, so setting it here is what makes the
         * client spawn vanilla's sprinting particles for this actor. Swimming and gliding are
         * the same kind of thing: the flag is what spreads the elytra's wings and lays the body
         * flat on every client watching, and neither would happen from the frame alone. */
        actor.method_5728(EntityState.isOn(replay.keyframes.state(EntityState.SPRINTING).interpolate(tick)));
        actor.method_5796(swimming);
        ((EntityInvoker) actor).bbs$setFlag(EntityState.FALL_FLYING_FLAG, gliding);
        actor.method_18380(EntityState.pose(gliding, swimming, sneaking));

        /* Vanilla counts the roll up while flying, and an actor is placed rather than flown, so
         * the recorded count is handed over - it's what ramps the elytra's dive. */
        ((LivingEntityRollAccessor) actor).bbs$setRoll(replay.keyframes.roll.interpolate(tick).intValue());

        /* Riding and creative flight are recorded but not written here: a replay doesn't mount
         * anyone, and flight is a permission on a real player. Both only pick an animation. */

        if (actor instanceof class_3222 player)
        {
            /* On a player equipStack() is a write into the real inventory, so the replay may
             * only dress one whose equipment the film borrowed at startup and gives back on
             * stop. A replay turned first person mid-playback borrowed nothing and dresses
             * nobody. */
            if (this.borrowedEquipment)
            {
                this.dressPlayer(player, replay.keyframes, tick);
            }
        }
        else
        {
            actor.method_5673(class_1304.field_6173, replay.keyframes.getMainHandStack(tick));
            actor.method_5673(class_1304.field_6171, replay.keyframes.offHand.interpolate(tick, class_1799.field_8037));
            actor.method_5673(class_1304.field_6169, replay.keyframes.armorHead.interpolate(tick, class_1799.field_8037));
            actor.method_5673(class_1304.field_6174, replay.keyframes.armorChest.interpolate(tick, class_1799.field_8037));
            actor.method_5673(class_1304.field_6172, replay.keyframes.armorLegs.interpolate(tick, class_1799.field_8037));
            actor.method_5673(class_1304.field_6166, replay.keyframes.armorFeet.interpolate(tick, class_1799.field_8037));
        }

        double vx = x - replay.keyframes.x.interpolate(tick - 1);
        double vy = y - replay.keyframes.y.interpolate(tick - 1);
        double vz = z - replay.keyframes.z.interpolate(tick - 1);

        if (vy == 0D)
        {
            vy = -ReplayKeyframes.GRAVITY_PROBE;
        }

        actor.method_18800(vx, vy, vz);

        actor.field_6017 = replay.keyframes.fall.interpolate(tick).floatValue();
    }

    /**
     * Lay the replay's frame out onto the first person player: nine hotbar cells, the armour,
     * the off hand and the selection. Nothing is put into the main hand - that's the selected
     * cell, and it's already there.
     */
    private void dressPlayer(class_3222 player, ReplayKeyframes keyframes, float tick)
    {
        /* Selection first, so anything reading "the hand" during this frame reads the cell the
         * frame means rather than the one it just left. */
        int slot = keyframes.getSelectedSlot(tick);

        if (player.method_31548().field_7545 != slot)
        {
            ServerNetwork.sendSelectedSlot(player, slot);
        }

        keyframes.applyEquipment(tick, this.fpEntity);
    }

    public boolean tick()
    {
        if (this.countdown > 0)
        {
            this.countdown -= 1;

            return false;
        }

        this.reviveLostActors();

        for (Map.Entry<String, class_1309> entry : this.actors.entrySet())
        {
            Replay replay = (Replay) this.film.replays.get(entry.getKey());

            if (replay != null)
            {
                this.apply(entry.getValue(), replay, this.tick, true);
            }
        }

        if (!this.playing)
        {
            return false;
        }

        if (this.tick >= 0)
        {
            this.applyAction();
        }

        this.tick += 1;

        return !this.syncing && this.tick >= this.duration;
    }

    private void applyAction()
    {
        SuperFakePlayer fakePlayer = SuperFakePlayer.get(this.world);
        List<Replay> list = this.film.replays.getList();

        for (int i = 0; i < list.size(); i++)
        {
            if (i == this.exception)
            {
                continue;
            }

            Replay replay = list.get(i);

            if (!replay.enabled.get())
            {
                continue;
            }

            class_1309 actor = this.actors.get(replay.getId());

            /* Replay-local for the same reason the pose is - see apply(). The client answers its
             * own clips on the wrapped tick, so an unwrapped one here had the two disagreeing. */
            replay.applyActions(actor, fakePlayer, this.film, replay.getTick(this.tick));
        }

        /* Chests the clips of this tick still hold open go up, the rest come
         * down - including when the film was scrubbed rather than played */
        fakePlayer.flushLids();
    }

    public void syncData(DataPath key, BaseType data)
    {
        /* findRecursively (not getRecursively) so an unresolvable path doesn't
         * throw and abort the whole server task. */
        BaseValue baseValue = this.film.findRecursively(key);

        if (baseValue != null)
        {
            this.pendingResync = false;
            baseValue.fromData(data);

            /* The edit may have moved the film's end - a keyframe past the camera's last clip, or
             * a replay switched off - and the playback stops (and takes its actors down) by it. */
            this.duration = this.film.calculateDuration();

            if (baseValue == this.film || baseValue.getId().equals("actor") || baseValue.getId().equals("fp") || baseValue.getId().equals("enabled") || baseValue.getId().equals("replays"))
            {
                this.updateReplayEntities();
            }
            else if (baseValue.getId().equals("actor_pickup") && baseValue.getParent() instanceof Replay replay)
            {
                if (this.actors.get(replay.getId()) instanceof ActorEntity actor)
                {
                    actor.setPickUpItems(replay.actorPickup.get());
                }
            }
            else if (baseValue.getId().equals("form") && baseValue.getParent() instanceof Replay replay)
            {
                /* A costume change, not a change of cast: the body already standing there takes the
                 * new form. Rebuilding the cast over it would hand every actor in the film a fresh
                 * entity id, and until now nothing happened at all - the actor kept its old form
                 * until something else forced a restart. */
                if (this.actors.get(replay.getId()) instanceof ActorEntity actor)
                {
                    actor.setForm(FormUtils.copy(replay.form.get()));
                }
            }
        }
        else if (!this.pendingResync && this.serverPlayer != null)
        {
            /* The client edited a path we don't have (e.g. a keyframe it just
             * inserted but hasn't structurally synced yet). Ask it to re-send the
             * whole film so we catch up; debounced until that full data arrives. */
            this.pendingResync = true;

            ServerNetwork.requestFilmResync(this.serverPlayer, this.film.getId());
        }
    }

    public void goTo(int tick)
    {
        this.goTo(this.tick, tick);
    }

    public void goTo(int from, int tick)
    {
        if (from != tick)
        {
            this.tick = from;

            while (this.tick != tick)
            {
                this.tick += this.tick > tick ? -1 : 1;

                this.applyAction();
            }
        }
        else
        {
            /* Nothing to replay, but the destination is still the destination: a rewind to the
             * very frame the walk would have started from has to land there all the same. */
            this.tick = tick;
        }

        /* Poses after the actions and at the destination, not before: replaying the actions walks
         * the tick counter, and an actor placed before that walk stands on the frame it is leaving
         * rather than the one it was asked for. A restart jumps from 0, so that stale frame was
         * the very beginning - the actor appeared at the origin for a tick before catching up. */
        for (Map.Entry<String, class_1309> entry : this.actors.entrySet())
        {
            Replay replay = (Replay) this.film.replays.get(entry.getKey());

            if (replay != null)
            {
                this.apply(entry.getValue(), replay, this.tick, false);
            }
        }
    }

    public void stop()
    {
        SuperFakePlayer fakePlayer = SuperFakePlayer.getIfPresent(this.world);

        /* Nothing asks for a lid any more, so every one the film opened closes */
        if (fakePlayer != null)
        {
            fakePlayer.flushLids();
        }

        for (class_1309 value : this.actors.values())
        {
            if (!value.method_31747())
            {
                /* Before the body goes: what it swept up during the take is the world's, not the
                 * film's, and this is the last moment there is anywhere to put it back. */
                if (value instanceof ActorEntity actor)
                {
                    actor.dropPickedUp();
                }

                value.method_31472();
            }
        }

        /* Every way a playback ends comes through here - the film reaching its end, the editor
         * stopping it, the player disconnecting, the server shutting down - so this is the one
         * place that has to let damage control go. Releasing a hold that was already released
         * does nothing, which is what makes stopping twice harmless. */
        BBSMod.getActions().stopDamage(this.world, this);

        /* Whether the equipment was borrowed, not whether it would be borrowed now: the film's
         * first person replay can be toggled off mid-playback, and then there would be nothing
         * to give back. */
        if (this.borrowedEquipment)
        {
            this.refreshPlayer();

            this.returnEquipment();

            ServerNetwork.sendMorphToTracked(this.serverPlayer, this.cachedForm);

            this.serverPlayer.method_6033(this.cacheHp);
            this.serverPlayer.method_7344().method_7580(this.cacheHunger);
            this.serverPlayer.field_7510 = this.cacheXpProgress;
            this.serverPlayer.method_14252(this.cacheXpLevel);
        }
    }

    public void toggle()
    {
        this.playing = !this.playing;
    }
}
