package mchorse.bbs_mod;

import mchorse.bbs_mod.forms.forms.SplineForm;

import mchorse.bbs_mod.actions.ActionHandler;
import mchorse.bbs_mod.actions.ActionManager;
import mchorse.bbs_mod.actions.types.AttackActionClip;
import mchorse.bbs_mod.actions.types.DamageActionClip;
import mchorse.bbs_mod.actions.types.SwipeActionClip;
import mchorse.bbs_mod.actions.types.blocks.BreakBlockActionClip;
import mchorse.bbs_mod.actions.types.blocks.InteractBlockActionClip;
import mchorse.bbs_mod.actions.types.blocks.PlaceBlockActionClip;
import mchorse.bbs_mod.actions.types.chat.ChatActionClip;
import mchorse.bbs_mod.actions.types.chat.CommandActionClip;
import mchorse.bbs_mod.actions.types.item.ItemDropActionClip;
import mchorse.bbs_mod.actions.types.item.ReleaseUseItemActionClip;
import mchorse.bbs_mod.actions.types.item.UseBlockItemActionClip;
import mchorse.bbs_mod.actions.types.item.UseItemActionClip;
import mchorse.bbs_mod.blocks.ModelBlock;
import mchorse.bbs_mod.blocks.entities.ModelBlockEntity;
import mchorse.bbs_mod.blocks.entities.ModelProperties;
import mchorse.bbs_mod.camera.clips.ClipFactoryData;
import mchorse.bbs_mod.camera.clips.converters.DollyToKeyframeConverter;
import mchorse.bbs_mod.camera.clips.converters.DollyToPathConverter;
import mchorse.bbs_mod.camera.clips.converters.IdleConverter;
import mchorse.bbs_mod.camera.clips.converters.IdleToDollyConverter;
import mchorse.bbs_mod.camera.clips.converters.IdleToKeyframeConverter;
import mchorse.bbs_mod.camera.clips.converters.IdleToPathConverter;
import mchorse.bbs_mod.camera.clips.converters.PathToDollyConverter;
import mchorse.bbs_mod.camera.clips.converters.PathToKeyframeConverter;
import mchorse.bbs_mod.camera.clips.misc.AudioClip;
import mchorse.bbs_mod.camera.clips.misc.CurveClip;
import mchorse.bbs_mod.camera.clips.misc.ImageClip;
import mchorse.bbs_mod.camera.clips.misc.SubtitleClip;
import mchorse.bbs_mod.camera.clips.misc.VideoClip;
import mchorse.bbs_mod.camera.clips.modifiers.AngleClip;
import mchorse.bbs_mod.camera.clips.modifiers.DollyZoomClip;
import mchorse.bbs_mod.camera.clips.modifiers.DragClip;
import mchorse.bbs_mod.camera.clips.modifiers.LookClip;
import mchorse.bbs_mod.camera.clips.modifiers.MathClip;
import mchorse.bbs_mod.camera.clips.modifiers.OrbitClip;
import mchorse.bbs_mod.camera.clips.modifiers.RemapperClip;
import mchorse.bbs_mod.camera.clips.modifiers.ShakeClip;
import mchorse.bbs_mod.camera.clips.modifiers.TrackerClip;
import mchorse.bbs_mod.camera.clips.modifiers.TranslateClip;
import mchorse.bbs_mod.camera.clips.overwrite.DollyClip;
import mchorse.bbs_mod.camera.clips.overwrite.IdleClip;
import mchorse.bbs_mod.camera.clips.overwrite.KeyframeClip;
import mchorse.bbs_mod.camera.clips.overwrite.PathClip;
import mchorse.bbs_mod.camera.clips.overwrite.SplineClip;
import mchorse.bbs_mod.entity.ActorEntity;
import mchorse.bbs_mod.entity.GunProjectileEntity;
import mchorse.bbs_mod.api.BBSAddonMod;
import mchorse.bbs_mod.api.EventBus;
import mchorse.bbs_mod.api.events.BBSReadyEvent;
import mchorse.bbs_mod.api.events.RegisterActionClipsEvent;
import mchorse.bbs_mod.api.events.RegisterCameraClipsEvent;
import mchorse.bbs_mod.api.events.RegisterFormModifiersEvent;
import mchorse.bbs_mod.api.events.RegisterFormsEvent;
import mchorse.bbs_mod.api.events.RegisterKeyframeFactoriesEvent;
import mchorse.bbs_mod.api.events.RegisterSettingsEvent;
import mchorse.bbs_mod.utils.keyframes.factories.KeyframeFactories;
import mchorse.bbs_mod.api.events.RegisterSourcePacksEvent;
import mchorse.bbs_mod.film.FilmManager;
import mchorse.bbs_mod.forms.FormArchitect;
import mchorse.bbs_mod.forms.forms.AnchorForm;
import mchorse.bbs_mod.forms.forms.BillboardForm;
import mchorse.bbs_mod.forms.forms.VideoForm;
import mchorse.bbs_mod.forms.forms.BlockForm;
import mchorse.bbs_mod.forms.forms.ExtrudedForm;
import mchorse.bbs_mod.forms.forms.FramebufferForm;
import mchorse.bbs_mod.forms.forms.ItemForm;
import mchorse.bbs_mod.forms.forms.LabelForm;
import mchorse.bbs_mod.forms.forms.MobForm;
import mchorse.bbs_mod.forms.forms.ModelForm;
import mchorse.bbs_mod.forms.forms.ParticleForm;
import mchorse.bbs_mod.forms.forms.StructureForm;
import mchorse.bbs_mod.forms.forms.TrailForm;
import mchorse.bbs_mod.forms.forms.VanillaParticleForm;
import mchorse.bbs_mod.items.GunItem;
import mchorse.bbs_mod.morphing.Morph;
import mchorse.bbs_mod.network.ServerNetwork;
import mchorse.bbs_mod.resources.AssetProvider;
import mchorse.bbs_mod.resources.ISourcePack;
import mchorse.bbs_mod.resources.Link;
import mchorse.bbs_mod.resources.packs.DynamicSourcePack;
import mchorse.bbs_mod.resources.packs.ExternalAssetsSourcePack;
import mchorse.bbs_mod.resources.packs.InternalAssetsSourcePack;
import mchorse.bbs_mod.settings.Settings;
import mchorse.bbs_mod.settings.SettingsBuilder;
import mchorse.bbs_mod.settings.SettingsManager;
import mchorse.bbs_mod.ui.utils.icons.Icon;
import mchorse.bbs_mod.ui.utils.icons.Icons;
import mchorse.bbs_mod.utils.clips.Clip;
import mchorse.bbs_mod.utils.clips.ClipFactory;
import mchorse.bbs_mod.utils.colors.Colors;
import mchorse.bbs_mod.utils.factory.MapFactory;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.gamerule.v1.GameRuleFactory;
import net.fabricmc.fabric.api.gamerule.v1.GameRuleRegistry;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.networking.v1.EntityTrackingEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1928;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_4048;
import net.minecraft.class_5218;
import net.minecraft.class_7923;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class BBSMod implements ModInitializer
{
    public static final String MOD_ID = "bbs";

    public static final EventBus events = new EventBus();

    private static ActionManager actions;

    /* Important folders */
    private static File gameFolder;
    private static File assetsFolder;
    private static File settingsFolder;

    /* Core services */
    private static AssetProvider provider;
    private static DynamicSourcePack dynamicSourcePack;
    private static ExternalAssetsSourcePack originalSourcePack;

    /* Foundation services */
    private static SettingsManager settings;
    private static FormArchitect forms;

    /* Data */
    private static FilmManager films;

    private static List<Runnable> runnables = new ArrayList<>();

    private static MapFactory<Clip, ClipFactoryData> factoryCameraClips;
    private static MapFactory<Clip, ClipFactoryData> factoryActionClips;

    public static final class_1299<ActorEntity> ACTOR_ENTITY = class_2378.method_10230(
        class_7923.field_41177,
        new class_2960(MOD_ID, "actor"),
        FabricEntityTypeBuilder.create(class_1311.field_6294, ActorEntity::new)
            .dimensions(class_4048.method_18385(0.6F, 1.8F))
            .trackRangeBlocks(256)
            .trackedUpdateRate(1)
            .build());

    public static final class_1299<GunProjectileEntity> GUN_PROJECTILE_ENTITY = class_2378.method_10230(
        class_7923.field_41177,
        new class_2960(MOD_ID, "gun_projectile"),
        FabricEntityTypeBuilder.create(class_1311.field_6294, GunProjectileEntity::new)
            .dimensions(class_4048.method_18385(0.25F, 0.25F))
            .trackRangeChunks(24)
            .trackedUpdateRate(1)
            .build());

    public static final class_2248 MODEL_BLOCK = new ModelBlock(FabricBlockSettings.method_9637()
        .method_45477()
        .method_42327()
        .method_9634()
        .method_22488()
        .method_51370()
        .method_9632(0F)
        /* The hitbox comes from the block entity, so the state's shape cache
         * must stay off — with it on, the per-block shape would never be asked. */
        .method_9624()
        .method_9631((state) -> state.method_11654(ModelBlock.LIGHT_LEVEL)));
    public static final class_2248 CHROMA_RED_BLOCK = createChromaBlock();
    public static final class_2248 CHROMA_GREEN_BLOCK = createChromaBlock();
    public static final class_2248 CHROMA_BLUE_BLOCK = createChromaBlock();
    public static final class_2248 CHROMA_CYAN_BLOCK = createChromaBlock();
    public static final class_2248 CHROMA_MAGENTA_BLOCK = createChromaBlock();
    public static final class_2248 CHROMA_YELLOW_BLOCK = createChromaBlock();
    public static final class_2248 CHROMA_BLACK_BLOCK = createChromaBlock();
    public static final class_2248 CHROMA_WHITE_BLOCK = createChromaBlock();

    public static final class_1747 MODEL_BLOCK_ITEM = new class_1747(MODEL_BLOCK, new class_1792.class_1793());
    public static final GunItem GUN_ITEM = new GunItem(new class_1792.class_1793().method_7889(1));
    /* Plain vanilla item on purpose: the region selection it drives lives entirely on the client,
     * so there is nothing for a custom Item subclass to hold (see StructureSelection). */
    public static final class_1792 STRUCTURE_WAND_ITEM = new class_1792(new class_1792.class_1793().method_7889(1));
    public static final class_1747 CHROMA_RED_BLOCK_ITEM = new class_1747(CHROMA_RED_BLOCK, new class_1792.class_1793());
    public static final class_1747 CHROMA_GREEN_BLOCK_ITEM = new class_1747(CHROMA_GREEN_BLOCK, new class_1792.class_1793());
    public static final class_1747 CHROMA_BLUE_BLOCK_ITEM = new class_1747(CHROMA_BLUE_BLOCK, new class_1792.class_1793());
    public static final class_1747 CHROMA_CYAN_BLOCK_ITEM = new class_1747(CHROMA_CYAN_BLOCK, new class_1792.class_1793());
    public static final class_1747 CHROMA_MAGENTA_BLOCK_ITEM = new class_1747(CHROMA_MAGENTA_BLOCK, new class_1792.class_1793());
    public static final class_1747 CHROMA_YELLOW_BLOCK_ITEM = new class_1747(CHROMA_YELLOW_BLOCK, new class_1792.class_1793());
    public static final class_1747 CHROMA_BLACK_BLOCK_ITEM = new class_1747(CHROMA_BLACK_BLOCK, new class_1792.class_1793());
    public static final class_1747 CHROMA_WHITE_BLOCK_ITEM = new class_1747(CHROMA_WHITE_BLOCK, new class_1792.class_1793());

    public static final class_1928.class_4313<class_1928.class_4310> BBS_EDITING_RULE = GameRuleRegistry.register("bbsEditing", class_1928.class_5198.field_24100, GameRuleFactory.createBooleanRule(true));

    public static final class_2591<ModelBlockEntity> MODEL_BLOCK_ENTITY = class_2378.method_10230(
        class_7923.field_41181,
        new class_2960(MOD_ID, "model_block_entity"),
        FabricBlockEntityTypeBuilder.create(ModelBlockEntity::new, MODEL_BLOCK).build()
    );

    public static final class_1761 ITEM_GROUP = FabricItemGroup.builder()
        .method_47320(() -> createModelBlockStack(Link.assets("textures/icon.png")))
        .method_47321(class_2561.method_43471("itemGroup.bbs.main"))
        .method_47317((context, entries) ->
        {
            entries.method_45420(createModelBlockStack(Link.assets("textures/model_block.png")));
            entries.method_45421(CHROMA_RED_BLOCK_ITEM);
            entries.method_45421(CHROMA_GREEN_BLOCK_ITEM);
            entries.method_45421(CHROMA_BLUE_BLOCK_ITEM);
            entries.method_45421(CHROMA_CYAN_BLOCK_ITEM);
            entries.method_45421(CHROMA_MAGENTA_BLOCK_ITEM);
            entries.method_45421(CHROMA_YELLOW_BLOCK_ITEM);
            entries.method_45421(CHROMA_BLACK_BLOCK_ITEM);
            entries.method_45421(CHROMA_WHITE_BLOCK_ITEM);
            entries.method_45420(new class_1799(GUN_ITEM));
            entries.method_45420(new class_1799(STRUCTURE_WAND_ITEM));
        })
        .method_47324();

    public static final class_3414 CLICK = registerSound("click");

    private static class_3414 registerSound(String path)
    {
        class_2960 id = new class_2960(MOD_ID, path);

        return class_2378.method_10230(class_7923.field_41172, id, class_3414.method_47908(id));
    }

    private static File worldFolder;

    private static class_2248 createChromaBlock()
    {
        return new class_2248(FabricBlockSettings.method_9637()
            .method_45477()
            .method_42327()
            .method_29292()
            .method_9629(-1F, 3600000F));
    }

    private static class_1799 createModelBlockStack(Link texture)
    {
        class_1799 stack = new class_1799(MODEL_BLOCK_ITEM);
        ModelBlockEntity entity = new ModelBlockEntity(class_2338.field_10980, MODEL_BLOCK.method_9564());
        class_2487 nbt = new class_2487();
        BillboardForm form = new BillboardForm();
        ModelProperties properties = entity.getProperties();

        form.transform.get().translate.set(0F, 0.5F, 0F);
        form.texture.set(texture);
        properties.setForm(form);
        properties.getTransformFirstPerson().translate.set(0F, 0F, -0.25F);

        class_2487 compound = entity.method_38243();

        nbt.method_10566("BlockEntityTag", compound);
        stack.method_7980(nbt);

        return stack;
    }

    /**
     * Main folder, where all the other folders are located.
     */
    public static File getGameFolder()
    {
        return gameFolder;
    }

    public static File getGamePath(String path)
    {
        return new File(gameFolder, path);
    }

    /**
     * Assets folder within game's folder. It's used to store any assets that can
     * be loaded by {@link #provider}.
     */
    public static File getAssetsFolder()
    {
        return assetsFolder;
    }

    /** Additional assets of the local world, or null outside a local world. */
    public static File getWorldAssetsFolder()
    {
        ISourcePack sourcePack = getDynamicSourcePack().getSecondary();

        if (sourcePack instanceof ExternalAssetsSourcePack pack)
        {
            return pack.getFolder();
        }

        return null;
    }

    public static File getAudioFolder()
    {
        return getAssetsPath("audio");
    }

    public static File getAssetsPath(String path)
    {
        return new File(getAssetsFolder(), path);
    }

    public static File getAudioCacheFolder()
    {
        return getSettingsPath("audio_cache");
    }

    /**
     * Config folder within game's folder. It's used to store any configuration
     * files.
     */
    public static File getSettingsFolder()
    {
        return settingsFolder;
    }

    public static File getSettingsPath(String path)
    {
        return new File(settingsFolder, path);
    }

    public static File getExportFolder()
    {
        return getGamePath("export");
    }

    public static ActionManager getActions()
    {
        return actions;
    }

    public static AssetProvider getProvider()
    {
        return provider;
    }

    public static DynamicSourcePack getDynamicSourcePack()
    {
        return dynamicSourcePack;
    }

    public static ExternalAssetsSourcePack getOriginalSourcePack()
    {
        return originalSourcePack;
    }

    public static SettingsManager getSettings()
    {
        return settings;
    }

    public static FormArchitect getForms()
    {
        return forms;
    }

    public static FilmManager getFilms()
    {
        return films;
    }

    public static MapFactory<Clip, ClipFactoryData> getFactoryCameraClips()
    {
        return factoryCameraClips;
    }

    public static MapFactory<Clip, ClipFactoryData> getFactoryActionClips()
    {
        return factoryActionClips;
    }

    @Override
    public void onInitialize()
    {
        /* Core */
        gameFolder = FabricLoader.getInstance().getGameDir().toFile();
        assetsFolder = new File(gameFolder, "config/bbs/assets");
        settingsFolder = new File(gameFolder, "config/bbs/settings");

        assetsFolder.mkdirs();

        FabricLoader.getInstance()
            .getEntrypointContainers("bbs-addon", BBSAddonMod.class)
            .forEach((container) ->
            {
                events.register(container.getEntrypoint());
            });

        actions = new ActionManager();

        originalSourcePack = new ExternalAssetsSourcePack(Link.ASSETS, assetsFolder).providesFiles();
        dynamicSourcePack = new DynamicSourcePack(originalSourcePack);
        provider = new AssetProvider();
        provider.register(dynamicSourcePack);
        provider.register(new InternalAssetsSourcePack());

        events.post(new RegisterSourcePacksEvent(provider));

        /* Before the forms, because a form of an addon's may well animate a value type of
         * the same addon's. */
        KeyframeFactories.setup();

        events.post(new RegisterKeyframeFactoriesEvent());

        settings = new SettingsManager();
        forms = new FormArchitect();
        forms
            .register(Link.bbs("billboard"), BillboardForm.class, null)
            .register(Link.bbs("video"), VideoForm.class, null)
            .register(Link.bbs("label"), LabelForm.class, null)
            .register(Link.bbs("model"), ModelForm.class, null)
            .register(Link.bbs("particle"), ParticleForm.class, null)
            .register(Link.bbs("extruded"), ExtrudedForm.class, null)
            .register(Link.bbs("block"), BlockForm.class, null)
            .register(Link.bbs("item"), ItemForm.class, null)
            .register(Link.bbs("anchor"), AnchorForm.class, null)
            .register(Link.bbs("spline"), SplineForm.class, null)
            .register(Link.bbs("mob"), MobForm.class, null)
            .register(Link.bbs("vanilla_particles"), VanillaParticleForm.class, null)
            .register(Link.bbs("trail"), TrailForm.class, null)
            .register(Link.bbs("framebuffer"), FramebufferForm.class, null)
            .register(Link.bbs("structure"), StructureForm.class, null);

        events.post(new RegisterFormsEvent(forms));
        events.post(new RegisterFormModifiersEvent());

        films = new FilmManager(() -> new File(worldFolder, "bbs/films"));

        /* Register camera clips */
        factoryCameraClips = new ClipFactory()
            .register(Link.bbs("idle"), IdleClip.class, new ClipFactoryData(Icons.FRUSTUM, 0x159e64)
                .withConverter(Link.bbs("dolly"), new IdleToDollyConverter())
                .withConverter(Link.bbs("path"), new IdleToPathConverter())
                .withConverter(Link.bbs("keyframe"), new IdleToKeyframeConverter()))
            .register(Link.bbs("dolly"), DollyClip.class, new ClipFactoryData(Icons.CAMERA, 0xffa500)
                .withConverter(Link.bbs("idle"), IdleConverter.CONVERTER)
                .withConverter(Link.bbs("path"), new DollyToPathConverter())
                .withConverter(Link.bbs("keyframe"), new DollyToKeyframeConverter()))
            .register(Link.bbs("path"), PathClip.class, new ClipFactoryData(Icons.GALLERY, 0x6820ad)
                .withConverter(Link.bbs("idle"), IdleConverter.CONVERTER)
                .withConverter(Link.bbs("dolly"), new PathToDollyConverter())
                .withConverter(Link.bbs("keyframe"), new PathToKeyframeConverter()))
            .register(Link.bbs("keyframe"), KeyframeClip.class, new ClipFactoryData(Icons.CURVES, 0xde2e9f)
                .withConverter(Link.bbs("idle"), IdleConverter.CONVERTER))
            .register(Link.bbs("translate"), TranslateClip.class, new ClipFactoryData(Icons.UPLOAD, 0x4ba03e))
            .register(Link.bbs("angle"), AngleClip.class, new ClipFactoryData(Icons.ARC, 0xd77a0a))
            .register(Link.bbs("drag"), DragClip.class, new ClipFactoryData(Icons.FADING, 0x4baff7))
            .register(Link.bbs("shake"), ShakeClip.class, new ClipFactoryData(Icons.EXCHANGE, 0x159e64))
            .register(Link.bbs("math"), MathClip.class, new ClipFactoryData(Icons.GRAPH, 0x6820ad))
            .register(Link.bbs("look"), LookClip.class, new ClipFactoryData(Icons.VISIBLE, 0x197fff))
            .register(Link.bbs("orbit"), OrbitClip.class, new ClipFactoryData(Icons.GLOBE, 0xd82253))
            .register(Link.bbs("remapper"), RemapperClip.class, new ClipFactoryData(Icons.TIME, 0x222222))
            .register(Link.bbs("audio"), AudioClip.class, new ClipFactoryData(Icons.SOUND, 0xffc825))
            .register(Link.bbs("subtitle"), SubtitleClip.class, new ClipFactoryData(Icons.FONT, 0x888899))
            .register(Link.bbs("image"), ImageClip.class, new ClipFactoryData(Icons.PICTURE, 0x2d4fd2))
            .register(Link.bbs("video"), VideoClip.class, new ClipFactoryData(Icons.VIDEO_CAMERA, 0xd21f3c))
            .register(Link.bbs("curve"), CurveClip.class, new ClipFactoryData(Icons.ARC, 0xff1493))
            .register(Link.bbs("tracker"), TrackerClip.class, new ClipFactoryData(Icons.USER, 0xffffff))
            .register(Link.bbs("spline"), SplineClip.class, new ClipFactoryData(Icons.GRAPH, 0x5599ff))
            .register(Link.bbs("dolly_zoom"), DollyZoomClip.class, new ClipFactoryData(Icons.FILTER, 0x7d56c9));

        events.post(new RegisterCameraClipsEvent(factoryCameraClips));

        factoryActionClips = new ClipFactory()
            .register(Link.bbs("chat"), ChatActionClip.class, new ClipFactoryData(Icons.BUBBLE, Colors.YELLOW))
            .register(Link.bbs("command"), CommandActionClip.class, new ClipFactoryData(Icons.PROPERTIES, Colors.ACTIVE))
            .register(Link.bbs("place_block"), PlaceBlockActionClip.class, new ClipFactoryData(Icons.BLOCK, Colors.INACTIVE))
            .register(Link.bbs("interact_block"), InteractBlockActionClip.class, new ClipFactoryData(Icons.FULLSCREEN, Colors.MAGENTA))
            .register(Link.bbs("break_block"), BreakBlockActionClip.class, new ClipFactoryData(Icons.BULLET, Colors.GREEN))
            .register(Link.bbs("use_item"), UseItemActionClip.class, new ClipFactoryData(Icons.POINTER, Colors.BLUE))
            .register(Link.bbs("use_block_item"), UseBlockItemActionClip.class, new ClipFactoryData(Icons.BUCKET, Colors.CYAN))
            .register(Link.bbs("release_use_item"), ReleaseUseItemActionClip.class, new ClipFactoryData(Icons.ARROW_UP, 0x9457ff))
            .register(Link.bbs("drop_item"), ItemDropActionClip.class, new ClipFactoryData(Icons.ARROW_DOWN, Colors.DEEP_PINK))
            .register(Link.bbs("attack"), AttackActionClip.class, new ClipFactoryData(Icons.DROP, Colors.RED))
            .register(Link.bbs("damage"), DamageActionClip.class, new ClipFactoryData(Icons.SKULL, Colors.CURSOR))
            .register(Link.bbs("swipe"), SwipeActionClip.class, new ClipFactoryData(Icons.LIMB, Colors.ORANGE));

        events.post(new RegisterActionClipsEvent(factoryActionClips));

        setupConfig(Icons.SETTINGS, "bbs", new File(settingsFolder, "bbs.json"), BBSSettings::register);

        events.post(new RegisterSettingsEvent());

        /* Networking */
        ServerNetwork.setup();

        /* Commands */
        CommandRegistrationCallback.EVENT.register(BBSCommands::register);

        /* Event listener */
        registerEvents();

        /* Entities */
        FabricDefaultAttributeRegistry.register(ACTOR_ENTITY, ActorEntity.createActorAttributes());

        /* Blocks */
        class_2378.method_10230(class_7923.field_41175, new class_2960(MOD_ID, "model"), MODEL_BLOCK);
        class_2378.method_10230(class_7923.field_41175, new class_2960(MOD_ID, "chroma_red"), CHROMA_RED_BLOCK);
        class_2378.method_10230(class_7923.field_41175, new class_2960(MOD_ID, "chroma_green"), CHROMA_GREEN_BLOCK);
        class_2378.method_10230(class_7923.field_41175, new class_2960(MOD_ID, "chroma_blue"), CHROMA_BLUE_BLOCK);
        class_2378.method_10230(class_7923.field_41175, new class_2960(MOD_ID, "chroma_cyan"), CHROMA_CYAN_BLOCK);
        class_2378.method_10230(class_7923.field_41175, new class_2960(MOD_ID, "chroma_magenta"), CHROMA_MAGENTA_BLOCK);
        class_2378.method_10230(class_7923.field_41175, new class_2960(MOD_ID, "chroma_yellow"), CHROMA_YELLOW_BLOCK);
        class_2378.method_10230(class_7923.field_41175, new class_2960(MOD_ID, "chroma_black"), CHROMA_BLACK_BLOCK);
        class_2378.method_10230(class_7923.field_41175, new class_2960(MOD_ID, "chroma_white"), CHROMA_WHITE_BLOCK);

        class_2378.method_10230(class_7923.field_41178, new class_2960(MOD_ID, "model"), MODEL_BLOCK_ITEM);
        class_2378.method_10230(class_7923.field_41178, new class_2960(MOD_ID, "gun"), GUN_ITEM);
        class_2378.method_10230(class_7923.field_41178, new class_2960(MOD_ID, "structure_wand"), STRUCTURE_WAND_ITEM);
        class_2378.method_10230(class_7923.field_41178, new class_2960(MOD_ID, "chroma_red"), CHROMA_RED_BLOCK_ITEM);
        class_2378.method_10230(class_7923.field_41178, new class_2960(MOD_ID, "chroma_green"), CHROMA_GREEN_BLOCK_ITEM);
        class_2378.method_10230(class_7923.field_41178, new class_2960(MOD_ID, "chroma_blue"), CHROMA_BLUE_BLOCK_ITEM);
        class_2378.method_10230(class_7923.field_41178, new class_2960(MOD_ID, "chroma_cyan"), CHROMA_CYAN_BLOCK_ITEM);
        class_2378.method_10230(class_7923.field_41178, new class_2960(MOD_ID, "chroma_magenta"), CHROMA_MAGENTA_BLOCK_ITEM);
        class_2378.method_10230(class_7923.field_41178, new class_2960(MOD_ID, "chroma_yellow"), CHROMA_YELLOW_BLOCK_ITEM);
        class_2378.method_10230(class_7923.field_41178, new class_2960(MOD_ID, "chroma_black"), CHROMA_BLACK_BLOCK_ITEM);
        class_2378.method_10230(class_7923.field_41178, new class_2960(MOD_ID, "chroma_white"), CHROMA_WHITE_BLOCK_ITEM);

        class_2378.method_10230(class_7923.field_44687, new class_2960(MOD_ID, "main"), ITEM_GROUP);

        events.post(new BBSReadyEvent());
    }

    private void registerEvents()
    {
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) ->
        {
            if (entity instanceof class_3222 player)
            {
                Morph morph = Morph.getMorph(player);

                ServerNetwork.sendMorphToTracked(player, morph.getForm());
            }
        });

        ServerLifecycleEvents.SERVER_STARTED.register((event) -> worldFolder = event.method_27050(class_5218.field_24188).toFile());
        ServerPlayConnectionEvents.JOIN.register((a, b, c) -> ServerNetwork.sendHandshake(c, b));
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> actions.stopFor(handler.method_32311()));

        ActionHandler.registerHandlers(actions);

        ServerTickEvents.START_SERVER_TICK.register((server) ->
        {
            actions.tick();
        });

        ServerTickEvents.END_SERVER_TICK.register((server) ->
        {
            for (Runnable runnable : runnables)
            {
                runnable.run();
            }

            runnables.clear();
        });

        ServerLifecycleEvents.SERVER_STOPPED.register((server) ->
        {
            actions.reset();
            ServerNetwork.reset();
        });

        EntityTrackingEvents.START_TRACKING.register((trackedEntity, player) ->
        {
            runnables.add(() ->
            {
                if (trackedEntity instanceof class_3222 playerTwo)
                {
                    Morph morph = Morph.getMorph(trackedEntity);

                    if (morph != null)
                    {
                        ServerNetwork.sendMorph(player, playerTwo.method_5628(), morph.getForm());
                    }
                }
            });
        });
    }

    public static Settings setupConfig(Icon icon, String id, File destination, Consumer<SettingsBuilder> registerer)
    {
        SettingsBuilder builder = new SettingsBuilder(icon, id, destination);
        Settings settings = builder.getConfig();

        registerer.accept(builder);

        BBSMod.settings.modules.put(settings.getId(), settings);
        BBSMod.settings.load(settings, settings.file);

        return settings;
    }
}
