package mchorse.bbs_mod.cubic.render.vao;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_284;
import net.minecraft.class_4587;
import net.minecraft.class_5944;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL30;

public class ModelVAORenderer
{
    /** Sampler uniform names — setupUniforms runs per draw call, no string building there. */
    private static final String[] SAMPLERS =
    {
        "Sampler0", "Sampler1", "Sampler2", "Sampler3", "Sampler4", "Sampler5",
        "Sampler6", "Sampler7", "Sampler8", "Sampler9", "Sampler10", "Sampler11"
    };

    /**
     * The full model-view a draw issued right now would use. Deferred translucent commands
     * capture it at enqueue time, because the global model-view is different by the time
     * the queue flushes at the end of the frame.
     */
    public static Matrix4f captureModelView(class_4587 stack)
    {
        return new Matrix4f(RenderSystem.getModelViewMatrix()).mul(stack.method_23760().method_23761());
    }

    public static void render(class_5944 shader, IModelVAO modelVAO, class_4587 stack, float r, float g, float b, float a, int light, int overlay)
    {
        render(shader, modelVAO, captureModelView(stack), stack.method_23760().method_23762(), r, g, b, a, light, overlay);
    }

    public static void render(class_5944 shader, IModelVAO modelVAO, Matrix4f modelView, Matrix3f normalMat, float r, float g, float b, float a, int light, int overlay)
    {
        int currentVAO = GL30.glGetInteger(GL30.GL_VERTEX_ARRAY_BINDING);
        int currentElementArrayBuffer = GL30.glGetInteger(GL30.GL_ELEMENT_ARRAY_BUFFER_BINDING);

        setupUniforms(shader, modelView, normalMat);

        shader.method_34586();
        modelVAO.render(shader.method_35786(), r, g, b, a, light, overlay);
        shader.method_34585();

        GL30.glBindVertexArray(currentVAO);
        GL30.glBindBuffer(GL30.GL_ELEMENT_ARRAY_BUFFER, currentElementArrayBuffer);
    }

    public static void setupUniforms(class_4587 stack, class_5944 shader)
    {
        setupUniforms(shader, captureModelView(stack), stack.method_23760().method_23762());
    }

    public static void setupUniforms(class_5944 shader, Matrix4f modelView, Matrix3f normalMat)
    {
        for (int i = 0; i < SAMPLERS.length; i++)
        {
            shader.method_34583(SAMPLERS[i], RenderSystem.getShaderTexture(i));
        }

        if (shader.field_29471 != null)
        {
            shader.field_29471.method_1250(RenderSystem.getProjectionMatrix());
        }

        if (shader.field_29470 != null)
        {
            shader.field_29470.method_1250(modelView);
        }

        /* NormalMat is present by default in Iris' shaders, but when there is no Iris,
         * the BBS mod's model.json shader is being used instead that provides NormalMat
         * uniform.
         */
        class_284 normalUniform = shader.method_34582("NormalMat");

        if (normalUniform != null)
        {
            normalUniform.method_39978(normalMat);
        }

        if (shader.field_36323 != null)
        {
            shader.field_36323.method_39978(RenderSystem.getInverseViewRotationMatrix());
        }

        if (shader.field_29477 != null)
        {
            shader.field_29477.method_1251(RenderSystem.getShaderFogStart());
        }

        if (shader.field_29478 != null)
        {
            shader.field_29478.method_1251(RenderSystem.getShaderFogEnd());
        }

        if (shader.field_29479 != null)
        {
            shader.field_29479.method_1253(RenderSystem.getShaderFogColor());
        }

        if (shader.field_36373 != null)
        {
            shader.field_36373.method_35649(RenderSystem.getShaderFogShape().method_40036());
        }

        if (shader.field_29474 != null)
        {
            shader.field_29474.method_35657(1F, 1F, 1F, 1F);
        }

        if (shader.field_29481 != null)
        {
            shader.field_29481.method_1251(RenderSystem.getShaderGameTime());
        }

        if (shader.field_29472 != null)
        {
            shader.field_29472.method_1250(RenderSystem.getTextureMatrix());
        }

        RenderSystem.setupShaderLights(shader);
    }
}
