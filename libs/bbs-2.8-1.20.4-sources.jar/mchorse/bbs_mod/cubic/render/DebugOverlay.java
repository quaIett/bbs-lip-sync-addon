package mchorse.bbs_mod.cubic.render;

import mchorse.bbs_mod.bobj.BOBJBone;
import mchorse.bbs_mod.cubic.IModel;
import mchorse.bbs_mod.cubic.data.model.Model;
import mchorse.bbs_mod.cubic.data.model.ModelGroup;
import mchorse.bbs_mod.cubic.model.bobj.BOBJModel;
import mchorse.bbs_mod.graphics.Draw;
import mchorse.bbs_mod.settings.values.ui.ValueDebugElement;
import mchorse.bbs_mod.utils.MathUtils;
import mchorse.bbs_mod.utils.colors.Colors;
import net.minecraft.class_287;
import net.minecraft.class_4587;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * The shared drawing language of the model debug overlays (IK and physics):
 * lines that can be hairline or volumetric, solid or dashed, and markers in
 * the {@link ValueDebugElement} shapes. Everything is emitted in the overlay's
 * drawing space through the given matrix — no Euler orientation anywhere
 * ({@code Draw.fillBoxTo}'s camera-convention angles diverge under the model
 * stack and tubes fly off the joints), thick lines and shapes are built from
 * cross-product bases and raw vertices instead.
 */
public final class DebugOverlay
{
    /** The drawing scale of a rig with no measurable bones at all. */
    private static final float FALLBACK_UNIT = 0.25F;

    private static final float EPS = 1.0e-6f;

    private DebugOverlay()
    {
    }

    /**
     * The scale an overlay draws a model at: the average REST bone length of the
     * WHOLE rig. One number per model, so every marker and wire on it comes out
     * the same size — it used to be the average segment of each chain, which made
     * a two-bone chain draw fat handles next to a five-bone one on the same model,
     * and made every handle jump the moment a chain's length changed.
     *
     * <p>Rest, never the posed skeleton: a pose-derived scale would breathe with
     * the animation, which is the same complaint one step further out. Read
     * straight off the rig's relative bone offsets — cubic pivots are in the
     * model's pixel space, so they come back to blocks the way the renderer takes
     * them ({@code ICubicRenderer.moveToGroupPivot}), while BOBJ rest matrices are
     * already in the overlay's space.
     */
    public static float modelUnit(IModel model)
    {
        float total = 0F;
        int bones = 0;

        if (model instanceof Model cubic)
        {
            for (ModelGroup group : cubic.getAllGroups())
            {
                float length = group.initial.translate.length() / 16F;

                if (length > EPS)
                {
                    total += length;
                    bones++;
                }
            }
        }
        else if (model instanceof BOBJModel bobj)
        {
            for (BOBJBone bone : bobj.getAllBOBJBones())
            {
                float length = bone.relBoneMat.getTranslation(new Vector3f()).length();

                if (length > EPS)
                {
                    total += length;
                    bones++;
                }
            }
        }

        return bones > 0 ? total / bones : FALLBACK_UNIT;
    }

    public static float[] rgb(int color)
    {
        return new float[] {Colors.getR(color), Colors.getG(color), Colors.getB(color)};
    }

    /** A line segment: hairline vertices when {@code thickness} is zero, a prism otherwise; split into dashes when asked. */
    public static void segment(class_287 builder, Matrix4f matrix, float thickness, boolean dashed, float dash, Vector3f p1, Vector3f p2, float[] col, float a)
    {
        if (!dashed || dash <= 0F)
        {
            solid(builder, matrix, thickness, p1, p2, col, a);

            return;
        }

        int count = Math.max(1, Math.round(p1.distance(p2) / dash));

        /* An odd dash count keeps both endpoints solid. */
        if (count % 2 == 0)
        {
            count++;
        }

        for (int i = 0; i < count; i += 2)
        {
            Vector3f d1 = new Vector3f(p1).lerp(p2, i / (float) count);
            Vector3f d2 = new Vector3f(p1).lerp(p2, (i + 1) / (float) count);

            solid(builder, matrix, thickness, d1, d2, col, a);
        }
    }

    public static void line(class_287 builder, Matrix4f matrix, Vector3f p1, Vector3f p2, float[] col, float a)
    {
        builder.method_22918(matrix, p1.x, p1.y, p1.z).method_22915(col[0], col[1], col[2], a).method_1344();
        builder.method_22918(matrix, p2.x, p2.y, p2.z).method_22915(col[0], col[1], col[2], a).method_1344();
    }

    private static void solid(class_287 builder, Matrix4f matrix, float thickness, Vector3f p1, Vector3f p2, float[] col, float a)
    {
        if (thickness > 0F)
        {
            prism(builder, matrix, p1, p2, thickness, col, a);
        }
        else
        {
            line(builder, matrix, p1, p2, col, a);
        }
    }

    /** A thick line as a box built from cross-product basis vectors. */
    private static void prism(class_287 builder, Matrix4f matrix, Vector3f p1, Vector3f p2, float thickness, float[] col, float a)
    {
        Vector3f d = new Vector3f(p2).sub(p1);
        float len2 = d.lengthSquared();

        if (len2 < 1e-12F)
        {
            return;
        }

        Vector3f ref = d.y * d.y > 0.98F * len2 ? new Vector3f(1F, 0F, 0F) : new Vector3f(0F, 1F, 0F);
        Vector3f u = new Vector3f(d).cross(ref).normalize().mul(thickness * 0.5F);
        Vector3f v = new Vector3f(d).cross(u).normalize().mul(thickness * 0.5F);

        Vector3f c1 = new Vector3f(p1).add(u).add(v);
        Vector3f c2 = new Vector3f(p1).sub(u).add(v);
        Vector3f c3 = new Vector3f(p1).sub(u).sub(v);
        Vector3f c4 = new Vector3f(p1).add(u).sub(v);
        Vector3f c5 = new Vector3f(p2).add(u).add(v);
        Vector3f c6 = new Vector3f(p2).sub(u).add(v);
        Vector3f c7 = new Vector3f(p2).sub(u).sub(v);
        Vector3f c8 = new Vector3f(p2).add(u).sub(v);

        quad(builder, matrix, c1, c2, c6, c5, col, a);
        quad(builder, matrix, c2, c3, c7, c6, col, a);
        quad(builder, matrix, c3, c4, c8, c7, col, a);
        quad(builder, matrix, c4, c1, c5, c8, col, a);
        quad(builder, matrix, c1, c2, c3, c4, col, a);
        quad(builder, matrix, c5, c6, c7, c8, col, a);
    }

    /** A marker of the element's shape at {@code p}. The factors even out the shapes' visual footprint at equal sizes. */
    public static void marker(class_287 builder, class_4587 stack, int shape, Vector3f p, float radius, float[] col, float a)
    {
        stack.method_22903();
        stack.method_46416(p.x, p.y, p.z);

        if (shape == ValueDebugElement.SHAPE_CUBE)
        {
            float s = radius * 0.8F;

            Draw.fillBox(builder, stack, -s, -s, -s, s, s, s, col[0], col[1], col[2], a);
        }
        else if (shape == ValueDebugElement.SHAPE_DIAMOND)
        {
            diamond(builder, stack, radius * 1.3F, col, a);
        }
        else if (shape == ValueDebugElement.SHAPE_RING)
        {
            ring(builder, stack, radius * 1.05F, radius * 0.22F, col, a);
        }
        else if (shape == ValueDebugElement.SHAPE_CROSS)
        {
            cross(builder, stack, radius, col, a);
        }
        else
        {
            Draw.sphere(builder, stack, radius, 9, 9, col[0], col[1], col[2], a);
        }

        stack.method_22909();
    }

    /** An octahedron with apexes at {@code s} along every axis. */
    private static void diamond(class_287 builder, class_4587 stack, float s, float[] col, float a)
    {
        Matrix4f m = stack.method_23760().method_23761();

        tri(builder, m, 0, s, 0, s, 0, 0, 0, 0, s, col, a);
        tri(builder, m, 0, s, 0, 0, 0, s, -s, 0, 0, col, a);
        tri(builder, m, 0, s, 0, -s, 0, 0, 0, 0, -s, col, a);
        tri(builder, m, 0, s, 0, 0, 0, -s, s, 0, 0, col, a);
        tri(builder, m, 0, -s, 0, 0, 0, s, s, 0, 0, col, a);
        tri(builder, m, 0, -s, 0, -s, 0, 0, 0, 0, s, col, a);
        tri(builder, m, 0, -s, 0, 0, 0, -s, -s, 0, 0, col, a);
        tri(builder, m, 0, -s, 0, s, 0, 0, 0, 0, -s, col, a);
    }

    /** A thin torus around the Y axis. */
    private static void ring(class_287 builder, class_4587 stack, float radius, float tube, float[] col, float a)
    {
        Matrix4f m = stack.method_23760().method_23761();
        int segU = 20;
        int segV = 8;

        for (int iu = 0; iu < segU; iu++)
        {
            float u1 = MathUtils.PI * 2F * iu / segU;
            float u2 = MathUtils.PI * 2F * (iu + 1) / segU;

            for (int iv = 0; iv < segV; iv++)
            {
                float v1 = MathUtils.PI * 2F * iv / segV;
                float v2 = MathUtils.PI * 2F * (iv + 1) / segV;

                Vector3f p11 = torusPoint(radius, tube, u1, v1);
                Vector3f p12 = torusPoint(radius, tube, u1, v2);
                Vector3f p21 = torusPoint(radius, tube, u2, v1);
                Vector3f p22 = torusPoint(radius, tube, u2, v2);

                quad(builder, m, p11, p12, p22, p21, col, a);
            }
        }
    }

    private static Vector3f torusPoint(float radius, float tube, float u, float v)
    {
        float ring = radius + tube * (float) Math.cos(v);

        return new Vector3f(ring * (float) Math.cos(u), tube * (float) Math.sin(v), ring * (float) Math.sin(u));
    }

    /** Three thin axis-aligned bars through the centre, Blender's plain-axes empty. */
    private static void cross(class_287 builder, class_4587 stack, float radius, float[] col, float a)
    {
        float l = radius * 1.4F;
        float t = radius * 0.16F;

        Draw.fillBox(builder, stack, -l, -t, -t, l, t, t, col[0], col[1], col[2], a);
        Draw.fillBox(builder, stack, -t, -l, -t, t, l, t, col[0], col[1], col[2], a);
        Draw.fillBox(builder, stack, -t, -t, -l, t, t, l, col[0], col[1], col[2], a);
    }

    private static void quad(class_287 builder, Matrix4f matrix, Vector3f p1, Vector3f p2, Vector3f p3, Vector3f p4, float[] col, float a)
    {
        builder.method_22918(matrix, p1.x, p1.y, p1.z).method_22915(col[0], col[1], col[2], a).method_1344();
        builder.method_22918(matrix, p2.x, p2.y, p2.z).method_22915(col[0], col[1], col[2], a).method_1344();
        builder.method_22918(matrix, p3.x, p3.y, p3.z).method_22915(col[0], col[1], col[2], a).method_1344();
        builder.method_22918(matrix, p1.x, p1.y, p1.z).method_22915(col[0], col[1], col[2], a).method_1344();
        builder.method_22918(matrix, p3.x, p3.y, p3.z).method_22915(col[0], col[1], col[2], a).method_1344();
        builder.method_22918(matrix, p4.x, p4.y, p4.z).method_22915(col[0], col[1], col[2], a).method_1344();
    }

    private static void tri(class_287 builder, Matrix4f matrix, float x1, float y1, float z1, float x2, float y2, float z2, float x3, float y3, float z3, float[] col, float a)
    {
        builder.method_22918(matrix, x1, y1, z1).method_22915(col[0], col[1], col[2], a).method_1344();
        builder.method_22918(matrix, x2, y2, z2).method_22915(col[0], col[1], col[2], a).method_1344();
        builder.method_22918(matrix, x3, y3, z3).method_22915(col[0], col[1], col[2], a).method_1344();
    }
}
