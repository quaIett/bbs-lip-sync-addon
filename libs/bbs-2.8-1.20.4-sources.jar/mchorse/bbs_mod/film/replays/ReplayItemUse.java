package mchorse.bbs_mod.film.replays;

import mchorse.bbs_mod.actions.types.ActionClip;
import mchorse.bbs_mod.actions.types.item.UseItemActionClip;
import mchorse.bbs_mod.cubic.animation.ItemUsePose;
import mchorse.bbs_mod.utils.clips.Clip;
import mchorse.bbs_mod.utils.keyframes.KeyframeChannel;
import mchorse.bbs_mod.utils.keyframes.KeyframeSegment;
import net.minecraft.class_1764;
import net.minecraft.class_1799;
import net.minecraft.class_1839;
import java.util.ArrayList;
import java.util.List;

/**
 * The item use running in a replay's hand at a given tick, read off its "use
 * item" action clips.
 *
 * <p>A live player has an item use state vanilla ticks; a take has clips. The
 * server side of such a clip fires {@code stack.use} once - here only WHEN it
 * fired and for how long is read, never that path, so everything driven by it
 * (the arm pose, the item's own model, the crumbs of a meal) scrubs with the
 * cursor like the rest of the film.</p>
 */
public class ReplayItemUse
{
    /**
     * Which animation: the item actually displayed in the hand decides, and the
     * clip's own stack is the fallback (a vanilla item wrapped into a form has no
     * use action of its own). How long: the clip's duration when the author set
     * one, otherwise the item's natural vanilla time - the animation itself always
     * runs at vanilla speed and simply holds its end pose while the clip lasts,
     * exactly like holding a drawn bow.
     */
    public static ItemUsePose.Use compute(Replay replay, float tick, boolean mainHand)
    {
        class_1799 displayed = mainHand
            ? itemAt(replay.keyframes.hotbar.get(replay.keyframes.getSelectedSlot(tick)), tick)
            : itemAt(replay.keyframes.offHand, tick);

        ItemUsePose.Use state = null;
        float latest = Float.NEGATIVE_INFINITY;
        List<Float> fires = new ArrayList<>();

        for (Clip clip : replay.actions.get())
        {
            if (!(clip instanceof UseItemActionClip useClip) || useClip.hand.get() != mainHand)
            {
                continue;
            }

            class_1799 clipStack = useClip.itemStack.get();
            class_1839 action = displayed.method_7976() != class_1839.field_8952 ? displayed.method_7976() : clipStack.method_7976();

            if (action == class_1839.field_8952)
            {
                continue;
            }

            class_1799 timing = displayed.method_7976() != class_1839.field_8952 ? displayed : clipStack;
            float window = useClip.duration.get() > 1 ? useClip.duration.get() : naturalWindow(action, timing);

            fires.clear();
            collectFires(useClip, tick, fires);

            for (float fire : fires)
            {
                if (tick < fire + window && fire > latest)
                {
                    latest = fire;
                    state = new ItemUsePose.Use(action, tick - fire, timing, window);
                }
            }
        }

        return state;
    }

    /** The stack a slot channel holds at given tick - a slot never fades, it switches. */
    public static class_1799 itemAt(KeyframeChannel<class_1799> channel, float tick)
    {
        KeyframeSegment<class_1799> segment = channel.find(tick);

        return segment == null ? class_1799.field_8037 : segment.a.getValue();
    }

    /**
     * How long an untouched use clip animates: each item's own vanilla
     * saturation point - a bite takes its eating time, a bow reaches full pull
     * in 20 ticks, a crossbow in its pull time, a trident charges in 10.
     */
    private static float naturalWindow(class_1839 action, class_1799 stack)
    {
        switch (action)
        {
            case field_8950:
            case field_8946:
                return stack.method_7935() > 0 ? stack.method_7935() : 32F;
            case field_8947:
                return Math.max(1, class_1764.method_7775(stack));
            case field_8951:
                return 10F;
            default:
                return 20F;
        }
    }

    /**
     * Every tick at or before {@code tick} where an action clip fires: its own
     * start, plus the repeats its frequency schedules inside its duration
     * (the same rule {@link ActionClip#apply} plays them by). Disabled clips
     * fire never.
     */
    private static void collectFires(ActionClip clip, float tick, List<Float> fires)
    {
        if (!clip.enabled.get())
        {
            return;
        }

        int start = clip.tick.get();

        if (tick < start)
        {
            return;
        }

        int frequency = clip.frequency.get();

        if (frequency <= 0)
        {
            fires.add((float) start);
        }
        else
        {
            float inside = Math.min(tick, start + clip.duration.get() - 1) - start;

            for (int k = 0; k * frequency <= inside; k++)
            {
                fires.add((float) (start + k * frequency));
            }
        }
    }
}
