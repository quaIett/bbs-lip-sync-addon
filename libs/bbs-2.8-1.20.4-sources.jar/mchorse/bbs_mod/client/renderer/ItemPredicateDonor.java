package mchorse.bbs_mod.client.renderer;

import mchorse.bbs_mod.cubic.animation.ItemUsePose;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;

/**
 * A stand-in entity for vanilla's item model predicates.
 *
 * <p>A drawn bow, a blocking shield and a charged crossbow are different MODELS,
 * picked by predicates that ask an entity whether it is using this very stack.
 * A film's actor is no such entity - it never uses anything - so the predicates
 * get answered from the film's data instead, through this one.</p>
 */
public class ItemPredicateDonor
{
    private static class_1531 donor;

    /**
     * An entity that reports "using this stack, this much time left" so that
     * vanilla's model predicates (bow pull, crossbow pulling/charged, shield
     * blocking, trident throwing) pick the right model. The predicates compare
     * the active stack by identity, so the caller must hand in the very
     * instance it renders.
     */
    public static class_1309 get(class_1799 stack, ItemUsePose.Use use)
    {
        class_310 mc = class_310.method_1551();

        if (mc.field_1687 == null || stack.method_7960())
        {
            return null;
        }

        if (donor == null || donor.method_37908() != mc.field_1687)
        {
            donor = new class_1531(mc.field_1687, 0D, 0D, 0D);

            donor.method_6122(class_1268.field_5808, new class_1799(class_1802.field_8102));
            donor.method_6019(class_1268.field_5808);

            /* setCurrentHand only raises the "using item" flag on the SERVER
             * (its isClient branch skips setLivingFlag - 1.20.4 bytecode), and
             * the bow's "pulling", the shield's "blocking" and the trident's
             * "throwing" predicates all demand that flag: without it the bow
             * never bends and never shows its arrow. Raise it by hand, once -
             * on the client nothing ever lowers it again. */
            donor.method_6085(1, true);
        }

        donor.field_6277 = stack;
        donor.field_6222 = Math.max(0, Math.round(stack.method_7935() - use.elapsed()));

        return donor;
    }
}
